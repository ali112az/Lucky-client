// 常量定义
import { MessageType, MessageContentType } from "@/constants";

// 本地工具和存储
import { storage } from "@/utils/Storage";
import { useAudioPlayer, AudioEnum } from "@/hooks/useAudioPlayer";
import { useTauriEvent } from "@/hooks/useTauriEvent";
import { useGlobalShortcut } from "./hooks/useGlobalShortcut";
import ObjectUtils from "@/utils/ObjectUtils";
import { downloadDir } from "@tauri-apps/api/path";
import { useTray } from "@/hooks/useTray";
import { exit } from "@tauri-apps/plugin-process";
import { useIdleTaskExecutor } from "@/hooks/useIdleTaskExecutor";
// import { useUpdate } from "@/hooks/useUpdate"

// 窗口操作
import { CreateScreenWindow } from "@/windows/screen";
import { showOrCreateNotifyWindow, calculateHideNotifyWindow } from "@/windows/notify";
import { ShowMainWindow, appIsMinimizedOrHidden } from "@/windows/main";

// 数据请求
import api from "@/api/index";

// 配置和初始化
import { useWebSocketWorker } from "@/hooks/useWebSocketWorker";
//import loadWorker from "@/worker/LoadWorker";

// 状态管理和数据存储
import { useChatMainStore } from "@/store/modules/chat";
import { useMessageStore } from "@/store/modules/message";
import { useUserStore } from "@/store/modules/user";
import { useCallStore } from "@/store/modules/call";
import { useSettingStore } from "@/store/modules/setting";
import { useFriendsStore } from "@/store/modules/friends";

// 数据库实体
import SingleMessage from "@/database/entity/SingleMessage";
import GroupMessage from "@/database/entity/GroupMessage";
import { useMappers } from "@/database";

// 获取和初始化数据库操作
const { chatsMapper, singleMapper, groupMapper, friendsMapper } = useMappers();

// 状态管理实例
const callStore = useCallStore();
const chatStore = useChatMainStore();
const userStore = useUserStore();
const messageStore = useMessageStore();
const settingStore = useSettingStore();
const friendStore = useFriendsStore();

// 声音
const { play } = useAudioPlayer();

// 系统托盘
const { initSystemTray, flash } = useTray();

// 事件总线
const { onceEventDebounced } = useTauriEvent();

// 日志
const log = useLogger();

const { connect, disconnect, onMessage } = useWebSocketWorker();

// 异步（空闲）任务执行器
const exec = useIdleTaskExecutor({ maxWorkTimePerIdle: 12 });

// const { fetchVersion } = useUpdate();

/**
 *
 * - 将初始化拆分为：关键路径（Sync）+ 后台任务（Idle）
 * - 提供 start/stop/cleanup
 */
class MainManager {

  private static instance: MainManager;

  // 保存 ws unsubscribe 以便在 destroy 时取消
  private wsUnsub: (() => void) | null = null;
  private backgroundTasksRunning = false;

  private constructor() {}

  public static getInstance(): MainManager {
    if (!MainManager.instance) {
      MainManager.instance = new MainManager();
    }
    return MainManager.instance;
  }

  /**
   * 启动客户端（主入口）
   * - 仅等待关键初始化（用户信息、chat store、WebSocket 注册）
   * - 其它耗时/可延后任务放到后台执行
   */
  async initClient() {
    const t0 = performance.now();
    log.prettyInfo("core", "客户端初始化开始");

    try {
      // 1) 启动语言加载（轻量，可并行）
      this.initLanguage().catch(err => log.prettyWarn("init", "initLanguage failed (non-fatal)", err));

      // 2) 获取用户信息 —— **关键路径**（必须完成以便后续鉴权）
      await this.initUserSafe();

      // 3) 本地会话初始化（快速，本地操作）
      this.initChatStore().catch(err => log.prettyError("core", "initChatStore 失败（非致命）", err));

      // 4) 启动后台任务（数据库、离线同步、托盘、快捷键等）
      this.runBackgroundInit().catch(err => log.prettyError("core", "runBackgroundInit 失败（非致命）", err));

      // 5) 初始化 WebSocket（注册 onMessage -> 再 connect）
      await this.initWebSocketSafe();

      const t1 = performance.now();

      log.prettySuccess("core", `客户端关键路径初始化完成（${Math.round(t1 - t0)} ms）`);
    } catch (err) {
      log.prettyError("core", "initClient 致命错误", err);
    }
  }

  /* ---------------------- 关键子任务（可被单独调用） ---------------------- */

  /** 初始化语言（轻量） */
  async initLanguage() {
    const t0 = performance.now();
    // 如果有语言加载逻辑放这里（示例用注释）
    // await loadI18n();
    const t1 = performance.now();
    log.prettyInfo("i18n", `语言初始化完成（${Math.round(t1 - t0)} ms）`);
  }

  /** 安全初始化用户（捕获错误并记录） */
  private async initUserSafe() {
    const t0 = performance.now();
    try {
      await userStore.handleGetUserInfo();
      log.prettySuccess("user", "用户信息初始化成功");
    } catch (err) {
      log.prettyError("user", "初始化用户信息失败", err);
      throw err; // 关键路径失败需要抛出
    } finally {
      const t1 = performance.now();
      log.prettyInfo("user", `initUser 耗时 ${Math.round(t1 - t0)} ms`);
    }
  }

  /** 初始化会话（本地） */
  async initChatStore() {
    const t0 = performance.now();
    try {
      await chatStore.handleInit();
      log.prettySuccess("user", "本地会话初始化成功");
    } catch (err) {
      log.prettyError("user", "本地会话初始化失败", err);
      throw err; // 关键路径失败需要抛出
    } finally {
      const t1 = performance.now();
      log.prettyInfo("user", `initChat 耗时 ${Math.round(t1 - t0)} ms`);
    }
  }

  /**
   * 初始化 WebSocket：先注册 onMessage，再发起 connect（确保不会漏消息）
   *
   */
  async initWebSocketSafe() {
    const t0 = performance.now();
    try {
      const url = new URL(import.meta.env.VITE_API_SERVER_WS);

      // 添加用户id 和 token 用于 用户鉴权
      url.searchParams.append("uid", userStore.userId);
      url.searchParams.append("token", userStore.token);

      onMessage((e: any) => {
        try {
          log.prettyInfo("websocket", "收到 ws 消息:", e);
          this.handleWebSocketMessage(e);
        } catch (err) {
          log.prettyError("websocket", "处理 ws 消息时抛出异常", err);
        }
      });

      // 发起连接
      connect(url.toString(), {
        payload: { code: 1000, token: userStore.token, data: "registrar" },
        heartbeat: { code: 1001, token: userStore.token, data: "heartbeat" },
        interval: import.meta.env.VITE_API_SERVER_HEARTBEAT,
        protocol: import.meta.env.VITE_API_PROTOCOL_TYPE
      });

      log.prettySuccess("websocket", "WebSocket连接成功");
    } catch (err) {
      log.prettyError("websocket", "WebSocket连接失败", err);
      throw err; // 关键路径，考虑失败重试或上报
    } finally {
      const t1 = performance.now();
      log.prettyInfo("websocket", `initWebSocket 耗时 ${Math.round(t1 - t0)} ms`);
    }
  }

  /* ---------------------- 后台初始化（空闲时执行） ---------------------- */

  /** 将耗时任务安排在空闲时间执行以避免阻塞渲染/启动流程 */
  private async runBackgroundInit() {
    if (this.backgroundTasksRunning) return;
    this.backgroundTasksRunning = true;

    const run = async () => {
      log.prettyInfo("background", "开始后台初始化任务（requestIdle）");

      const tasks = [
        this.initFileDownload(), // 设置下载目录（轻/中）
        this.initDatabase(), // 数据库初始化（较慢）
        this.syncUserData(), // 同步离线消息/会话/好友（较慢）
        this.initTray(), // 托盘（UI 相关）
        this.initShortcut() // 注册快捷键
      ];

      // 并行执行，记录各自结果
      const results = await Promise.allSettled(tasks);
      results.forEach((r, i) => {
        if (r.status === "rejected") {
          log.prettyWarn("background", `后台任务 #${i} 失败（非致命）`, r.reason);
        }
      });

      log.prettySuccess("background", "后台初始化任务完成（部分任务可能失败但不影响主流程）");
    };

    // 优先使用 requestIdleCallback（若存在），否则使用 setTimeout
    if (typeof (window as any).requestIdleCallback === "function") {
      (window as any).requestIdleCallback(() => run());
    } else {
      // 延迟一帧再运行，避免阻塞首次渲染
      setTimeout(() => run(), 50);
    }
  }

  /* ---------------------- 各项实现（可单独调用） ---------------------- */

  /** 初始化文件下载目录（如果未配置） */
  async initFileDownload() {
    const t0 = performance.now();
    try {
      if (ObjectUtils.isEmpty(settingStore.file.path)) {
        settingStore.file.path = await downloadDir();
        log.prettyInfo("file", "下载目录初始化为", settingStore.file.path);
      } else {
        log.prettyInfo("file", "已存在下载目录设置", settingStore.file.path);
      }
    } catch (err) {
      log.prettyWarn("file", "初始化下载目录失败（使用默认或稍后重试）", err);
    } finally {
      const t1 = performance.now();
      log.prettyInfo("file", `initFileDownload 耗时 ${Math.round(t1 - t0)} ms`);
    }
  }

  /** 初始化数据库（FTS 等） */
  async initDatabase() {
    const t0 = performance.now();
    try {
      await Promise.all([
        chatsMapper.createFTSTable(),
        singleMapper.createFTSTable(),
        groupMapper.createFTSTable(),
        friendsMapper.createFTSTable()
      ]);
      log.prettySuccess("database", "数据库 FTS 表初始化成功");
    } catch (err) {
      log.prettyError("database", "数据库初始化失败（可重试）", err);
      // 不抛出：数据库失败不应阻塞 UI 启动
    } finally {
      const t1 = performance.now();
      log.prettyInfo("database", `initDatabase 耗时 ${Math.round(t1 - t0)} ms`);
    }
  }

  /** 同步用户数据（离线消息、会话、好友）——耗时，置于后台 */
  async syncUserData() {
    const t0 = performance.now();
    try {
      // 并行拉取消息与会话（由你原来的实现组成）
      // 注意：updateMessageData 与 updateChatData 各自内部包含 DB 操作（可能耗时）
      await Promise.all([this.updateMessageData(), this.updateChatData()]);
      // 好友信息稍后刷新（非阻塞）
      friendStore.loadNewFriends();
      log.prettySuccess("sync", "用户数据同步完成");
    } catch (err) {
      log.prettyError("sync", "同步用户数据失败（可重试）", err);
    } finally {
      const t1 = performance.now();
      log.prettyInfo("sync", `syncUserData 耗时 ${Math.round(t1 - t0)} ms`);
    }
  }

  /** 获取并更新离线消息数据（保留原实现，但加上错误隔离） */
  async updateMessageData() {
    const t0 = performance.now();
    try {
      const chats = await chatsMapper.findLastChat();
      const sequence = chats?.[0]?.sequence || 0;
      const formData = { fromId: storage.get("userId"), sequence };

      const res: any = await api.GetMessageList(formData);
      if (!res) {
        log.prettyInfo("core", "GetMessageList 无新数据");
        return;
      }

      if (res[MessageType.SINGLE_MESSAGE.code]) {
        await singleMapper.batchInsert(res[MessageType.SINGLE_MESSAGE.code], {
          ownerId: storage.get("userId"),
          messageType: MessageType.SINGLE_MESSAGE.code
        });

        singleMapper.batchInsertFTS5(
          res[MessageType.SINGLE_MESSAGE.code],
          {
            ownerId: storage.get("userId"),
            messageType: MessageType.SINGLE_MESSAGE.code
          },
          200,
          exec
        );
      }

      if (res[MessageType.GROUP_MESSAGE.code]) {
        await groupMapper.batchInsert(res[MessageType.GROUP_MESSAGE.code], {
          ownerId: storage.get("userId"),
          messageType: MessageType.GROUP_MESSAGE.code
        });

        groupMapper.batchInsertFTS5(
          res[MessageType.GROUP_MESSAGE.code],
          {
            ownerId: storage.get("userId"),
            messageType: MessageType.GROUP_MESSAGE.code
          },
          200,
          exec
        );
      }

      log.prettyInfo("core", "消息数据更新成功");
    } catch (err) {
      log.prettyError("core", "更新离线消息失败", err);
    } finally {
      const t1 = performance.now();
      log.prettyInfo("core", `updateMessageData 耗时 ${Math.round(t1 - t0)} ms`);
    }
  }

  /** 获取并更新会话数据（保留原实现并加日志/错误隔离） */
  async updateChatData() {
    const t0 = performance.now();
    try {
      const lastChats = await chatsMapper.findLastChat();
      const sequence = lastChats?.[0]?.sequence ?? 0;

      const res: any = await api.GetChatList({
        fromId: storage.get("userId"),
        sequence
      });

      if (Array.isArray(res) && res.length > 0) {
        const transformed = res.map((chat: any) => {
          let parsedMessage: any = chat.message;
          try {
            if (typeof chat.message === "string" && chat.message.length > 0) {
              parsedMessage = JSON.parse(chat.message);
            }
          } catch {
            parsedMessage = chat.message;
          }
          const message = this.replaceMessageBody(parsedMessage, chat.messageContentType);
          const newChat: Record<string, any> = { ...chat, message };
          delete newChat.messageContentType;
          return newChat;
        });

        try {
          await chatsMapper.batchInsert(transformed);
          chatsMapper.batchInsertFTS5(transformed, undefined, 200, exec);
          log.prettyInfo("core", `批量插入 ${transformed.length} 条会话到 FTS`);
        } catch (batchErr) {
          log.prettyWarn("core", "batchInsertFTS5 失败，降级到逐条插入", batchErr);
          for (const item of transformed) {
            try {
              await chatsMapper.insertOrUpdate(item);
            } catch (singleErr) {
              log.prettyError("core", "单条插入失败，忽略并继续", singleErr);
            }
          }
        }

        const list: any = await chatsMapper.selectList();
        chatStore.handleSortChatList(list);
        log.prettyInfo("core", "会话数据批量更新成功");
      } else {
        const list: any = await chatsMapper.selectList();
        chatStore.handleSortChatList(list);
        log.prettyInfo("core", "会话无新数据，使用本地列表排序");
      }
    } catch (err) {
      log.prettyError("core", "更新会话数据失败", err);
      const list: any = await chatsMapper.selectList();
      chatStore.handleSortChatList(list);
    } finally {
      const t1 = performance.now();
      log.prettyInfo("core", `updateChatData 耗时 ${Math.round(t1 - t0)} ms`);
    }
  }

  /** 更新好友数据（后台） */
  async updateFriendData() {
    const t0 = performance.now();
    try {
      const res: any = await api.GetContacts({ userId: storage.get("userId") });
      if (res && res.length > 0) {
        await friendsMapper.deleteById(storage.get("userId"));
        await friendsMapper.batchInsert(res);
        log.prettyInfo("core", "好友数据更新成功");
      }
    } catch (err) {
      log.prettyError("core", "更新好友数据失败", err);
    } finally {
      const t1 = performance.now();
      log.prettyInfo("core", `updateFriendData 耗时 ${Math.round(t1 - t0)} ms`);
    }
  }

  /* ---------------------- 其它小工具 & UI 功能 ---------------------- */

  /** 根据消息类型返回替代文本（保留并简化原逻辑） */
  replaceMessageBody(messageObj: any, messageContentType: any) {
    const code = parseInt(messageContentType);
    if (!messageObj || !messageContentType) return "";
    switch (code) {
      case MessageContentType.TEXT.code:
        return messageObj.message;
      case MessageContentType.IMAGE.code:
        return "[图片]";
      case MessageContentType.VIDEO.code:
        return "[视频]";
      case MessageContentType.AUDIO.code:
        return "[语音]";
      case MessageContentType.FILE.code:
        return "[文件]";
      case MessageContentType.LOCAL.code:
        return "[位置]";
      default:
        return "未知消息类型";
    }
  }

  /** 初始化快捷键（后台执行） */
  async initShortcut() {
    const t0 = performance.now();
    try {
      useGlobalShortcut([
        {
          name: "screenshot",
          combination: "Ctrl+Shift+M",
          handler: () => {
            log.prettyInfo("shortcut", "开启截图");
            CreateScreenWindow(screen.availWidth, screen.availHeight);
          }
        }
      ]).init();
      log.prettySuccess("shortcut", "初始化快捷键成功");
    } catch (err) {
      log.prettyError("shortcut", "快捷键初始化失败", err);
    } finally {
      const t1 = performance.now();
      log.prettyInfo("shortcut", `initShortcut 耗时 ${Math.round(t1 - t0)} ms`);
    }
  }

  /** 初始化托盘（后台执行） */
  async initTray() {
    const t0 = performance.now();
    try {
      await initSystemTray({
        id: "app-tray",
        tooltip: import.meta.env.VITE_APP_NAME,
        icon: "icons/32x32.png",
        empty_icon: "icons/empty.png",
        flashTime: 500,
        menuItems: [
          { id: "open", text: "打开窗口", action: () => ShowMainWindow() },
          {
            id: "quit",
            text: "退出",
            action: async () => {
              await exit(0);
            }
          }
        ],
        trayClick: (event: any) => {
          const { button, buttonState, type } = event;
          if (button === "Left" && buttonState === "Up" && type === "Click") {
            log.prettyInfo("tray", "鼠标左键点击抬起 打开主窗口");
            ShowMainWindow();
            flash(false);
          }
        },
        trayEnter: async (event: any) => {
          const chatCount = chatStore.getHaveMessageChat.length;
          if (chatCount > 0) {
            showOrCreateNotifyWindow(chatCount, event.position);
            onceEventDebounced("notify-win-click", event => {
              log.prettyInfo("tray", "应用加载完成:", event.payload);
            });
          }
        },
        trayMove: () => {},
        trayLeave: (event: any) => {
          log.prettyInfo("tray", "鼠标移出关闭窗口", event);
          calculateHideNotifyWindow(event);
        }
      });
      log.prettySuccess("tray", "系统托盘初始化成功");
    } catch (err) {
      log.prettyError("tray", "初始化系统托盘失败（可忽略）", err);
    } finally {
      const t1 = performance.now();
      log.prettyInfo("tray", `initTray 耗时 ${Math.round(t1 - t0)} ms`);
    }
  }

  /* ---------------------- WebSocket 消息处理 ---------------------- */

  /**
   *  处理WebSocket收到的消息
   *  @param data
   */
  handleWebSocketMessage(res: any) {
    const { code, data } = res;
    if (!data) return;
    if (code === MessageType.SINGLE_MESSAGE.code || code === MessageType.GROUP_MESSAGE.code) {
      // 处理消息
      this.handleIncomingMessage(data, code);
    }
    if (code === MessageType.VIDEO_MESSAGE.code) {
      // 处理视频消息
      callStore.handleCallMessage(data);
    }
    if (code === MessageType.REFRESHTOKEN.code) {
      // 刷新token
      userStore.refreshToken();
    }
  }

  /**
   * 处理收到的消息
   * @param message
   * @param code
   */
  async handleIncomingMessage(message: SingleMessage | GroupMessage, code: number) {
    if (settingStore.notification.message) {
      // 播放提示音
      play(AudioEnum.MESSAGE_ALERT);
      // 窗口最小化时
      if (await appIsMinimizedOrHidden()) {
        // 系统托盘闪烁
        flash(true);
      }
    }
    const id =
      code === MessageType.SINGLE_MESSAGE.code ? (message as SingleMessage).fromId : (message as GroupMessage).groupId;

    // 更新或创建会话
    chatStore.handleCreateOrUpdateChat(message, id as any);
    // 插入新消息
    messageStore.handleCreateMessage(id, message, code);
  }

  /* ---------------------- 销毁/清理 ---------------------- */

  /** 销毁管理器（退出时调用） */
  async destroy() {
    log.prettyInfo("core", "开始清理 MainManager 资源");
    try {
      // 取消 ws 订阅
      if (this.wsUnsub) {
        try {
          this.wsUnsub();
        } catch (e) {}
        this.wsUnsub = null;
      }

      // 断开/销毁 worker
      try {
        disconnect();
        // destroyWs();
      } catch (e) {
        // 忽略
      }

      // 如果需要，也可以清理其他资源
      log.prettySuccess("core", "清理完成");
    } catch (err) {
      log.prettyError("core", "destroy 出错", err);
    }
  }
}

/** hook */
export function useMainManager() {
  return MainManager.getInstance();
}
