import { StoresEnum } from "@/constants";
import api from "@/api/index";
//import { storage } from '@/utils/Storage'
import { useMappers } from "@/database";
import { storage } from "@/utils/Storage";

//import { genFriend, genFriends, genGroup, genGroups, toReactivePayload } from "@/mock/ShipMockData";

const { friendsMapper } = useMappers();

interface State {
  contacts: any[];
  groups: any[];
  shipInfo: any;
  newFriends: any[];
  type: "contacts" | "groups" | "newFriends" | "";
  ignore: boolean;
}

export const useFriendsStore = defineStore(StoresEnum.FRIENDS, {
  state: (): State => {
    return {
      contacts: [],
      groups: [],
      newFriends: [],
      shipInfo: {},
      type: "contacts",
      ignore: false
    };
  },
  getters: {
    /**
     * 获取总未读消息数
     * @returns 所有会话未读消息的总和
     */
    getTotalNewFriends: state => (state.ignore ? 0 : state.newFriends.length)
  },
  // 同步和异步皆可
  actions: {
    async loadNewFriends() {
      const newList =
        (await api.GetNewFriends({
          userId: storage.get("userId")
        })) || [];

      if (!Array.isArray(newList) || newList.length === 0) {
        console.info("群列表无更新");
        return;
      }
      if (this.ignore) {
        this.ignore = false;
      }
      this.newFriends = [...newList];
    },
    async loadGroups() {
      const newList =
        (await api.GetGroups({
          userId: storage.get("userId")
        })) || [];

      if (!Array.isArray(newList) || newList.length === 0) {
        console.info("群列表无更新");
        return;
      }
      // const groups = genGroups(20);
      this.groups = [...newList];
    },
    async loadContacts() {
      const newList =
        (await api.GetContacts({
          userId: storage.get("userId")
        })) || [];

      if (!Array.isArray(newList) || newList.length === 0) {
        console.info("好友列表无更新");
        return;
      }

      //const friends = genFriends(5000);
      this.contacts = [...newList];

      // try {
      //   // 1. 先从本地取出所有好友
      //   const localList = (await friendsMapper.selectList()) || [];
      //   if (!Array.isArray(localList)) {
      //     this.contacts = [];
      //   } else {
      //     this.contacts = localList;
      //   }

      //   // 2. 计算本地的最大 sequence，用于增量拉取
      //   const maxSeq = this.contacts.length > 0 ? Math.max(...this.contacts.map(f => f.sequence || 0)) : 0;

      //   // 3. 调用后端增量接口：只拉 sequence > maxSeq 的数据
      //   const userId = storage.get("userId");
      //   const newList =
      //     (await api.GetFriendList({
      //       userId,
      //       sequence: maxSeq
      //     })) || [];

      //   // 4. 如果没有新数据，就无需更新
      //   if (!Array.isArray(newList) || newList.length === 0) {
      //     console.info("好友列表无更新，sequence:", maxSeq);
      //     return;
      //   }

      //   // 5. 合并新数据
      //   //    假设后端只返回 sequence > maxSeq 的记录，直接 append 即可
      //   const merged = [...this.contacts, ...newList];

      //   // 6. 更新本地缓存
      //   //await friendsMapper.replaceAll(merged);
      //   friendsMapper.deleteById(storage.get("userId"));
      //   friendsMapper.batchInsert(merged); // 插入或更新好友数据
      //   this.contacts = merged;
      //   console.info(
      //     `新增 ${newList.length} 条好友关系，新的 maxSeq: ${Math.max(...merged.map(f => f.sequence || 0))}`
      //   );
      // } catch (error) {
      //   console.error("获取/更新好友列表失败：", error);
      //   // 出错时保持现有列表不变或清空
      //   this.contacts = this.contacts || [];
      // }
    },
    async handleGetFriendInfo(toId: string) {
      return (
        (await api.GetFriendInfo({
          fromId: storage.get("userId"),
          toId: toId
        })) || {}
      );
    }
  },
  persist: [
    {
      key: `${StoresEnum.FRIENDS}_local`,
      paths: ["ignore"],
      storage: localStorage
    },
    {
      key: `${StoresEnum.FRIENDS}_session`,
      paths: [],
      storage: sessionStorage
    }
  ]
});
