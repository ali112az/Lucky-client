// message.store.ts (重构版)
// 说明：保留原有外部接口与行为。主要做法：功能分区 + 重复逻辑提取为私有 helper。

import { defineStore } from "pinia";
import { StoresEnum, MessageType, MessageContentType } from "@/constants";
import api from "@/api/index";
import { useUserStore } from "./user";
import { useChatMainStore } from "./chat";
import { useMappers, FTSQueryBuilder, QueryBuilder, PageResult, Segmenter } from "@/database";
import { escapeHtml, highlightTextByTokens } from "@/utils/Strings";
import { CreateScreenWindow } from "@/windows/screen";
import SingleMessage from "@/database/entity/SingleMessage";
import GroupMessage from "@/database/entity/GroupMessage";
import { useIdleTaskExecutor } from "@/hooks/useIdleTaskExecutor";
import { storage } from "@/utils/Storage";

// mappers（DB 操作）
const { singleMapper, groupMapper } = useMappers();

// 其他 Store
const userStore = useUserStore();
const chatStore = useChatMainStore();

const logger = useLogger();

// 异步（空闲）任务执行器
const { addTask } = useIdleTaskExecutor({ maxWorkTimePerIdle: 12 });

/** Store 状态接口 */
interface State {
  messageList: Array<Record<string, any>>;
  historyMessageList: Array<Record<string, any>>;
  messageNum: number;
  messageSize: number;
  groupInfo: Record<string, any>;
  currentUrls: string[];
  messageCount: number;
  loading: boolean; // 全局 loading
  error: string | null; // 错误信息
}

export const useMessageStore = defineStore(StoresEnum.MESSAGE, {
  state: (): State => ({
    messageList: [],
    historyMessageList: [],
    messageNum: 1,
    messageSize: 15,
    groupInfo: {},
    currentUrls: [],
    messageCount: 0,
    loading: false,
    error: null
  }),

  getters: {
    remainingQuantity: state => Math.max(0, state.messageCount - state.messageNum * state.messageSize),
    // 当前用户id
    getOwnerId: () => userStore.userId || storage.get("userId")
  },

  actions: {
    /* ---------------------------
       初始化 / 重置
       --------------------------- */

    // 重置 Store（清空数据）
    handleReset() {
      Object.assign(this, {
        messageList: [],
        historyMessageList: [],
        messageNum: 1,
        messageCount: 0,
        currentUrls: [],
        groupInfo: {}
      });
    },

    /* ---------------------------
       发送消息（文本 / 文件）相关
       --------------------------- */

    /**
     * 发送消息入口：支持文件类（图片/视频/文件）优先上传并发送，文本逐条发送
     * 保持原有行为：文件逐个上传并发送；文本逐条 sendSingle
     */
    async handleSendMessage(messages: any[]) {
      if (!messages || messages.length === 0) return;
      const currentChat = chatStore.currentChat;
      if (!currentChat) {
        console.warn("没有当前会话，无法发送消息");
        return;
      }

      // 分类消息
      const fileMsgs = messages.filter(m => m.type === "image" || m.type === "video" || m.type === "file");
      const textMsgs = messages.filter(m => m.type === "text");

      // 1) 文件类逐个上传并发送（与原逻辑保持一致）
      for (const m of fileMsgs) {
        try {
          const file: File = m.file;
          if (!file) {
            console.warn("文件消息缺少 file 对象", m);
            continue;
          }
          const contentType =
            m.type === "image"
              ? MessageContentType.IMAGE.code
              : m.type === "video"
              ? MessageContentType.VIDEO.code
              : MessageContentType.FILE.code;

          // 不阻塞：但保留 await 行为以与原逻辑一致（你可以改为并发 Promise.all）
          await this.uploadAndSendFile(file, currentChat, contentType);
        } catch (e: any) {
          this.setError(e?.message || "上传并发送文件失败");
        }
      }

      // 2) 文本类逐条发送
      for (const m of textMsgs) {
        try {
          const form = this.handleCreateMessageContext({ text: m.content }, currentChat, MessageContentType.TEXT.code, {
            mentionedUserIds: Array.isArray(m.mentionedUserIds) ? m.mentionedUserIds : [],
            mentionAll: !!m.mentionAll,
            replyMessage: m.replyMessage
          });

          const apiFn = this._getSendApiByChat(currentChat);
          await this.sendSingle(form, currentChat, apiFn);
        } catch (e: any) {
          this.setError(e?.message || "发送文本消息失败");
        }
      }
    },

    /**
     * 发送单条（调用后端 API），成功后在 UI 创建本地消息并返回 res
     */
    async sendSingle(formData: any, currentChat: any, sendFn: Function) {
      try {
        const res = await sendFn(formData);
        // 保持原有行为：本地创建消息（用于即时显示）
        this.handleCreateMessage(currentChat.toId, res, currentChat.chatType, true);
        return res;
      } catch (e: any) {
        this.setError(e?.message || "sendSingle failed");
      }
    },

    /**
     * 上传文件并发送（上传后组装 message payload 并发送）
     * - 返回 uploadRes（如果需要）
     */
    async uploadAndSendFile(file: File, currentChat: any, contentType: number, opts: { retries?: number } = {}) {
      if (!file || !currentChat) {
        throw new Error("uploadAndSendFile 参数非法");
      }

      // 工具：取文件后缀
      const getExtension = (fileName: string) => {
        const idx = fileName.lastIndexOf(".");
        if (idx === -1 || idx === fileName.length - 1) return "";
        return fileName.slice(idx + 1).toLowerCase();
      };

      const formData = new FormData();
      formData.append("file", file);

      try {
        const uploadRes: any = await api.UploadFile(formData);

        // 组装发送表单并发送
        const form = this.handleCreateMessageContext(
          {
            ...uploadRes,
            size: file.size,
            suffix: getExtension(file.name)
          },
          currentChat,
          contentType
        );

        const apiFn = this._getSendApiByChat(currentChat);
        await this.sendSingle(form, currentChat, apiFn);

        return uploadRes;
      } catch (e: any) {
        this.setError(e?.message || "uploadAndSendFile failed");
      }
    },

    /**
     * 创建消息表单（公开 API，保留原名字）
     * meta 支持：mentionedUserIds、mentionAll、replyMessage
     */
    handleCreateMessageContext(content: any, chat: any, messageContentType: number, meta: any = {}) {
      return this._buildFormPayload(content, chat, messageContentType, meta);
    },

    /* ---------------------------
       拉取 / 分页 / 列表相关
       --------------------------- */

    // 加载更多历史消息（页码 + 调用获取列表）
    handleMoreMessage(): void {
      if (!chatStore.currentChat) return;
      this.messageNum++;
      this.handleGetMessageList(chatStore.currentChat);
    },

    /**
     * 获取当前会话消息（分页）
     */
    async handleGetMessageList(chat: any) {
      if (!chat) return;
      if (this.messageCount === 0) await this.handleGetMessageCount();

      const ownId = this.getOwnerId;
      const offset = (this.messageNum - 1) * this.messageSize;
      const isSingle = this._isSingle(chat);

      // 确保 currentChatGroupMemberMap 有默认值（避免访问 undefined）
      chatStore.currentChatGroupMemberMap = chatStore.currentChatGroupMemberMap || [];

      let messages: any[] = [];
      if (isSingle) {
        messages = await singleMapper.findMessage(ownId, chat.toId, offset, this.messageSize);
      } else {
        messages = await groupMapper.findMessage(ownId, chat.toId, offset, this.messageSize);
      }

      // 规范化消息并 prepend 到列表（保持原来把新批次放到前面的行为）
      const userInfo = userStore.userInfo;
      const normalized = messages.map(msg => this._normalizeMessageForUI(msg, ownId, userInfo, chat));
      this.messageList = [...normalized, ...this.messageList];
    },

    // 获取当前会话消息总数（异步）
    async handleGetMessageCount() {
      const chat = chatStore.currentChat;
      if (!chat) return;
      if (chat.chatType === MessageType.SINGLE_MESSAGE.code) {
        this.messageCount = await singleMapper.findMessageCount(chat.ownerId, chat.toId);
      } else {
        this.messageCount = await groupMapper.findMessageCount(chat.toId);
      }
    },

    /* ---------------------------
       创建 / 持久化消息（UI + DB + 索引）
       --------------------------- */

    /**
     * 在 UI 列表中创建消息（收到或自己发的）
     * - id 参数：当前会话的 toId（原代码）
     * - message：后端返回的 message 对象（格式与原代码保持一致）
     * - messageType：MessageType.SINGLE_MESSAGE.code | GROUP_MESSAGE.code
     * - isSender：是否本地发送者（用于触发会话更新）
     */
    handleCreateMessage(id: any, message: any, messageType: number, isSender: boolean = false) {
      const currentChat = chatStore.currentChat;

      // 仅当消息属于当前会话时才在 UI 列表中 push
      if (currentChat?.id === id) {
        const ownId = this.getOwnerId;
        const userInfo = userStore.userInfo;

        // 计算 name/avatar（单聊/群聊差异）
        let user: any = {};
        if (currentChat?.chatType === MessageType.SINGLE_MESSAGE.code) {
          user = { name: currentChat.name, avatar: currentChat.avatar };
        } else if (currentChat?.chatType === MessageType.GROUP_MESSAGE.code) {
          user = {
            name: chatStore.currentChatGroupMemberMap[message.fromId]?.name,
            avatar: chatStore.currentChatGroupMemberMap[message.fromId]?.avatar
          };
        }

        this.messageList.push({
          ...message,
          name: ownId === message.fromId ? userInfo.name : user?.name,
          avatar: ownId === message.fromId ? userInfo.avatar : user?.avatar,
          isOwner: ownId === message.fromId
        });

        // 如果是本地发送，触发更新会话（保持原行为）
        if (isSender) {
          chatStore.handleCreateOrUpdateChat(message, currentChat?.toId as any);
        }
      }

      this.handleInsertToDatabase(message, messageType);
    },

    /**
     * 将消息写入数据库 + 更新 FTS（索引）
     */
    async handleInsertToDatabase(message: any, messageType: number) {
      const record = this._toDbRecord(message);

      addTask(() => {
        if (messageType === MessageType.SINGLE_MESSAGE.code) {
          singleMapper.insert(record);
          const text = message.messageBody?.text;
          if (text) singleMapper.insertOrUpdateFTS({ ...record, messageBody: text });
        } else {
          groupMapper.insert(record);
          const text = message.messageBody?.text;
          if (text) groupMapper.insertOrUpdateFTS({ ...record, messageBody: text });
        }
      });
    },

    /* ---------------------------
       媒体 / 删除 / 更新 / 群成员相关
       --------------------------- */

    // 查询并收集媒体文件 URL
    async handleSearchMessageUrl(msg: any): Promise<void> {
      if (msg.messageType === MessageType.SINGLE_MESSAGE.code) {
        this.currentUrls = await singleMapper.findMessageUrl(msg.fromId, msg.toId);
      } else {
        this.currentUrls = await groupMapper.findMessageUrl(msg.groupId);
      }
    },

    // 删除消息（UI + DB + FTS）
    async handleDelectMessage(message: any) {
      this.messageList = this.messageList.filter((item: any) => item.messageId !== message.messageId);
      const id = message.messageId;
      if (message.messageType === MessageType.SINGLE_MESSAGE.code) {
        await singleMapper.deleteById(id);
        await singleMapper.deleteFTSById(id);
      } else {
        await groupMapper.deleteById(id);
        await groupMapper.deleteFTSById(id);
      }
    },

    // 添加群成员（API 调用）
    async handleAddGroupMember(membersList: string[], isSingle: boolean = false) {
      if (!membersList || membersList.length === 0) {
        console.warn("Members list is empty.");
        return;
      }
      const currentChat = chatStore.currentChat;
      const formData = {
        groupId: isSingle ? "" : currentChat?.id || "",
        userId: storage.get("userId") || "",
        memberIds: membersList,
        type: isSingle ? MessageType.SINGLE_MESSAGE.code : currentChat?.chatType || MessageType.SINGLE_MESSAGE.code
      };

      try {
        const res: any = await api.InviteGroupMember(formData);
        if (res) {
          console.log("Group members added successfully.");
        } else {
          console.warn("Failed to add group members:", res?.message || "Unknown error");
        }
      } catch (e: any) {
        this.setError(e?.message || "Error while adding group members:");
      }
    },

    // 更新消息（DB + UI）
    handleUpdateMessage(message: any, updata: any) {
      const type = parseInt(message.messageType, 10);
      if (type === MessageType.SINGLE_MESSAGE.code) {
        singleMapper.updateById(message.messageId, updata as any);
      } else {
        groupMapper.updateById(message.messageId, updata as any);
      }
      const messageIndex = this.messageList.findIndex(item => item.messageId == message.messageId);
      if (messageIndex != -1) {
        this.messageList[messageIndex] = { ...this.messageList[messageIndex], ...updata };
      }
    },

    /* ---------------------------
       工具 / UI 操作
       --------------------------- */

    handleShowScreeenShot() {
      CreateScreenWindow(screen.availWidth, screen.availHeight);
    },

    /* ---------------------------
       历史消息 / 搜索（保留骨架，便于后续补全）
       --------------------------- */

    /**
     * 历史消息查询  先查询索引索引库再查数据库
     * @param pageInfo 分页信息，包含 page 和 size
     * @param searchStr 可选的查询字符串或已分词结果 用于全文或模糊匹配（string | string[] | space-separated tokens）
     * @returns 格式化后的消息列表和总数
     */
    async handleHistoryMessage(
      pageInfo: PageResult<any>,
      searchStr?: string | string[]
    ): Promise<{ list: any[]; total: number }> {
      try {
        const currentChat = chatStore.currentChat;
        if (!currentChat?.id) {
          logger?.colorLog?.("history", "No current chat selected", "warn");
          return { list: [], total: 0 };
        }

        const ownId = this.getOwnerId;
        const toId = currentChat.id;
        if (!ownId || !toId) {
          logger?.colorLog?.("history", `Invalid ownId (${ownId}) or toId (${toId})`, "error");
          return { list: [], total: 0 };
        }

        const isSingle = currentChat.chatType === MessageType.SINGLE_MESSAGE.code;
        const searchMapper = isSingle ? singleMapper : groupMapper;
        if (!searchMapper) {
          logger?.colorLog?.("history", "Invalid search mapper", "error");
          return { list: [], total: 0 };
        }

        // ---------- 构建基础条件 ----------
        const qb = new FTSQueryBuilder<any>();
        const params: (string | number)[] = isSingle ? [ownId, toId, toId, ownId] : [ownId, toId];
        qb.raw(
          isSingle ? "((fromId = ? AND toId = ?) OR (fromId = ? AND toId = ?))" : "ownerId = ? AND groupId = ?",
          ...params
        ).orderByAsc("sequence");

        // ---------- 处理分词（searchStr 可能为 string[]、空格分隔string、或原始 string） ----------
        // 最终希望得到 tokens: string[]
        let tokens: string[] = [];
        if (Array.isArray(searchStr)) {
          tokens = searchStr.map(t => String(t));
        } else if (typeof searchStr === "string" && searchStr.trim().includes(" ")) {
          // 已是空格分隔的 tokens
          tokens = searchStr
            .trim()
            .split(/\s+/)
            .map(t => String(t));
        } else if (typeof searchStr === "string" && searchStr.trim()) {
          // 依然保留调用分词器的后备（如果传入的是原始未分词字符串）
          try {
            const segResult: string[] = await Segmenter.segment(searchStr);
            tokens = Array.isArray(segResult) ? segResult.map(t => String(t)) : [];
          } catch (e) {
            // 分词器失败时退回到按字符/空格拆分（中文按字符，英文按空白）
            const raw = String(searchStr || "").trim();
            if (/[\p{Script=Han}]/u.test(raw)) tokens = Array.from(raw);
            else tokens = raw.split(/\s+/).filter(Boolean);
          }
        }

        // 清理 tokens：trim、去掉引号、过滤空
        tokens = tokens.map(t => t.trim().replace(/["']/g, "")).filter(Boolean);

        // 构造 MATCH 表达式：每个 token 加 * 做前缀匹配，AND 连接（如需 OR 改为 join(" OR "))
        if (tokens.length > 0) {
          //const parts = tokens.map(t => `${t} `);
          const matchExpr = tokens.join(" ");

          qb.setMatchColumn("messageBody")
            .matchKeyword(matchExpr, "and")
            .addSnippetSelect("excerpt", "snippet({table}, 0, '<b>', '</b>', '...', 10)")
            .setRankingExpr("bm25({table})", "DESC");
          // .limit(20)
          // .offset(0);
          //qb.match("messageBody", matchExpr).and(q => q.isNotNull("messageBody"));
        } else {
          // 没有有效 token，至少过滤掉空 messageBody
          qb.isNotNull("messageBody");
        }

        // ---------- 执行 FTS5 分页查询 ----------
        const fts5RawPage = await searchMapper.searchFTS5Page(qb, pageInfo.page, pageInfo.size);
        const ids = fts5RawPage.records?.map((i: any) => i.messageId).filter(Boolean) ?? [];
        if (!ids.length) {
          return { list: [], total: fts5RawPage.total ?? 0 };
        }

        // ---------- 根据 ID 查询完整记录（按 messageTime 降序） ----------
        const rawPage = await searchMapper.selectByIds(ids, "messageTime", "desc");
        const records = Array.isArray(rawPage) ? rawPage : [];
        if (!records.length) {
          return { list: [], total: fts5RawPage.total ?? 0 };
        }

        // ---------- 构建群成员查找表 ----------
        const memberLookup = new Map<any, any>(
          (chatStore.getCurrentGroupMembersExcludeSelf ?? []).map(m => [m.userId, m])
        );

        const userInfo = userStore.userInfo ?? {};

        // ---------- 格式化结果并高亮 messageBody.text（若存在） ----------
        const formatted = records
          .map(item => {
            if (!item) return null;

            // 解析 messageBody（可能是 JSON 字符串或已对象）
            let body: any;
            try {
              body = typeof item.messageBody === "string" ? JSON.parse(item.messageBody) : item.messageBody;
            } catch (e) {
              logger?.colorLog?.(
                "history",
                `Failed to parse messageBody for messageId ${item.messageId}: ${(e as any)?.message ?? e}`,
                "warn"
              );
              body = { text: String(item.messageBody ?? "") };
            }

            // 高亮：只对 body.text 做高亮（若 tokens 存在）
            if (tokens.length > 0 && body && typeof body.text === "string") {
              // 默认使用 <mark> 包裹
              body.text = highlightTextByTokens(body.text, tokens);
            } else if (body && typeof body.text === "string") {
              body.text = escapeHtml(body.text);
            }
            const isOwner = ownId === item.fromId;
            const member = isSingle ? null : memberLookup.get(item.fromId);
            const name = isOwner ? userInfo.name : isSingle ? currentChat.name : member?.name ?? "未知";
            const avatar = isOwner ? userInfo.avatar : isSingle ? currentChat.avatar : member?.avatar ?? "";

            // 返回并用 messageBody 替换为已解析对象（text 已被 HTML 转义/高亮）
            return { ...item, messageBody: body, name, avatar, isOwner };
          })
          .filter((it): it is NonNullable<typeof it> => !!it);

        return { list: formatted, total: fts5RawPage.total ?? 0 };
      } catch (err) {
        logger?.colorLog?.("history", `handleHistoryMessage error: ${(err as any)?.message ?? err}`, "error");
        return { list: [], total: 0 };
      }
    },

    async handleSearchMessage(searchStr?: string, global: boolean = false) {
      // TODO: 全局/会话内搜索入口（先查索引，再回表）
    },

    /* ---------------------------
       私有 Helper（提取重复逻辑）
       --------------------------- */

    // 判断 chat 是否单聊
    _isSingle(chat: any): boolean {
      return chat && chat.chatType === MessageType.SINGLE_MESSAGE.code;
    },

    // 根据会话类型返回对应的 mapper（single/group）
    _getMapperByType(messageType: number) {
      return messageType === MessageType.SINGLE_MESSAGE.code ? singleMapper : groupMapper;
    },

    // 根据当前会话类型返回对应的发送 API（单聊/群聊）
    _getSendApiByChat(chat: any) {
      return chat.chatType === MessageType.SINGLE_MESSAGE.code ? api.SendSingleMessage : api.SendGroupMessage;
    },

    // 构建 message 表单 payload（抽取重复字段）
    _buildFormPayload(content: any, chat: any, messageContentType: number, meta: any = {}) {
      const chatType = chat?.chatType;
      const toKey = chatType === MessageType.SINGLE_MESSAGE.code ? "toId" : "groupId";
      const base = {
        fromId: this.getOwnerId,
        messageBody: content,
        messageTempId: generateTempId("msg"),
        messageTime: Date.now(),
        messageContentType,
        messageType: chatType,
        [toKey]: chat?.id || ""
      };

      const payload: any = { ...base };
      if (meta) {
        if (Array.isArray(meta.mentionedUserIds) && meta.mentionedUserIds.length > 0) {
          payload.mentionedUserIds = Array.from(new Set(meta.mentionedUserIds));
        }
        if (typeof meta.mentionAll === "boolean") payload.mentionAll = meta.mentionAll;
        if (meta.replyMessage && typeof meta.replyMessage === "object") payload.replyMessage = meta.replyMessage;
      }
      return payload;
    },

    // 将消息对象序列化为 DB 要存的 record（移除临时 id）
    _toDbRecord(message: any) {
      const ownerId = this.getOwnerId;
      const record = { ...message, ownerId, messageBody: JSON.stringify(message.messageBody) };
      if (record.messageTempId) delete record.messageTempId;
      return record;
    },

    // 处理单条消息对象（解析 body、注入 name/avatar/isOwner）
    _normalizeMessageForUI(msg: any, ownId: string, userInfo: any, chat: any) {
      const isSystemMessage = msg.fromId === "000000";
      const body = typeof msg.messageBody === "string" ? JSON.parse(msg.messageBody) : msg.messageBody;
      const name = isSystemMessage
        ? null
        : ownId === msg.fromId
        ? userInfo.name
        : chatStore.currentChatGroupMemberMap[msg.fromId]?.name || chat.name;
      const avatar = isSystemMessage
        ? null
        : ownId === msg.fromId
        ? userInfo.avatar
        : chatStore.currentChatGroupMemberMap[msg.fromId]?.avatar || chat.avatar;

      return {
        ...msg,
        messageBody: body,
        name,
        avatar,
        isOwner: ownId === msg.fromId
      };
    },

    /**
     * store错误日志输出，可拓展日志上报
     * @param err
     */
    setError(err: string | null) {
      this.error = err;
      if (err) logger.error?.("[chat-store] error:", err);
    },

    // 根据 messageType 返回 API 调用/mapper 等（用于插入/更新/删除）
    _chooseByMessageType(messageType: number) {
      if (messageType === MessageType.SINGLE_MESSAGE.code) {
        return { mapper: singleMapper, isSingle: true };
      } else {
        return { mapper: groupMapper, isSingle: false };
      }
    }
  },

  persist: [
    { key: `${StoresEnum.MESSAGE}_local`, paths: ["messageList"], storage: localStorage },
    { key: `${StoresEnum.MESSAGE}_session`, paths: ["messageCount"], storage: sessionStorage }
  ]
});

/* ---------------------------
   Module-level Helper (未改变的工具函数)
   --------------------------- */

/** 解析 messageBody（兼容异常） */
function parseMessageBody(body: string) {
  try {
    return JSON.parse(body);
  } catch {
    return { message: body };
  }
}

/** 根据 messageContentType 返回 preview 文本（保留原映射） */
function formatPreview(content: any) {
  const code = parseInt(content.messageContentType, 10);
  if (code === MessageContentType.TEXT.code) return content.messageBody.text;
  return (
    {
      [MessageContentType.IMAGE.code]: "[图片]",
      [MessageContentType.VIDEO.code]: "[视频]",
      [MessageContentType.AUDIO.code]: "[语音]",
      [MessageContentType.FILE.code]: "[文件]",
      [MessageContentType.LOCAL.code]: "[位置]"
    }[code] || "未知消息类型"
  );
}

/** 生成临时 message id（短且较唯一） */
function generateTempId(prefix = "tmp") {
  return `${prefix}-${Date.now()}-${Math.floor(Math.random() * 1000000)}`;
}

/** 简单延迟 */
function delay(ms: number) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
