import { defineStore } from "pinia";
import { StoresEnum } from "@/constants";
import api from "@/api/index";
import Chats from "@/database/entity/Chats";
import SingleMessage from "@/database/entity/SingleMessage";
import GroupMessage from "@/database/entity/GroupMessage";
import { QueryBuilder } from "@/database";
import { useUserStore } from "./user";
import { useMappers } from "@/database";
import { ShowMainWindow } from "@/windows/main";
import { storage } from "@/utils/Storage";
import { useTray } from "@/hooks/useTray";
import { useChatInput } from "@/hooks/useChatInput";
import { MessageType } from "@/constants";
import { useIdleTaskExecutor } from "@/hooks/useIdleTaskExecutor";

const { chatsMapper } = useMappers();
const userStore = useUserStore();
const { flash } = useTray();
const logger = useLogger();
const { buildMessagePreview, buildDraftMessagePreview, findChatIndex, removeMentionHighlightsFromHtml } =
  useChatInput();

// 异步（空闲）任务执行器
const { addTask } = useIdleTaskExecutor({ maxWorkTimePerIdle: 12 });

// 简单的成员类型
type User = { userId: string; name: string; avatar?: string | null };

/**
 * 聊天主存储（Pinia）
 * 管理：会话列表 / 当前会话 / 消息预览 / 未读数 / 置顶 / 本地持久化等
 */
interface State {
  chatList: Chats[]; // 会话列表
  currentChat: Chats | null; // 当前会话
  currentChatGroupMemberMap: any[]; // 当前群成员列表（供 name 映射）
  isShowDetail: boolean; // 是否显示详情面板
  ignoreAllList: string[]; // 忽略提醒的会话ID列表
  chatDraftMap?: Record<string, any>; // 会话草稿列表
  loading: boolean; // 全局 loading
  error: string | null; // 错误信息
}

/**
 * Chat 主 store（重构版）
 * - 结构化：把重复逻辑提取到私有方法（_ 开头）
 * - 保持原有 API 与持久化配置（兼容老逻辑）
 */
export const useChatMainStore = defineStore(StoresEnum.CHAT, {
  state: (): State => ({
    chatList: [],
    currentChat: null,
    currentChatGroupMemberMap: [],
    isShowDetail: false,
    ignoreAllList: [],
    chatDraftMap: {},
    loading: false,
    error: null
  }),

  getters: {
    // 当前会话名称
    getCurrentName: state => state.currentChat?.name || "",

    // 按 id 获取会话（返回对象或 null）
    getChatById: state => (id: string | number) => {
      return (state.chatList || []).find((c: Chats) => c.chatId === id) ?? null;
    },

    // 当前会话类型（直接返回 chatType，便于判断）
    getCurrentType: state => state.currentChat?.chatType,
    // 总未读
    getTotalUnread: state => state.chatList.reduce((s, c) => s + (c.unread || 0), 0),
    // 是否有当前会话（用于显示详情按钮）
    getShowDetailBtn: state => !!state.currentChat,
    // 是否显示详情
    getShowDetail: state => state.isShowDetail,
    // 有未读且非忽略的会话（注意：忽略逻辑可在前端扩展）
    getHaveMessageChat: state => state.chatList.filter(c => c.unread > 0),
    // 当前会话是否是群聊
    getChatIsGroup: state =>
      state.currentChat ? state.currentChat.chatType === MessageType.GROUP_MESSAGE.code : false,
    // 当前用户
    getOwnerId: () => userStore.userId || storage.get("userId"),
    /**
     * 返回当前群成员列表（排除自己）
     * 支持 currentChatGroupMemberList 为：数组 / 对象字典 / JSON 字符串 / 仅 id 的数组
     */
    getCurrentGroupMembersExcludeSelf(): User[] {
      const raw = this.currentChatGroupMemberMap;
      const me = this.getOwnerId;

      // 规范化 raw -> 数组
      let arr: any[] = [];
      if (!raw) arr = [];
      else if (Array.isArray(raw)) arr = raw;
      else if (typeof raw === "object") arr = Object.values(raw);
      else arr = [];

      const mapMember = (m: any): User | null => {
        if (m == null) return null;
        if (typeof m === "string" || typeof m === "number") {
          const id = String(m);
          return { userId: id, name: id, avatar: null };
        }
        const id = m.userId ?? m.id ?? m.uid ?? m.user_id ?? null;
        if (id == null) return null;
        const name = m.name ?? m.nick ?? m.nickname ?? m.displayName ?? m.username ?? String(id);
        const avatar = m.avatar ?? m.avatarUrl ?? m.img ?? m.head ?? null;
        return { userId: String(id), name: String(name ?? ""), avatar: avatar != null ? String(avatar) : null };
      };

      const result = arr.map(mapMember).filter((x): x is User => x != null && String(x.userId) !== String(me));
      return result;
    }
  },

  actions: {
    /* -------------------- 对外公开 API（原有方法名保持不变） -------------------- */

    // 初始化
    async handleInit() {
      this.setLoading(true);
      try {
        if (!this.chatList || this.chatList.length === 0) {
          const data = await chatsMapper.selectList();
          if (Array.isArray(data) && data.length > 0) {
            this.chatList = data;
          }
        }
        this.setError(null);
      } catch (e: any) {
        this.setError(e?.message || "初始化会话列表失败");
      } finally {
        this.setLoading(false);
      }
    },

    /**
     * 设置当前会话（保持引用到 chatList 内的对象）
     * - 保存草稿、去除 mention 高亮、排序
     */
    async handleChangeCurrentChat(chatOrId: Chats | string | number): Promise<void> {
      try {
        this.saveDraftAsPreview();

        if (!chatOrId) {
          this.currentChat = null;
          return;
        }

        let idx = -1;
        if (typeof chatOrId === "object" && (chatOrId as Chats).chatId) {
          idx = this._findChatIndexLocal((chatOrId as Chats).chatId);
        } else {
          idx = this._findChatIndexLocal(chatOrId as string | number);
        }

        if (idx === -1) {
          if (typeof chatOrId === "object") {
            const newIdx = this._upsertChat(chatOrId as Chats);
            this.currentChat = this.chatList[newIdx];
          } else {
            this.currentChat = null;
            this.setError("会话不存在");
          }
        } else {
          const chat = this.chatList[idx];
          // 从 DB 获取最新消息并去除 mention 高亮（fallback 不影响显示）
          try {
            const dbChat: Chats | null = await chatsMapper.selectById(chat.chatId);
            if (dbChat) {
              chat.message = removeMentionHighlightsFromHtml(dbChat.message, {
                returnPlainText: true
              });
            }
          } catch (e) {
            logger.warn("[chat-store] removeMentionHighlights failed", e);
          }
          this.currentChat = chat;

          if (this.getChatIsGroup) {
            let res: any = await api.GetGroupMember({ groupId: this.currentChat.toId });
            // 检查 res 数据，并赋值给 currentChatGroupMemberMap
            this.currentChatGroupMemberMap = res || {};
          }
          this.handleSortChatList();
        }
      } catch (e: any) {
        this.setError(e?.message || "设置当前会话失败");
      }
    },

    /**
     * 更新会话未读数（并持久化到数据库）
     */
    async handleUpdateReadStatus(chat: Chats, unread: number = 0): Promise<void> {
      if (!chat) return;
      const idx = this._findChatIndexLocal(chat.chatId);
      if (idx === -1) {
        this.setError("会话未找到");
        return;
      }
      this.chatList[idx].unread = unread;
      try {
        await chatsMapper.updateById(chat.chatId, { unread } as Chats);
      } catch (e: any) {
        logger.error("[chat-store] update unread fail", e);
      }
    },

    async handleCurrentChangeByFriend(friendInfo: { friendId: string | number; [k: string]: any }, chatType: number) {
      const fromId = this.getOwnerId;
      const friendId = friendInfo.friendId;
      const existingIdx = this.chatList.findIndex(c => c.toId === friendId && c.chatType === chatType);
      if (existingIdx !== -1) {
        await this.handleUpdateReadStatus(this.chatList[existingIdx], 0);
        this.currentChat = this.chatList[existingIdx];
        return;
      }

      try {
        this.setLoading(true);
        const res = (await api.CreateChat({ fromId, toId: friendId, chatType })) as Chats;
        if (!res) throw new Error("创建会话失败");
        this.handleUpdateChatWithMessage(res);
        this._upsertChat(res);
        this.handleSortChatList();
        this.currentChat = res;
        this.setError(null);
      } catch (e: any) {
        this.setError(e?.message || "创建会话失败");
      } finally {
        this.setLoading(false);
      }
    },

    async handleCurrentChangeByGroup(groupInfo: { groupId: string | number; [k: string]: any }, chatType: number) {
      const fromId = this.getOwnerId;
      const groupId = groupInfo.groupId;
      const existingIdx = this.chatList.findIndex(c => c.toId === groupId && c.chatType === chatType);
      if (existingIdx !== -1) {
        await this.handleUpdateReadStatus(this.chatList[existingIdx], 0);
        this.currentChat = this.chatList[existingIdx];
        return;
      }

      try {
        this.setLoading(true);
        const res = (await api.CreateChat({ fromId, toId: groupId, chatType })) as Chats;
        if (!res) throw new Error("创建会话失败");
        this.handleUpdateChatWithMessage(res);
        this._upsertChat(res);
        this.handleSortChatList();
        this.currentChat = res;
        this.setError(null);
      } catch (e: any) {
        this.setError(e?.message || "创建会话失败");
      } finally {
        this.setLoading(false);
      }
    },

    /**
     * 收到消息后更新或创建会话
     * - 保持原有行为：若本地没有则从 DB / 服务端拉取
     */
    async handleCreateOrUpdateChat(message: SingleMessage | GroupMessage | undefined, id: string | number) {
      const ownerId = this.getOwnerId;
      const qb = new QueryBuilder<Chats>().select().and(q => q.eq("ownerId", ownerId).eq("toId", id));

      try {
        this.setLoading(true);

        // 1) 先从本地 DB 查询
        const chats: Chats[] | null = await chatsMapper.selectList(qb);

        if (Array.isArray(chats) && chats.length > 0) {
          const chatFromDb = chats[0];
          const idx = this._findChatIndexLocal(chatFromDb.chatId);

          if (idx !== -1) {
            // 本地已经有 -> 更新该会话预览
            this.handleUpdateChatWithMessage(this.chatList[idx], message);
            if ((this.chatList[idx] as any).messageContentType) delete (this.chatList[idx] as any).messageContentType;
          } else {
            // DB 有但内存没有 -> 合并并 upsert 到内存
            this.handleUpdateChatWithMessage(chatFromDb, message, true);
            if ((chatFromDb as any).messageContentType) delete (chatFromDb as any).messageContentType;
            this._upsertChat(chatFromDb);
          }
        } else {
          // 2) DB 无 -> 从服务端拉取会话信息
          const res = await this._fetchChatFromServer(ownerId, id);
          if (res) {
            this.handleUpdateChatWithMessage(res, message, true);
            if ((res as any).messageContentType) delete (res as any).messageContentType;
            this._upsertChat(res);
          }
        }

        this.handleSortChatList();
        this.setError(null);
      } catch (err: any) {
        this.setError(err?.message || "创建或更新会话失败");
        logger.error("[chat-store] handleCreateOrUpdateChat error", err);
      } finally {
        this.setLoading(false);
      }
    },

    /**
     * 根据 message 更新会话 preview / unread 等（核心合并逻辑）
     * - 保持原有逻辑：若目标不是当前会话且不是 isNew -> unread++ 并触发托盘闪烁
     * - 异步持久化 preview（不阻塞主流程）
     */
    handleUpdateChatWithMessage(chat: Chats, message?: SingleMessage | GroupMessage, isNew: boolean = false) {
      if (!chat) return;

      try {
        if (message) {
          const preview = this._buildPreviewFromMessage(message, true);

          if (preview) {
            // 非当前会话并且不是新会话 -> 新增未读并设置 HTML preview（带高亮）
            if (String(chat.toId) !== String(this.currentChat?.toId) && !isNew) {
              chat.unread = (chat.unread || 0) + 1;
              chat.message = preview.html;
              try {
                flash(true);
              } catch (e) {
                logger.warn("[chat-store] flash tray failed", e);
              }
            } else {
              // 当前会话：显示纯文本 preview
              chat.message = preview.plainText;
            }

            chat.messageTime = message.messageTime || Date.now();
            chat.sequence = message.messageTime || Date.now();

            // 持久化（写入 original 或 plainText）
            this._persistPreviewToDb({
              ...chat,
              message: preview.originalText == "" ? preview.plainText : preview.originalText
            });
          } else {
            // 无法生成 preview 的兜底逻辑
            chat.message = "";
            chat.messageTime = message.messageTime || Date.now();
            chat.sequence = message.messageTime || Date.now();
            this._persistPreviewToDb({ ...chat, message: "" });
          }
        } else {
          // 无 message => 清空 preview
          chat.message = "";
          chat.messageTime = Date.now();
          chat.sequence = Date.now();
          chat.unread = 0;
          this._persistPreviewToDb({ ...chat, message: "" });
        }
      } catch (e: any) {
        logger.error("[chat-store] handleUpdateChatWithMessage error", e);
      }
    },

    /**
     * 删除会话
     * @param chat
     * @returns
     */
    async handleDeleteChat(chat: Chats) {
      if (!chat) return;
      const idx = this._findChatIndexLocal(chat.chatId);
      if (idx !== -1) {
        try {
          await chatsMapper.deleteById(chat.chatId);
        } catch (e) {
          logger.warn("[chat-store] delete chat db fail", e);
        }
        this.chatList.splice(idx, 1);
      }
      if (this.currentChat?.chatId === chat.chatId) {
        this.currentChat = null;
      }
    },

    /**
     * 删除消息部分字段
     * @param message
     */
    handleDeleteMessage(message: SingleMessage | GroupMessage) {
      if (message && (message as any).messageContentType) {
        delete (message as any).messageContentType;
      }
    },

    /**
     * 置顶会话
     * @param chat
     * @returns
     */
    async handlePinChat(chat: Chats) {
      if (!chat) return;
      try {
        const idx = this._findChatIndexLocal(chat.chatId);
        if (idx === -1) return;
        const newTop = (this.chatList[idx].isTop || 0) === 1 ? 0 : 1;
        this.chatList[idx].isTop = newTop;
        await chatsMapper.updateById(chat.chatId, { isTop: newTop } as Chats);
        this.handleSortChatList();
      } catch (e: any) {
        this.setError(e?.message || "更新置顶状态失败");
        throw e;
      }
    },

    /**
     * 会话排序
     * @param customList
     */
    handleSortChatList(customList?: Chats[]) {
      const list = customList || this.chatList;
      this.chatList = [...list].sort((a, b) => {
        const topDiff = (b.isTop || 0) - (a.isTop || 0);
        if (topDiff !== 0) return topDiff;
        return (b.messageTime || 0) - (a.messageTime || 0);
      });
    },

    /**
     * 会话忽略
     */
    handleIgnoreAll() {
      for (const item of this.getHaveMessageChat) {
        const id = String(item.chatId);
        if (!this.ignoreAllList.includes(id)) {
          this.ignoreAllList.push(id);
        }
      }
      logger.info("[chat-store] ignore all messages");
    },

    /**
     * 会话跳转
     */
    async handleJumpToChat() {
      if (this.currentChat) {
        try {
          ShowMainWindow();
        } catch (e) {
          logger.warn("[chat-store] open main window fail", e);
        }
      }
    },

    /**
     * 根据ID获取聊天
     * @param id 聊天ID
     */
    handleGetChat(id: any): Chats | undefined {
      return this.chatList.find(c => c.id === id);
    },

    /**
     * 保存会话输入草稿状态
     * @returns
     */
    async saveDraftAsPreview() {
      const chatId = this.currentChat?.chatId;
      if (!chatId) return;

      const draftHtml = this.getDraft(chatId);
      if (!draftHtml) return;

      const preview = buildDraftMessagePreview(String(chatId), draftHtml ?? "");
      if (preview) {
        const stub: Partial<any> = {
          chatId,
          message: preview,
          messageTime: Date.now()
        };
        try {
          this._upsertChat(stub as any);
          // 非阻塞持久化（与原逻辑一致）
          //this._persistPreviewToDb(stub);
        } catch (err: any) {
          logger.warn("[chat-store] saveDraftAsPreview failed", err);
        }
      }
    },

    setDraft(chatId: string | number, html: string) {
      if (!chatId) return;
      const id = String(chatId);
      if (!(this as any).chatDraftMap) (this as any).chatDraftMap = {};
      (this as any).chatDraftMap[id] = html ?? "";
    },

    getDraft(chatId: string | number) {
      if (!chatId) return "";
      return ((this as any).chatDraftMap || {})[String(chatId)] || undefined;
    },

    clearDraft(chatId: string | number) {
      if (!chatId) return;
      const id = String(chatId);
      if ((this as any).chatDraftMap && id in (this as any).chatDraftMap) {
        delete (this as any).chatDraftMap[id];
      }
    },

    setLoading(flag: boolean) {
      this.loading = !!flag;
    },

    /**
     * store错误日志输出，可拓展日志上报
     * @param err
     */
    setError(err: string | null) {
      this.error = err;
      if (err) logger.error?.("[chat-store] error:", err);
    },

    handleChatDetail() {
      this.isShowDetail = !this.isShowDetail;
    },

    /* -------------------- 私有辅助方法（提取重复逻辑） -------------------- */

    // 在本地 chatList 中查找索引（优先使用 hook）
    _findChatIndexLocal(chatId: string | number) {
      try {
        return findChatIndex(this.chatList, chatId);
      } catch (e) {
        return this.chatList.findIndex(c => c.chatId === chatId);
      }
    },

    // 把 chat 插入或更新到 this.chatList（保持引用一致性）
    _upsertChat(chat: Partial<Chats> & { chatId?: any }): number {
      if (!chat || chat.chatId == null) return -1;
      const idx = this._findChatIndexLocal(chat.chatId);
      if (idx !== -1) {
        // 合并更新已有项（保留响应性）
        this.chatList[idx] = Object.assign({}, this.chatList[idx], chat);
        return idx;
      } else {
        // 新增
        this.chatList.push(chat as Chats);
        return this.chatList.length - 1;
      }
    },

    // 将 preview 写入 DB（非阻塞），封装日志
    _persistPreviewToDb(chatObj: Partial<Chats>) {
      if (!chatObj || !chatObj.chatId) return;

      addTask(() => {
        chatsMapper.insertOrUpdate(chatObj).catch(err => logger.warn("[chat-store] persist preview fail", err));

        chatsMapper.insertOrUpdateFTS(chatObj);
      });
    },

    // 根据 message 构建 preview（可复用）
    _buildPreviewFromMessage(message?: SingleMessage | GroupMessage, asHtml = true) {
      if (!message) return null;
      try {
        return buildMessagePreview(message, {
          currentUserId: this.getOwnerId,
          highlightClass: "mention-highlight",
          asHtml
        });
      } catch (e) {
        logger.warn("[chat-store] buildMessagePreview failed", e);
        return null;
      }
    },

    // 请求服务端拉取 chat（封装网络调用与错误处理）
    async _fetchChatFromServer(ownerId: string | number, toId: string | number) {
      try {
        const res = (await api.GetChat({ fromId: ownerId, toId })) as Chats;
        if (!res) throw new Error("拉取会话信息失败");
        return res;
      } catch (err: any) {
        logger.warn("[chat-store] GetChat failed", err);
        this.setError(err?.message || "拉取会话信息失败");
        return null;
      }
    }
  },

  persist: [
    {
      key: `${StoresEnum.CHAT}_local`,
      paths: ["chatDraftMap", "currentChatGroupMemberMap", "ignoreAllList"],
      storage: localStorage
    },
    {
      key: `${StoresEnum.CHAT}_session`,
      paths: ["chatList", "currentChat"],
      storage: sessionStorage
    }
  ],

  sync: {
    paths: ["chatList"],
    targetWindows: [StoresEnum.NOTIFY],
    sourceWindow: StoresEnum.MAIN
  }
});
