<template>
    <div 
        class="context-menu"
        :style="{
            left: adjustedPosition.x + 'px',
            top: adjustedPosition.y + 'px'
        }"
        @click.stop
    >
        <div 
            v-for="option in options" 
            :key="option.value"
            class="menu-item"
            @click="handleSelect(option.value)"
        >
            {{ option.label }}
        </div>
    </div>
</template>

<script setup lang="ts">
import { computed } from 'vue';

interface MenuOption {
    label: string;
    value: string;
}

const props = defineProps<{
    x: number;
    y: number;
    options: MenuOption[];
}>();

const emit = defineEmits<{
    (e: 'select', value: string): void;
    (e: 'close'): void;
}>();

// 计算菜单位置，确保不会超出窗口
const adjustedPosition = computed(() => {
    if (typeof window === 'undefined') return { x: 0, y: 0 };

    const menu = document.querySelector('.context-menu');
    if (!menu) return { x: props.x, y: props.y };

    const menuRect = menu.getBoundingClientRect();
    const windowWidth = window.innerWidth;
    const windowHeight = window.innerHeight;

    let x = props.x;
    let y = props.y;

    // 检查右边界
    if (x + menuRect.width > windowWidth) {
        x = windowWidth - menuRect.width;
    }

    // 检查下边界
    if (y + menuRect.height > windowHeight) {
        y = windowHeight - menuRect.height;
    }

    return { x, y };
});

const handleSelect = (value: string) => {
    emit('select', value);
};
</script>

<style scoped>
.context-menu {
    position: fixed;
    background: white;
    border: 1px solid #ddd;
    border-radius: 4px;
    padding: 4px 0;
    min-width: 120px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
    z-index: 9999;
    pointer-events: auto;
}

.menu-item {
    padding: 8px 16px;
    cursor: pointer;
    transition: background-color 0.2s;
    white-space: nowrap;
}

.menu-item:hover {
    background-color: #f5f5f5;
}
</style>