<template>
    <div class="new-msg-list-div" id="new-msg-list-div">
        <div class="content-div">
            <div class="title">
                新消息（{{ totalNumber }}）
            </div>
            <div class="list-div" v-if="listData.length">
                <div class="list-item" v-for="(item, index) in listData" :key="item.name" @click="onRead(item)">
                    <div class="content">
                        <div class="avator-div">
                            <img :src="item.avator" :class="`avator lazy-img`">
                        </div>
                        <div class="name-div">
                            <span class="name">{{ item.name }}</span>
                        </div>
                    </div>
                    <div class="msg-num">{{ item.number }}</div>
                </div>
            </div>
        </div>
        <div class="footer" @click="onIgnoreAll">忽略全部</div>
    </div>
</template>

<script setup >

// 状态
const listData = ref([
    {
        chatType: 0,
        name: "小红",
        avator: "https://img1.baidu.com/it/u=3285655239,3777030402&fm=253&fmt=auto&app=120&f=JPEG?w=507&h=500",
        number: 1,
    },
    {
        chatType: 2,
        name: "开发小组群",
        avator: "https://img2.baidu.com/it/u=1320604647,1678798061&fm=253&fmt=auto&app=120&f=JPEG?w=500&h=500",
        number: 2,
    },
    {
        chatType: 1,
        name: "小蓝",
        avator: "https://img0.baidu.com/it/u=1784421616,2414549464&fm=253&fmt=auto&app=120&f=JPEG?w=500&h=500",
        number: 3,
    },
]);

/**
 * 计算未读消息总数
 */
const totalNumber = computed(() => {
    let count = 0
    listData.value.forEach((item) => {
        count += item.number;
        //item.number = 0;
    });
    return count;
})


function onRead(msg) {
    console.log('Message read:', msg);
}

function onIgnoreAll() {
    console.log('All messages ignored');
}

// 组件挂载时执行
onMounted(() => {
    //createListDom()
    //updateTitleNumber()
});
</script>

<style lang="scss" scoped>
.new-msg-list-div {
    font-size: 12px;
    cursor: context-menu;
}

.new-msg-list-div .content-div {
    border-bottom: solid 1px #dedede;
}

.new-msg-list-div .content-div .title {
    line-height: 34px;
    font-weight: bold;
    padding: 0 20px;
}

.new-msg-list-div .content-div .list-div {
    max-height: 400px;
    overflow-y: auto;
    scrollbar-width: none;
    /*设置火狐浏览器不显示滚动条*/

}

.new-msg-list-div .content-div .list-div::-webkit-scrollbar {
    /*设置谷歌浏览器不显示滚动条*/
    width: 0;
    height: 0;
    background-color: transparent;
}

.new-msg-list-div .content-div .list-div .list-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 6px 20px;
    border-bottom: solid 1px #eee;

}

.new-msg-list-div .content-div .list-div .list-item:hover {
    background-color: #e8e8e8;

}

.new-msg-list-div .content-div .list-div .list-item .content {
    display: flex;
    align-items: center;
}

.new-msg-list-div .content-div .list-div .list-item .content .avator-div {
    width: 34px;
    height: 34px;
    background-color: #eee;
    margin-right: 10px;
    display: flex;
    align-items: center;
    flex-wrap: wrap-reverse;
    justify-content: center;
    overflow: hidden;
    align-content: center;
    border-radius: 0px;
    flex-shrink: 0;

}

.new-msg-list-div .content-div .list-div .list-item .content .avator-div .avator {
    width: 100%;
    height: 100%;
    border-radius: 2px;
    font-size: 18px;
    display: flex;
    justify-content: center;
    align-items: center;
    color: #fff;

}


.new-msg-list-div .content-div .list-div .list-item .content .name-div {
    display: flex;
    align-items: center;
}

.new-msg-list-div .content-div .list-div .list-item .content .name {
    font-weight: bold;
    max-width: 90px;
    text-overflow: ellipsis;
    overflow: hidden;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    word-break: break-word;
}

.new-msg-list-div .content-div .list-div .list-item .msg-num {
    color: #fff;
    background-color: red;
    padding: 0 8px;
    border-radius: 100px;
}

.new-msg-list-div .footer {
    line-height: 34px;
    padding: 0 20px;
    text-align: right;
    color: #586cb1;
    cursor: pointer;
}
</style>