<template>
    <div class="markdown-preview-container">
        <div class="markdown-body preview" v-dompurify="renderedHtml"></div>
    </div>
</template>

<script setup lang="ts">
import { ref, computed, watch, onMounted, nextTick } from 'vue';
import MarkdownIt from 'markdown-it';
import 'github-markdown-css';

// 接收外部 Markdown 文件 URL
const props = defineProps<{ src?: string }>();
// 定义渲染完成、错误事件
const emit = defineEmits<{
    (e: 'rendered'): void;
    (e: 'error', err: unknown): void;
}>();

// 初始化 Markdown-it
const mdParser = new MarkdownIt({ html: true, linkify: true, typographer: true });

// 文本内容
const markdownText = ref<string>('');

// 实时渲染 HTML
const renderedHtml = computed(() => mdParser.render(markdownText.value));

// 监听渲染完成
watch(renderedHtml, async () => {
    // nextTick 确保 DOM 已更新
    await nextTick();
    emit('rendered');
});

// 监听 src 变更，fetch Markdown
async function loadFromUrl(url: string) {
    try {
        const res = await fetch(url);
        markdownText.value = await res.text();
    } catch (e) {
        markdownText.value = '';
        emit('error', e);
    }
}

// 初始化
onMounted(() => {
    if (props.src) {
        loadFromUrl(props.src)
            .catch(err => emit('error', err));
    }
});
</script>

<style lang="scss" scoped>
/* 滚动条样式 */
@mixin scroll-bar($width: 5px) {
    &::-webkit-scrollbar-track {
        border-radius: 10px;
        background-color: transparent;
    }

    &::-webkit-scrollbar {
        width: $width;
        height: 10px;
        background-color: transparent;
        transition: opacity 0.3s ease;
    }

    &::-webkit-scrollbar-thumb {
        border-radius: 10px;
        background-color: rgba(0, 0, 0, 0.2);
    }
}

.markdown-preview-container {
    display: flex;
    height: 100vh;
    overflow-y: auto;
    @include scroll-bar();
}

.preview {
    width: 100%;
    height: 100%;
    padding: 16px;
    background-color: #fafafa;
}
</style>
