<template>
    <div class="message-bubble" v-memo="[message, message.isOwner]" :id="`message-${message.messageId}`"
        :class="['bubble', message.type, { 'owner': message.isOwner }]">


        <!-- <template v-if="message.messageContentType == MessageContentType.TEXT.code">
      <div translate="yes" class="text-bubble" v-html="handleMessageProcess(message.messageBody?.text)"></div>
    </template>

<template v-if="message.messageContentType == MessageContentType.IMAGE.code">
      <img :src="message.messageBody?.path" alt="Image message" @click="handlePreview(message.messageBody?.path)"
        class="img-bubble lazy-img" />
    </template> -->


    </div>
</template>

<script setup lang="ts">

defineProps({
    message: {
        type: Object,
        required: true
    },
});

</script>

<style lang="scss" scoped></style>
