<template>
  <div
    class="message-bubble"
    v-memo="[message, message.isOwner, message.messageBody.local]"
    :id="`message-${message.messageId}`"
    v-context-menu="getMenuConfig(message)"
    :class="['bubble', message.type, { owner: message.isOwner }]"
  >
    <div class="file-bubble no-select" :title="message.messageBody?.name" @click="handleOpenFile(message)">
      <svg class="file-icon">
        <use :xlink:href="fileIcon(message.messageBody?.suffix)"></use>
      </svg>
      <div class="file-details">
        <div class="file-name">{{ message.messageBody?.name }}</div>
        <div class="file-size">{{ FileUtils.formatSize(message.messageBody?.size) }}</div>
      </div>
      <button v-show="!message.messageBody?.local" @click.stop="handleDownloadFile(message)" class="download-btn">
        <i class="iconfont icon-xiazai"></i>
      </button>
    </div>
  </div>
</template>

<script setup lang="ts">
  /**
   * 文件查看: https://blog.csdn.net/qq_63401240/article/details/147185196
   */
  import { fileIcon } from "@/utils/FileUpload";
  import { useMessageStore } from "@/store/modules/message";
  import ClipboardManager from "@/utils/Clipboard";
  import FileUtils from "@/utils/File";
  import { useFile } from "@/hooks/useFile";
  import ObjectUtils from "@/utils/ObjectUtils";

  const messageStore = useMessageStore();

  const { openFile, downloadFile, previewFile, openFilePath, autoDownloadFile } = useFile();

  const props = defineProps({
    message: {
      type: Object,
      required: true,
      default: function () {
        return {};
      }
    }
  });

  // 打开文件
  const handleOpenFile = async (message: any) => {
    const open = await openFile(message.messageBody?.local);
    if (!open) {
      delete message.messageBody.local;
      // 更新数据库
      const updata = {
        messageBody: JSON.stringify(message.messageBody)
      };
      messageStore.handleUpdateMessage(message, updata);
    }
  };

  // 下载文件
  const handleDownloadFile = async (message: any) => {
    const localPath = await downloadFile(message.messageBody?.name, message.messageBody?.path);
    if (ObjectUtils.isNotEmpty(localPath)) {
      message.messageBody.local = localPath;
      // 更新数据库
      const updata = {
        messageBody: JSON.stringify(message.messageBody)
      };
      messageStore.handleUpdateMessage(message, updata);
    }
  };

  // 自动下载文件
  const handleAutoDownloadFile = async (message: any) => {
    if (ObjectUtils.isEmpty(message.messageBody.local)) {
      const localPath = await autoDownloadFile(
        message.messageBody?.name,
        message.messageBody?.path,
        message.messageBody?.size
      );
      if (ObjectUtils.isNotEmpty(localPath)) {
        message.messageBody.local = localPath;
        // 更新数据库
        const updata = {
          messageBody: JSON.stringify(message.messageBody)
        };
        messageStore.handleUpdateMessage(message, updata);
      }
    }
  };

  /**
   * 构造右键菜单配置，只需要 item
   */
  const getMenuConfig = (item: any) => {
    const config = shallowReactive<any>({
      options: [],
      callback: async () => {}
    });
    // watchEffect 会监听 item.isTop/item.name 的改变，自动重建 options
    watchEffect(() => {
      config.options = [
        { label: "复制", value: "copy" },
        { label: "删除", value: "delete" },
        {
          label: item.messageBody.local ? "在文件夹中显示" : "预览",
          value: item.messageBody.local ? "openPath" : "preview"
        }
      ];
    });
    config.callback = async (action: any) => {
      try {
        if (action === "copy") {
          try {
            await ClipboardManager.clear();
            // 文本消息
            // if (item.messageContentType == MessageContentType.TEXT.code) {
            //     ClipboardManager.writeText(item.messageBody?.text).then(() => {
            //         Log.prettySuccess("copy text success", item.messageBody?.text)
            //     });
            // }
          } catch (err) {
            console.log(err);
          }
        }
        if (action === "delete") {
          // await ElMessageBox.confirm(
          //     `确定删除与 ${item.name} 的会话?`,
          //     '删除会话',
          //     { distinguishCancelAndClose: true, confirmButtonText: '确认', cancelButtonText: '取消' }
          // )
        }

        if (action === "openPath") {
          openFilePath(item.messageBody?.local);
        }

        if (action === "preview") {
          previewFile(item.messageBody?.name, item.messageBody?.path);
        }
      } catch {
        /* cancel */
      }
    };

    return config;
  };

  onMounted(() => {
    handleAutoDownloadFile(props.message);
  });
</script>

<style lang="scss" scoped>
  .file-bubble {
    display: flex;
    align-items: center;
    background-color: #fff;
    width: 220px;
    padding: 12px;
    border-radius: 5px;
    border: 1px solid #e7e7e7;
    box-shadow: 1px 1px 1px rgba(0, 0, 0, 0.1);
    cursor: pointer;
  }

  .file-icon {
    width: 28px;
    height: 28px;
    fill: currentColor;
    overflow: hidden;
    margin-right: 10px;
  }

  .file-details {
    flex-grow: 1;
    display: flex;
    flex-direction: column;
  }

  .file-name {
    width: 130px;
    font-weight: bold;
    overflow: hidden;
    color: var(--content-bubble-font-color);
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .file-size {
    padding-top: 5px;
    font-size: 12px;
    color: #888;
  }

  .download-btn {
    color: white;
    border: none;
    padding: 6px 8px;
    background-color: transparent;
    cursor: pointer;

    .icon-xiazai {
      color: #777;
      font-size: 22px;
    }

    &:hover {
      color: #555;
      background-color: #eee;
      // font-size: 20px;
      scale: 1.1;
    }
  }
</style>
