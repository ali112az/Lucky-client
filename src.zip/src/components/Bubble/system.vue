<template>
  <div class="message-bubble" v-memo="[message]" :id="`message-${message.messageId}`" :class="['bubble', message.type]">
    <span class="message no-select">
      <div>{{ message.messageBody?.text }}</div>
    </span>
  </div>
</template>

<script setup lang="ts">
  defineProps({
    message: {
      type: Object,
      required: true,
      default: function () {
        return {};
      }
    }
  });
</script>

<style lang="scss" scoped>
  .message-bubble {
     position: relative;
     width: 100%;


    .message {
      text-align: center;
      font-size: 12px;
      color: var(--content-message-font-color);
    }
  }
</style>
