<template>
  <div class="search-container">
    <el-row style="height: 60px">
      <el-col :span="20">
        <div class="search-container-input">
          <el-input
            class="input"
            v-model="searchStr"
            @input="handleOnInput"
            placeholder="搜索"
            @onKeydown="handleSearch"
          >
            <i slot="suffix" class="iconfont icon-sousuo"></i>
          </el-input>
        </div>
      </el-col>

      <el-col :span="4">
        <div class="search-container-btn">
          <el-button style="width: 30px" @click="handleInviteDialog">
            <i class="iconfont icon-jia" style="font-size: 18px"></i>
          </el-button>
        </div>
      </el-col>
    </el-row>
  </div>

  <el-dialog
    :model-value="inviteDialogVisible"
    title="邀请成员"
    width="550"
    class="status_change"
    :destroy-on-close="true"
  >
    <selectContact @handleAddGroupMember="handleAddGroupMember" @handleClose="handleInviteDialog"></selectContact>
  </el-dialog>
</template>

<script setup lang="ts">
  // import mitts from '@/utils/mitt.ts'
  import { useMessageStore } from "@/store/modules/message";

  const inviteDialogVisible = ref(false);

  const messageStore = useMessageStore();

  const searchStr = ref("");

  const handleSearch = (queryString: string, cb: any) => {
    messageStore.handleSearchMessage(queryString);
  };

  const handleOnInput = () => {};

  const handleInviteDialog = () => {
    // 实现添加成员的逻辑
    inviteDialogVisible.value = !inviteDialogVisible.value;
  };

  const handleSelect = () => {};

  /**
   * 邀请群成员
   * @param {*} arr
   */
  const handleAddGroupMember = (arr: any) => {
    if (arr && arr.length <= 0) return;
    messageStore.handleAddGroupMember(arr, true);
  };
</script>

<style lang="scss" scoped>
  .search-container {
    padding-left: 5px;
    line-height: 60px;
  }

  .search-container-input {
    padding-right: 8px;
  }
</style>
