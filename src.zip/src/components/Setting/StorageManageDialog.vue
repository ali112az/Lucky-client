<template>
  <el-dialog
    style="height: 480px"
    v-model="dialogVisible"
    title="存储空间"
    width="500px"
    :close-on-click-modal="false"
    @close="handleClose"
  >
    <div class="storage-container no-select">
      <!-- 存储空间概览 -->
      <div class="storage-overview">
        <div class="storage-title">已用空间</div>
        <div class="storage-size">{{ formatBytes(info.used) }}</div>
        <div class="storage-desc">占据磁盘{{ info.usedPercent.toFixed(1) }}%存储空间</div>

        <!-- 存储空间进度条 -->
        <div class="storage-progress">
          <div class="progress-bar">
            <div class="used-space" :style="`width: ${info.usedPercent.toFixed(1)}%`"></div>
            <div class="free-space"></div>
          </div>
          <div class="progress-legend">
            <div class="legend-item">
              <span class="legend-color used"></span>
              <span>磁盘已用空间</span>
            </div>
            <div class="legend-item">
              <span class="legend-color free"></span>
              <span>磁盘可用空间</span>
            </div>
          </div>
        </div>
      </div>

      <!-- 存储明细 -->
      <div class="storage-details">
        <div class="details-title">存储明细</div>

        <!-- 聊天数据 -->
        <div class="detail-item">
          <div class="item-header">
            <div class="item-info">
              <div class="item-title">聊天数据</div>
              <div class="item-size">{{ info.details.data.formatted }}</div>
            </div>
            <el-button type="primary" size="small" @click="handleManageChat"> 管理 </el-button>
          </div>
          <div class="item-desc">可清理聊天中的图片、视频、文件等数据</div>
        </div>

        <!-- 缓存 -->
        <div class="detail-item">
          <div class="item-header">
            <div class="item-info">
              <div class="item-title">缓存</div>
              <div class="item-size">{{ info.details.cache.formatted }}</div>
            </div>
            <el-button size="small" @click="handleClearCache"> 清理 </el-button>
          </div>
          <div class="item-desc">缓存是使用聊天过程中产生的临时数据，清理缓存不会影响软件的正常使用</div>
        </div>

        <!-- 其他 -->
        <div class="detail-item">
          <div class="item-header">
            <div class="item-info">
              <div class="item-title">其他</div>
              <div class="item-size">{{ info.details.other.formatted }}</div>
            </div>
          </div>
          <div class="item-desc">包含运行程序的必要文件、其他账号的数据等</div>
        </div>
      </div>
    </div>
  </el-dialog>
</template>

<script setup lang="ts">
  import { useStorageSpace } from "@/hooks/useStorageSpace";
  import { ElMessage } from "element-plus";

  const { info, refresh, formatBytes } = useStorageSpace();

  const dialogVisible = ref(false);

  const handleClose = () => {
    dialogVisible.value = false;
  };

  const handleManageChat = () => {
    ElMessage.info("管理聊天数据");
  };

  const handleClearCache = () => {
    ElMessage.success("清理缓存成功");
  };

  // 打开对话框的方法
  const showDialog = () => {
    dialogVisible.value = true;
  };

  // 暴露方法给父组件
  defineExpose({
    showDialog
  });
</script>

<style lang="scss" scoped>
  .storage-container {
    padding: 0px;
    padding-left: 20px;
    padding-right: 20px;

    .storage-overview {
      margin-bottom: 30px;

      .storage-title {
        font-size: 14px;
        color: #606266;
        margin-bottom: 10px;
      }

      .storage-size {
        font-size: 24px;
        color: #303133;
        margin-bottom: 5px;
      }

      .storage-desc {
        font-size: 12px;
        color: #909399;
        margin-bottom: 15px;
      }

      .storage-progress {
        .progress-bar {
          height: 20px;
          background-color: #f5f7fa;
          border-radius: 10px;
          overflow: hidden;
          display: flex;

          .used-space {
            background-color: #409eff;
            height: 100%;
          }

          .free-space {
            flex: 1;
            background-color: #e4e7ed;
          }
        }

        .progress-legend {
          display: flex;
          margin-top: 10px;
          font-size: 12px;
          color: #909399;

          .legend-item {
            display: flex;
            align-items: center;
            margin-right: 20px;

            .legend-color {
              width: 12px;
              height: 12px;
              margin-right: 5px;
              border-radius: 2px;

              &.used {
                background-color: #409eff;
              }

              &.free {
                background-color: #e4e7ed;
              }
            }
          }
        }
      }
    }

    .storage-details {
      .details-title {
        font-size: 14px;
        color: #606266;
        margin-bottom: 15px;
        padding-bottom: 10px;
        border-bottom: 1px solid #ebeef5;
      }

      .detail-item {
        margin-bottom: 20px;

        .item-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 5px;

          .item-info {
            display: flex;
            align-items: center;
            gap: 10px;

            .item-title {
              font-size: 14px;
              color: #303133;
            }

            .item-size {
              font-size: 14px;
              color: #606266;
            }
          }
        }

        .item-desc {
          font-size: 12px;
          color: #909399;
          line-height: 1.4;
        }
      }
    }
  }
</style>
