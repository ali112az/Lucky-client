import { ref, Ref } from "vue";
import { createI18n, I18n } from "vue-i18n";
import { readTextFile, writeTextFile, mkdir, exists, BaseDirectory, readDir } from "@tauri-apps/plugin-fs";
import { useSettingStore } from "@/store/modules/setting";

/** i18n 文件结构定义 */
interface I18nFile {
  locale: string;
  meta: {
    name: string;
    version?: string;
    author?: string;
    updatedAt?: string;
    [key: string]: any;
  };
  messages: Record<string, any>;
}

interface LocaleMeta {
  locale: string;
  name: string;
}

/** AppData 目录 */
const baseDir = BaseDirectory.AppData;

/** 默认 i18n 配置 */
const i18nOptions = {
  legacy: false,
  locale: "en-US", // 默认语言
  fallbackLocale: "en-US",
  messages: {} as Record<string, any>
};

/** 创建全局 vue-i18n 实例（单例管理时由 Manager 使用）*/
const i18n: I18n = createI18n(i18nOptions);

/**
 * I18n 管理器（单例）
 * - 保证全局仅有一个实例，组件调用 useI18n() 时会拿到同一个对象引用
 * - 封装加载 assets / appdata、保存、切换等逻辑
 */
class I18nManager {
  private static instance: I18nManager | null = null;

  // 状态（使用 ref 保证响应式）
  public i18n: I18n = i18n;
  public locale: Ref<string> = shallowRef(i18nOptions.locale);
  public meta: Ref<I18nFile["meta"] | null> = ref(null);
  public languageOptions: Ref<LocaleMeta[]> = ref([]);

  private settingStore = useSettingStore();
  private initialized = false;

  private constructor() {
    // 私有构造，防止外部 new
  }

  /** 获取单例 */
  public static getInstance(): I18nManager {
    if (!I18nManager.instance) {
      I18nManager.instance = new I18nManager();
    }
    return I18nManager.instance;
  }

  /* -------------------- 辅助函数：解析与收集 -------------------- */

  /**
   * 统一解析 raw（可能为 string / module / object）为 I18nFile
   */
  private tryParseI18n(raw: any, sourceLabel = "unknown"): I18nFile | undefined {
    if (!raw) return undefined;
    let parsed: any = raw;
    if (typeof raw === "string") {
      try {
        parsed = JSON.parse(raw);
      } catch (e) {
        console.warn(`[i18n] parse JSON failed from ${sourceLabel}:`, e);
        return undefined;
      }
    }
    // 模块导出可能是 { default: {...} }
    if (parsed && typeof parsed === "object" && parsed.default) {
      parsed = parsed.default;
    }
    if (parsed && typeof parsed.locale === "string" && parsed.messages) {
      return parsed as I18nFile;
    } else {
      console.warn(`[i18n] invalid i18n structure from ${sourceLabel}, missing locale/messages`);
      return undefined;
    }
  }

  /**
   * 收集所有可用的 i18n 文件：
   * - 优先读取 AppData（用户覆盖），再读取 assets（作为默认/补充）
   * - 返回解析并校验好的 I18nFile 数组
   */
  private async collectLocaleFiles(): Promise<I18nFile[]> {
    const resultsMap = new Map<string, I18nFile>();

    // 1) 读取 AppData 中的 i18n 文件（如果存在）
    try {
      const files = await readDir("i18n", { baseDir }).catch(() => []);
      if (files && files.length > 0) {
        for (const f of files) {
          if (!f.name) continue;
          if (!f.name.endsWith(".json")) continue;
          try {
            const raw = await readTextFile(`i18n/${f.name}`, { baseDir });
            const parsed = this.tryParseI18n(raw, `appdata/${f.name}`);
            if (parsed) {
              // 用户放在 AppData 的文件优先覆盖 assets
              resultsMap.set(parsed.locale, parsed);
            }
          } catch (e) {
            console.warn(`[i18n] failed read/parse appdata file ${f.name}:`, e);
            continue;
          }
        }
      }
    } catch (e) {
      console.warn("[i18n] readDir AppData/i18n failed:", e);
    }

    // 2) 读取打包到 assets 的 i18n（import.meta.glob）
    try {
      // path 必须为字面量以便 Vite 处理
      const modules = import.meta.glob("../assets/i18n/*.json", { eager: true }) as Record<string, any>;
      for (const key of Object.keys(modules)) {
        try {
          const mod = modules[key];
          const parsed = this.tryParseI18n(mod, `asset:${key}`);
          if (parsed && !resultsMap.has(parsed.locale)) {
            // 仅在 AppData 没有同名 locale 时加入
            resultsMap.set(parsed.locale, parsed);
          }
        } catch (e) {
          console.warn(`[i18n] failed parse asset ${key}:`, e);
        }
      }
    } catch (e) {
      console.warn("[i18n] load assets i18n failed:", e);
    }

    return Array.from(resultsMap.values());
  }

  /* -------------------- 对外 API（异步动作） -------------------- */

  /**
   * 加载指定语言并应用到 vue-i18n
   * - 优先从 AppData 读取目标文件，再 fallback 到 assets（通过 collectLocaleFiles）
   */
  public async loadLocale(lang: string) {
    try {
      let file: I18nFile | undefined;

      // 先尝试 AppData 中的单个文件（避免一开始就加载所有 assets）
      try {
        const appPath = `i18n/${lang}.json`;
        const fileExists = await exists(appPath, { baseDir }).catch(() => false);
        if (fileExists) {
          const raw = await readTextFile(appPath, { baseDir });
          file = this.tryParseI18n(raw, `appdata/${lang}.json`);
        }
      } catch (e) {
        console.warn("[i18n] changeLocale readTextFile failed:", e);
      }

      // 如果 AppData 中没有，使用 collectLocaleFiles 查找 assets 中的项
      if (!file) {
        const all = await this.collectLocaleFiles();
        file = all.find(f => f.locale === lang);
      }

      if (!file) {
        console.warn(`[i18n] locale ${lang} not found in AppData or assets`);
        return;
      }

      // 设置 meta 与 messages 到 vue-i18n
      this.meta.value = file.meta ?? null;
      this.i18n.global.setLocaleMessage(lang, file.messages);

      // 兼容性：vue-i18n 的 locale 可能是 ref 或普通属性
      // 优先尝试当作 ref 赋值，否则直接赋值
      try {
        const maybeRef = (this.i18n.global as any).locale;
        if (maybeRef && typeof maybeRef === "object" && "value" in maybeRef) {
          (maybeRef as Ref<string>).value = lang;
        } else {
          (this.i18n.global as any).locale = lang;
        }
      } catch {
        // 如果以上失败，尝试直接设定我们的响应式 locale（至少保证本地状态正确）
        this.locale.value = lang;
      }

      // 保证本地响应式 locale 与实际一致
      this.locale.value = lang;

      console.info(`[i18n] Loaded locale: ${lang}`, file.meta);
    } catch (e) {
      console.error(`[i18n] Error loading locale ${lang}:`, e);
      if (lang !== i18nOptions.fallbackLocale) {
        await this.loadLocale(i18nOptions.fallbackLocale);
      }
    }
  }

  /**
   * 保存语言文件到 AppData（仅当不存在时写入，避免覆盖用户修改）
   */
  public async saveLocaleFile(lang: string, file: I18nFile) {
    const dirPath = `i18n`;
    const filePath = `i18n/${lang}.json`;
    try {
      const dirExists = await exists(dirPath, { baseDir }).catch(() => false);
      if (!dirExists) {
        await mkdir(dirPath, { baseDir });
      }
      const fileExists = await exists(filePath, { baseDir }).catch(() => false);
      if (!fileExists) {
        await writeTextFile(filePath, JSON.stringify(file, null, 2), { baseDir });
        console.info(`[i18n] Saved locale file: ${filePath}`);
      } else {
        console.info(`[i18n] locale file already exists, skip save: ${filePath}`);
      }
    } catch (e) {
      console.error(`[i18n] Error saving locale ${lang}:`, e);
    }
  }

  /**
   * 切换语言：持久化到 settingStore 并加载语言
   */
  public async setLocale(lang: string) {
    // if (lang === this.locale.value) return; // 有时需要强制 reload，所以注释掉
    this.settingStore.language = lang;
    await this.loadLocale(lang);
    console.log("[i18n] Change lang success", lang);
  }

  /**
   * 构建语言选项（优先 AppData，再补充 assets）
   */
  public async loadLocaleOptions() {
    const files = await this.collectLocaleFiles();
    this.languageOptions.value = files.map(f => ({ locale: f.locale, name: f.meta?.name ?? f.locale }));

    // 如果 store 中的语言不在列表，补进去（保持 UI 可见）
    if (this.settingStore.language && !this.languageOptions.value.some(x => x.locale === this.settingStore.language)) {
      this.languageOptions.value.unshift({ locale: this.settingStore.language, name: this.settingStore.language });
    }
  }

  /**
   * 初始化 i18n：载入选项并应用首选语言（只需要调用一次）
   */
  public async initI18n(preferred: string = "en-US") {
    if (this.initialized) return;
    await this.loadLocaleOptions();

    const saved = this.settingStore.language;
    const lang = saved || preferred || i18nOptions.locale;
    await this.loadLocale(lang);

    this.initialized = true;
  }
}

/* -------------------- 导出 hook：返回单例管理器的公共接口 -------------------- */

/**
 * useI18n - 返回单例 I18n 管理器
 * 在组件中使用示例：
 * const { i18n, locale, setLocale, languageOptions, initI18n } = useI18n();
 */
export function useI18n() {
  const mgr = I18nManager.getInstance();
  return {
    i18n: mgr.i18n,
    locale: mgr.locale,
    meta: mgr.meta,
    languageOptions: mgr.languageOptions,
    initI18n: mgr.initI18n.bind(mgr),
    loadLocale: mgr.loadLocale.bind(mgr),
    saveLocaleFile: mgr.saveLocaleFile.bind(mgr),
    loadLocaleOptions: mgr.loadLocaleOptions.bind(mgr),
    setLocale: mgr.setLocale.bind(mgr)
  };
}
