import { MessageContentType } from "@/constants";
import Chats from "@/database/entity/Chats";

/**
 * useChatInput Hook（简化版）
 * 导出：buildUserMap / buildMessagePreview / buildDraftMessagePreview / removeMentionHighlightsFromHtml / findChatIndex
 */
type SingleMessageOrGroupMessage = any;

export function useChatInput() {
  /* -------------------- 辅助工具 -------------------- */

  const escapeHtml = (s?: string) =>
    s == null
      ? ""
      : String(s)
          .replace(/&/g, "&amp;")
          .replace(/</g, "&lt;")
          .replace(/>/g, "&gt;")
          .replace(/"/g, "&quot;")
          .replace(/'/g, "&#39;");

  const escapeRegExp = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

  const stripHtmlToPlain = (html = "") =>
    String(html)
      .replace(/<br\s*\/?>/gi, "\n")
      .replace(/<[^>]+>/g, "")
      .replace(/\u200B/g, "")
      .replace(/\s+/g, " ")
      .trim();

  const partsToOriginalText = (parts?: any[]) =>
    Array.isArray(parts) && parts.length
      ? parts
          .map(p => {
            if (!p) return "";
            if (p.type === "text") return String(p.content ?? "");
            if (p.type === "at") return String(p.content ?? `@${p.name ?? ""}`);
            if (p.type === "image") return "[图片]";
            if (p.type === "video") return "[视频]";
            if (p.type === "audio") return "[语音]";
            return "[附件]";
          })
          .join("")
      : "";

  const partsHasAll = (parts?: any[]) =>
    Array.isArray(parts) &&
    parts.some(p => {
      if (!p) return false;
      const id = String(p.id ?? "").toLowerCase();
      const name = String(p.name ?? "").toLowerCase();
      const content = String(p.content ?? "").toLowerCase();
      return id === "all" || id === "@all" || name === "所有人" || content === "@all" || content.includes("所有人");
    });

  const collectMentionIds = (message: SingleMessageOrGroupMessage, parts?: any[]) => {
    const set = new Set<string>();
    if (Array.isArray(message?.mentionedUserIds))
      message.mentionedUserIds.forEach((id: any) => id != null && set.add(String(id)));
    if (Array.isArray(parts)) parts.forEach(p => p && p.type === "at" && p.id && set.add(String(p.id)));
    return Array.from(set);
  };

  /* -------------------- buildMessagePreview（保留简洁逻辑） -------------------- */
  type BuildPreviewOptions = { highlightClass?: string; currentUserId?: string | null; asHtml?: boolean };

  function buildMessagePreview(message: SingleMessageOrGroupMessage, opts: BuildPreviewOptions = {}) {
    const { highlightClass = "mention-highlight", currentUserId = null, asHtml = true } = opts;
    const contentTypeRaw = message?.messageContentType;
    const code =
      typeof contentTypeRaw === "string"
        ? parseInt(contentTypeRaw, 10)
        : typeof contentTypeRaw === "number"
        ? contentTypeRaw
        : 0;

    // 文本类型
    if (code === MessageContentType.TEXT.code) {
      const body: any = message?.messageBody ?? {};
      const parts: any[] | undefined = Array.isArray(body.parts) ? body.parts : undefined;
      const originalText = parts && parts.length ? partsToOriginalText(parts) : String(body.text ?? "");
      const mentionAll = !!message?.mentionAll || partsHasAll(parts);
      const mentionedIds = collectMentionIds(message, parts);
      const mentionYou = currentUserId != null && mentionedIds.includes(String(currentUserId));

      const badges: string[] = [];
      const badge = (t: string) => `<span class="${escapeHtml(highlightClass)}">${escapeHtml(t)}</span>`;
      if (mentionYou) badges.push(badge("[有人@你]"));
      if (mentionAll) badges.push(badge("[@所有人]"));

      // 构建正文预览：把 parts 中的 text / placeholder 拼接（跳过 at）
      const outHtmlPieces: string[] = [];
      const outPlainPieces: string[] = [];
      if (Array.isArray(parts) && parts.length) {
        for (const p of parts) {
          if (!p) continue;
          if (p.type === "text") {
            outHtmlPieces.push(escapeHtml(String(p.content ?? "")));
            outPlainPieces.push(String(p.content ?? ""));
          } else if (p.type === "image") {
            outHtmlPieces.push(escapeHtml("[图片]"));
            outPlainPieces.push("[图片]");
          } else if (p.type === "video") {
            outHtmlPieces.push(escapeHtml("[视频]"));
            outPlainPieces.push("[视频]");
          } else if (p.type === "audio") {
            outHtmlPieces.push(escapeHtml("[语音]"));
            outPlainPieces.push("[语音]");
          } else {
            outHtmlPieces.push(escapeHtml("[附件]"));
            outPlainPieces.push("[附件]");
          }
        }
      } else {
        const raw = String(body.text ?? "");
        outHtmlPieces.push(escapeHtml(raw));
        outPlainPieces.push(raw);
      }

      const bodyHtml = outHtmlPieces.join("");
      const plainText = outPlainPieces.join("").replace(/\s+/g, " ").trim();
      const prefixHtml = badges.length ? badges.join("") + " " : "";
      const html = asHtml ? prefixHtml + bodyHtml : prefixHtml.replace(/<[^>]+>/g, "") + plainText;
      const finalPlain = (
        badges.map(b => b.replace(/<[^>]+>/g, "")).join("") + (plainText ? " " + plainText : "")
      ).trim();

      return {
        html: html || escapeHtml(finalPlain || ""),
        plainText: finalPlain || "",
        originalText: originalText || ""
      };
    }

    // 非文本类型（统一返回占位）
    const orig = String(message?.messageBody?.text ?? message?.previewText ?? "");
    const mentionAllNon = !!message?.mentionAll;
    const mentionedNon = Array.isArray(message?.mentionedUserIds) ? message.mentionedUserIds.map(String) : [];
    const mentionYouNon = currentUserId != null && mentionedNon.includes(String(currentUserId));
    const badgesNon: string[] = [];
    const badgeSpan = (t: string) => `<span class="${escapeHtml(highlightClass)}">${escapeHtml(t)}</span>`;
    if (mentionYouNon) badgesNon.push(badgeSpan("[有人@你]"));
    if (mentionAllNon) badgesNon.push(badgeSpan("[@所有人]"));
    const prefix = badgesNon.length ? badgesNon.join("") + " " : "";
    const txtMap: Record<number, string> = {
      [MessageContentType.IMAGE.code]: "[图片]",
      [MessageContentType.VIDEO.code]: "[视频]",
      [MessageContentType.AUDIO.code]: "[语音]",
      [MessageContentType.FILE.code]: "[文件]",
      [MessageContentType.LOCAL.code]: "[位置]"
    } as any;
    const placeholder = txtMap[code] || "未知消息类型";
    return {
      html: asHtml ? prefix + escapeHtml(placeholder) : prefix.replace(/<[^>]+>/g, "") + " " + placeholder,
      plainText: (prefix.replace(/<[^>]+>/g, "") + " " + placeholder).trim(),
      originalText: orig
    };
  }

  /* -------------------- removeMentionHighlightsFromHtml（改进） -------------------- */

  /**
   * 移除高亮 span / data-mention-id，并可额外移除常见 badge 文本（比如 [@所有人] [有人@你] [草稿]）
   * - options:
   *    highlightClass?: string (默认 'mention-highlight')
   *    matchByDataAttr?: boolean (默认 true)
   *    removeBadges?: boolean (默认 true)
   *    returnPlainText?: boolean (默认 false)
   */
  function removeMentionHighlightsFromHtml(
    html: string | undefined,
    options?: { highlightClass?: string; matchByDataAttr?: boolean; removeBadges?: boolean; returnPlainText?: boolean }
  ): string {
    const {
      highlightClass = "mention-highlight",
      matchByDataAttr = true,
      removeBadges = true,
      returnPlainText = false
    } = options || {};
    if (!html) return "";

    // badge 正则（会匹配 [@所有人] 或 [所有人]、[有人@你]、[草稿]）
    const badgeRegex = /\[(?:@?所有人|有人@你|草稿)\]/g;

    // 浏览器 DOM 路径（优先）
    if (typeof document !== "undefined") {
      const wrapper = document.createElement("div");
      wrapper.innerHTML = html;

      // 1) 处理带 highlightClass 的 span 元素
      const safeClass = (highlightClass || "").replace(/([^\w-])/g, "\\$1");
      const selector = `span.${safeClass}`;
      const highlightNodes = Array.from(wrapper.querySelectorAll(selector));
      for (const node of highlightNodes) {
        const txt = node.textContent ?? "";
        if (removeBadges && badgeRegex.test(txt)) {
          // 如果 span 内容是 badge（或包含 badge），移除整个节点
          node.parentNode?.removeChild(node);
        } else {
          // 否则用纯文本替换该节点（保留文本）
          node.parentNode?.replaceChild(document.createTextNode(txt), node);
        }
      }

      // 2) 处理带 data-mention-id 的元素：保留内部文本（替换为 text node）
      if (matchByDataAttr) {
        const attrNodes = Array.from(wrapper.querySelectorAll("[data-mention-id]"));
        for (const n of attrNodes) {
          const txt = n.textContent ?? "";
          n.parentNode?.replaceChild(document.createTextNode(txt), n);
        }
      }

      // 3) 在所有文本节点中移除残留的 badge 文本（例如 badge 可能是普通文本）
      if (removeBadges) {
        const walker = document.createTreeWalker(wrapper, NodeFilter.SHOW_TEXT, null);
        const toProcess: Text[] = [];
        while (walker.nextNode()) toProcess.push(walker.currentNode as Text);
        for (const t of toProcess) {
          if (!t.nodeValue) continue;
          if (badgeRegex.test(t.nodeValue)) {
            t.nodeValue = t.nodeValue.replace(badgeRegex, "").replace(/\s+/g, " ").trim();
          }
        }
      }

      if (returnPlainText) return (wrapper.textContent ?? "").replace(/\s+/g, " ").trim();
      return wrapper.innerHTML;
    }

    // SSR / 无 DOM：使用正则退化处理
    try {
      let s = html;

      // 1) 去除带 highlightClass 的 span 标签（如果是 badge 则整体删除；否则保留内部文本）
      const cls = (highlightClass || "").replace(/[-/\\^$*+?.()|[\]{}]/g, "\\$&");
      const reSpan = new RegExp(`<span[^>]*class=["'][^"']*\\b${cls}\\b[^"']*["'][^>]*>([\\s\\S]*?)<\\/span>`, "gi");
      s = s.replace(reSpan, (_m, inner) => {
        if (removeBadges && badgeRegex.test(inner || "")) return "";
        return inner || "";
      });

      // 2) 去除带 data-mention-id 的元素，保留内部内容（宽松匹配）
      s = s.replace(
        /<([a-zA-Z0-9]+)([^>]*?)\sdata-mention-id=(?:"[^"]*"|'[^']*'|[^\s>]+)([^>]*)>([\s\S]*?)<\/\1>/gi,
        (_m, _tag, _a, _b, inner) => inner || ""
      );
      // s = s.replace(
      //   /<([a-zA-Z0-9]+)([^>]*)\sdata-mention-id=(["']?).*?\3([^>]*)>([\s\S]*?)<\/\1>/gi,
      //   (_m, _tag, _a, _q, _b, inner) => inner || ""
      // );

      // 3) 移除残留 badge
      if (removeBadges) s = s.replace(badgeRegex, "");

      if (returnPlainText)
        return s
          .replace(/<[^>]+>/g, "")
          .replace(/\s+/g, " ")
          .trim();
      return s;
    } catch (e) {
      return html;
    }
  }

  /* -------------------- buildUserMap（保留简洁实现） -------------------- */
  function buildUserMap(members: any, filterIds?: string[]) {
    const out: Record<string, string> = {};
    if (!members) return out;
    if (typeof members === "string") {
      try {
        members = JSON.parse(members);
      } catch (e) {
        return out;
      }
    }
    const add = (id: string, name?: string) => {
      if (!id) return;
      if (filterIds && filterIds.length && !filterIds.includes(id)) return;
      out[id] = name ?? out[id] ?? "";
    };
    if (Array.isArray(members)) {
      for (const m of members) {
        if (!m) continue;
        const id = m.userId ?? m.id ?? (typeof m === "string" ? m : undefined);
        const name = m.name ?? m.nick ?? m.nickname ?? (typeof m === "string" ? m : undefined);
        if (id) add(String(id), name ? String(name) : "");
      }
      return out;
    }
    if (typeof members === "object") {
      for (const key of Object.keys(members)) {
        const v = members[key];
        const id = v?.userId ?? v?.id ?? key;
        const name = v?.name ?? v?.nick ?? v;
        if (id) add(String(id), name ? String(name) : "");
      }
      return out;
    }
    return out;
  }

  /* -------------------- buildDraftMessagePreview（简化、带 span 高亮 badge） -------------------- */
  function buildDraftMessagePreview(chatId: string | number, draftHtml: string) {
    if (!chatId && !draftHtml) return "";
    const plain = stripHtmlToPlain(draftHtml || "");
    const LIMIT = 80;
    const snippet = plain ? (plain.length > LIMIT ? `${plain.slice(0, LIMIT)}...` : plain) : "";
    // 使用 span 包裹 badge，便于样式高亮
    const snippetHtml = `<span class="mention-highlight-draft">[草稿]</span>&nbsp;${escapeHtml(snippet)}`;
    return snippetHtml;
  }

  /* -------------------- findChatIndex -------------------- */
  function findChatIndex(chatList: Chats[], chatId: string | number) {
    return chatList.findIndex(c => c.chatId === chatId || c.id === chatId);
  }

  /* -------------------- 导出 -------------------- */
  return {
    buildUserMap,
    buildMessagePreview,
    buildDraftMessagePreview,
    removeMentionHighlightsFromHtml,
    findChatIndex
  };
}
