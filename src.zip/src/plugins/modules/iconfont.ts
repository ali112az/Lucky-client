import '@/assets/iconfont/iconfont.css'
import '@/assets/iconfont/iconfont.js'


export default {
  install: () => {},
}
