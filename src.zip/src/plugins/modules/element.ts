import ElementPlus from 'element-plus'
import * as ElementPlusIconsVue from '@element-plus/icons-vue'
import { App } from 'vue';
import 'element-plus/theme-chalk/dark/css-vars.css'//这句是暗黑模式切换
import "@/assets/style/scss/index.scss";
import "@/assets/style/scss/theme.scss";
import "@/assets/style/scss/setting.scss";
import 'element-plus/dist/index.css'



export default {
  install: (app:App) => {
    app.use(ElementPlus);
    //增加element 图标
    for (const [key, component] of Object.entries(ElementPlusIconsVue)) {
      app.component(key, component)
    }
  },
}
