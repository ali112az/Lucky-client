import "bootstrap-icons/font/bootstrap-icons.scss";
import "bootstrap-icons/font/bootstrap-icons.css";
/**
 * https://icons.bootcss.com/#usage
 * bootstrap 图标库
 */
export default {
  install: () => {},
};
