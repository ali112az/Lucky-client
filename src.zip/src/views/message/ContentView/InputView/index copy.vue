<template>
  <div class="chat-container">
    <!-- 工具栏 -->
    <div class="chat-container-tool">
      <!--表情-->
      <div class="icon-box" ref="emojiBtnRef" @click="handleOpenEmoji">
        <i class="iconfont icon-biaoqing-xue"></i>
        <el-popover
          ref="emojiPopoverRef"
          width="420"
          popper-class="emoji-popper"
          :virtual-ref="emojiBtnRef"
          trigger="click"
          placement="top"
          virtual-triggering
        >
          <Suspense>
            <template #default>
              <Emoji @handleChooseEmoji="handleChooseEmoji" :historyEmojiList="historyEmojiList"></Emoji>
            </template>
            <template #fallback>
              <el-empty description="description" />
            </template>
          </Suspense>
        </el-popover>
      </div>

      <!--截图-->
      <div class="icon-box" @click="handleScreeenShot">
        <i class="iconfont icon-jietu1"></i>
      </div>

      <!--视频通话-->
      <div class="icon-box" @click="handleCall">
        <i class="iconfont icon-shipin1"></i>
      </div>

      <!--文件-->
      <div class="icon-box" @click="handleOpenFileInput">
        <i class="iconfont icon-wenjian"></i>
        <input type="file" ref="fileInputRef" style="display: none" @change="handleFileChange" />
      </div>

      <!--聊天历史-->
      <div class="icon-box" @click="handleHistoryMessageDialog">
        <i class="iconfont icon-liaotianjilu"></i>
      </div>
    </div>

    <!-- 输入框 -->
    <div
      class="chat-container-input"
      ref="inputContentRef"
      contenteditable="true"
      spellcheck="false"
      @click="handleSelection"
      @input="handleSelection"
      @keydown="handleKeyDown"
      @keyup="handleKeyUp"
      @paste="handlePaste"
    ></div>

    <!-- 在它下面或上面单独渲染预览区 -->
    <div class="image-preview-list">
      <div v-for="(img, i) in pastedImages" :key="i" class="preview-item">
        <img :src="img.url" style="height: 90px" />
      </div>
    </div>

    <!-- 发送按钮 -->
    <div class="chat-container-button">
      <button class="button" @click="handleSendMessage">发送</button>
    </div>

    <!-- @ 弹窗 -->

    <Suspense>
      <template #default>
        <AtDialog
          v-if="atDialogParam.showDialog"
          :visible="atDialogParam.showDialog"
          :position="atDialogParam.position"
          :queryString="atDialogParam.queryString"
          @handleHide="onHideAt"
          @handlePickUser="onPickUser"
          :users="users"
        />
      </template>
      <template #fallback>
        <el-empty description="description" />
      </template>
    </Suspense>

    <Suspense>
      <template #default>
        <HistoryDialog
          :visible="historyDialogParam.showDialog"
          :title="'聊天历史记录'"
          @handleClose="handleHistoryMessageDialog"
        />
      </template>
      <template #fallback>
        <el-empty description="description" />
      </template>
    </Suspense>
  </div>
</template>

<script setup lang="ts">
  // 按需导入组件和工具函数
  const Emoji = defineAsyncComponent(() => import("@/components/Emoji/index.vue"));
  const AtDialog = defineAsyncComponent(() => import("@/components/Atdialog/index.vue"));
  const HistoryDialog = defineAsyncComponent(() => import("@/components/History/index.vue"));

  import { useMessageStore } from "@/store/modules/message";
  import { useCallStore } from "@/store/modules/call";
  import { storage } from "@/utils/Storage";
  import userAt from "@/hooks/useAt";
  import onPaste from "@/utils/Paste";
  import { useGlobalShortcut } from "@/hooks/useGlobalShortcut";

  // 引入 Ref 和其他工具
  const emojiBtnRef = ref<HTMLElement>();
  const emojiPopoverRef = ref<HTMLElement | any>();
  const fileInputRef = ref<HTMLElement>();
  const inputContentRef = ref<HTMLElement>();
  const currentChildNodes = ref<any>([]);
  const currentSelection: any = ref(null);
  const range = ref(null);

  const { addShortcut } = useGlobalShortcut();
  const messageStore = useMessageStore();
  const callStore = useCallStore();
  const fileList = ref([]);
  const historyEmojiList = ref([]);
  const messageList = ref<any>([]);
  const users = [
    {
      userId: 100001,
      name: "any"
    }
  ];

  const pastedImages = shallowReactive<{ file: File; url: string }[]>([]);

  // 定义弹窗的状态
  const historyDialogParam = ref({ showDialog: false });

  const { atDialogParam, onHideAt, onPickUser, onKeyUp } = userAt(inputContentRef);

  /**
   * 打开文件选择框
   */
  const handleOpenFileInput = () => fileInputRef.value?.click();

  /**
   * 发送文件消息
   * @param {*} event
   */
  const handleFileChange = (event: any) => {
    const file = event.target.files[0];
    if (!file) return;
    //const type = getFileType(file.name);
    messageList.value.push({ type: "file", content: file } as never);
    messageStore.handleSendMessage(messageList.value);
    messageList.value = [];
  };

  /**
   * 截图
   */
  const handleScreeenShot = () => {
    messageStore.handleShowScreeenShot();
  };

  /**
   * 视频通话
   */
  const handleCall = () => {
    callStore.handleCreateCallMessage();
  };

  /**
   * 显示历史消息
   */
  const handleHistoryMessageDialog = () => {
    historyDialogParam.value.showDialog = !historyDialogParam.value.showDialog;
  };

  /**
   * 监听键盘事件
   * @param event
   */
  const handleKeyUp = (event: any) => {
    if (event.keyCode === 13) {
      //this.$emit('enter')
    }
    onKeyUp(event);
  };

  /**
   * 插入emoji表情
   * @param {*} emoji 选择的emoji
   */
  const handleChooseEmoji = (emoji: string) => {
    if (emoji) {
      // 没有焦点就获取输入框焦点
      if (document.activeElement != inputContentRef.value) {
        inputContentRef.value?.focus();
      }
      const textNode = document.createTextNode(emoji);
      inputContentRef.value?.appendChild(textNode);

      // 保存表情到 currentChildNodes
      if (inputContentRef.value && inputContentRef.value.childNodes) {
        currentChildNodes.value = inputContentRef.value.childNodes;
      }

      // 保存最近使用的emoji
      recentlyUseEmoji(emoji);
      // 光标移动到最后
      cursorToEnd();
    }
  };

  /**
   * 打开emoji表情弹窗
   */
  const handleOpenEmoji = () => {
    unref(emojiPopoverRef).popperRef?.delayHide?.();
  };

  const cursorToEnd = () => {
    if (window.getSelection) {
      //ie11 10 9 ff safari
      inputContentRef.value?.focus(); //解决ff不获取焦点无法定位问题
      var range: any = window.getSelection(); //创建range
      range.selectAllChildren(inputContentRef.value); //range 选择obj下所有子内容
      range.collapseToEnd(); //光标移至最后
    }
    // else if (document.getSelection as any) {//ie10 9 8 7 6 5
    //     var range = (document.selection as any).createRange();//创建选择对象
    //     //var range = document.body.createTextRange();
    //     range.moveToElementText(inputContentRef.value);//range定位到obj
    //     range.collapse(false);//光标移至最后
    //     range.select();
    // }
  };

  const handleKeyDown = (event: any) => {
    // 检查是否按下了回车键
    // if (event.key === "Enter" || event.keyCode === 13) {
    //   // 检查是否正在输入中文字符
    //   if (!!event.target.composing) return;
    //   // 否则，阻止默认行为，防止插入换行
    //   event.cancelBubble = true;
    //   event.stopPropagation();
    //   event.preventDefault();
    //   // 调用发送消息的方法
    //   handleSendMessage();
    // }
  };

  const handleSelection = (e: any) => {
    // 获取输入框中所有的子元素
    if (e.target && e.target.childNodes) {
      currentChildNodes.value = e.target.childNodes;
    }
    // 存储输入框最后输入时的光标目标及位置，用于上传图片时，图片插入光标所在位置
    currentSelection.value = window.getSelection();
    range.value = currentSelection.value.getRangeAt(0);
  };

  // const handlePaste = async (e: ClipboardEvent) => {
  //     e.preventDefault()
  //     const items = Array.from(e.clipboardData?.items || [])
  //     for (const item of items) {
  //         if (item.kind === 'file' && item.type.startsWith('image/')) {
  //             const file = item.getAsFile()!
  //             const url = URL.createObjectURL(file)
  //             pastedImages.push({ file, url })
  //         }
  //         else if (item.kind === 'string') {
  //             const text = await ClipboardManager.readText()
  //             document.execCommand('insertText', false, text)
  //         }
  //     }
  // }

  // const handlePaste = async (event: ClipboardEvent) => {
  //     event.preventDefault();
  //     // await ClipboardManager.readText()
  //     // if(){}
  //     const clipboard = event.clipboardData
  //     if (!clipboard) {
  //         throw new Error('剪贴板数据不可用')
  //     }
  //     try {
  //         // 遍历所有粘贴项
  //         for (const item of Array.from(clipboard.items)) {
  //             if (item.kind === 'file' && item.type.includes('image')) {
  //                 const sel = window.getSelection(); // 获取当前光标位置
  //                 if (sel?.rangeCount === 1 && sel.isCollapsed) {
  //                     // 1. 读取 PNG 二进制（Uint8Array）
  //                     const tauriImg = await ClipboardManager.readImage()
  //                     const bytes = await tauriImg.rgba()

  //                     // 2. 转成 Base64 字符串
  //                     //    注意：这里把 bytes 转为字符串，再 btoa
  //                     let binary = ''
  //                     const arr = new Uint8Array(bytes)
  //                     for (let i = 0; i < arr.byteLength; i++) {
  //                         binary += String.fromCharCode(arr[i])
  //                     }
  //                     const b64 = window.btoa(binary)

  //                     // 3. 构造 Data URL
  //                     const dataUrl = `data:image/png;base64,${b64}`

  //                     // 4. 插入图片
  //                     const img = new Image()
  //                     img.src = dataUrl
  //                     img.style.height = '90px'

  //                     const range = sel.getRangeAt(0)
  //                     range.insertNode(img)
  //                     range.collapse(false)
  //                     sel.removeAllRanges()
  //                     sel.addRange(range)
  //                 }
  //             }
  //             if (item.kind === 'string') {
  //                 const text = await ClipboardManager.readText();

  //                 const sel = window.getSelection();
  //                 if (!sel || sel.rangeCount === 0) return;
  //                 let range = sel.getRangeAt(0);
  //                 const p = document.createElement('p');
  //                 p.style = "white-space: pre-wrap; margin: 0;"
  //                 // 把换行转换成 <br/>，保留空格的话可以额外加 CSS white-space: pre-wrap;
  //                 p.innerHTML = text
  //                     .replace(/&/g, '&amp;')
  //                     .replace(/</g, '&lt;')
  //                     .replace(/>/g, '&gt;')
  //                     .replace(/\r?\n/g, '<br/>');
  //                 // 如果想让 p 保留空格缩进，也可以加：
  //                 // p.style.whiteSpace = 'pre-wrap';

  //                 range.insertNode(p);
  //                 range.setStartAfter(p);
  //                 range.collapse(true);

  //                 // 最后更新 selection
  //                 sel.removeAllRanges();
  //                 sel.addRange(range);

  //                 //document.execCommand('insertText', false, text);
  //             }
  //         }
  //     } catch (err) {
  //         throw new Error('不支持的粘贴类型')
  //     }
  // };

  const handlePaste = async (e: any) => {
    e.preventDefault();
    const result: any = await onPaste(e);
    if (result.data.size > 2 * 1024 * 1024) {
      ElMessage.error("图片大小超过2M");
      return;
    }
    if (result.type === "string") {
      // 粘贴文本
      const sel = window.getSelection();
      if (!sel || sel.rangeCount === 0) return;
      let range = sel.getRangeAt(0);
      const p = document.createElement("p");
      p.style = "white-space: pre-wrap; margin: 0;";
      // 把换行转换成 <br/>，保留空格的话可以额外加 CSS white-space: pre-wrap;
      p.innerHTML = result.data
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/\r?\n/g, "<br/>");
      // 如果想让 p 保留空格缩进，也可以加：
      // p.style.whiteSpace = 'pre-wrap';

      range.insertNode(p);
      range.setStartAfter(p);
      range.collapse(true);

      // 最后更新 selection
      sel.removeAllRanges();
      sel.addRange(range);
      cursorToEnd();
    } else {
      // 粘贴图片
      //const imgRegx = /^data:image\/(png|jpg|jpeg|gif|svg\+xml|bmp|tif);base64,/; // 支持的图片格式
      const mime = "png|jpg|jpeg|gif|svg\+xml|bmp|tif"; // 支持的图片格式
      const imgRegx = new RegExp(`^data:image\\/(${mime});base64,`, "i");
      if (imgRegx.test(result.url)) {
        fileList.value.push(result.data as never);
        // document.execCommand('insertImage', false, result.compressedDataUrl);
        const sel = window.getSelection(); // 获取当前光标位置
        if (sel && sel.rangeCount === 1 && sel.isCollapsed) {
          const range = sel.getRangeAt(0);
          const img: any = new Image();
          img.style = "height: 90px";
          img.src = result.url; // 使用压缩后的图片
          range.insertNode(img);
          range.collapse(false);
          sel.removeAllRanges();
          sel.addRange(range);
        }
      }
    }
  };

  const emitChange = () => {
    // 1. 重置消息列表
    messageList.value = [];

    // 2. 图片下标，用于获取 fileList
    let imgIndex = 0;

    // 3. 公共：向最后一条合并文本，否则新建一条 text 消息
    function appendText(text: string) {
      if (!text) return;
      const last: any = messageList.value[messageList.value.length - 1];
      if (last && last.type === "text") {
        last.content += text;
      } else {
        messageList.value.push({ type: "text", content: text });
      }
    }

    // 4. 逐节点处理
    currentChildNodes.value.forEach((node: Node) => {
      if (node.nodeType === Node.ELEMENT_NODE) {
        const el = node as HTMLElement;
        switch (el.nodeName) {
          case "BR":
            // 换行
            appendText("\n");
            break;
          case "SPAN":
            // @标签
            messageList.value.push({
              type: "at",
              content: el.innerText
            });
            break;
          case "IMG":
            // 图片
            const file = fileList.value[imgIndex++];
            if (file) {
              messageList.value.push({
                type: "image",
                content: file
              });
            }
            break;
          case "P":
            // 段落：把整个文本当一行，换段落用 '\n'
            const pText = el.innerText.trim();
            if (pText) {
              appendText(pText + "\n");
            }
            break;
          case "PRE":
            // 预格式化：保留所有换行和空格
            const preText = el.textContent || "";
            appendText(preText);
            break;
          default:
            // 其他元素，直接按它的文本来处理
            appendText(el.innerText);
        }
      } else if (node.nodeType === Node.TEXT_NODE) {
        // 文本节点
        appendText(node.nodeValue || "");
      }
    });

    // 5. 最后去除结尾多余的换行
    const last: any = messageList.value[messageList.value.length - 1];
    if (last && last.type === "text") {
      last.content = last.content.replace(/\n+$/, "");
    }

    // 6. 如果没有生成任何消息，则不触发
    if (messageList.value.length === 0) {
      return;
    }
  };

  /**
   * 通过组件传递发送输入框的消息
   */
  const handleSendMessage = async () => {
    emitChange();
    messageStore.handleSendMessage(messageList.value);
    useLogger().prettyInfo("send message", messageList.value);
    //emit("handleSendMessage", messageList.value);
    fileList.value = [];
    messageList.value = [];
    currentChildNodes.value = [];
    inputContentRef.value!.innerHTML = "";
  };

  // 保存最近使用的emoji
  const recentlyUseEmoji = (emoji: any) => {
    let idx = historyEmojiList.value.indexOf(emoji as never);
    if (idx < 0) {
      historyEmojiList.value.unshift(emoji as never);
    } else {
      historyEmojiList.value.unshift(historyEmojiList.value.splice(idx, 1)[0]);
    }
    // 只要两行emoji(16个)
    historyEmojiList.value = historyEmojiList.value.splice(0, 16);
    // 保存记录
    storage.set("emojiHistory", JSON.stringify(historyEmojiList.value));
  };

  /**
   * 发送图片消息
   * @param {*} event
   */
  // const handleFileChange = (event) => {
  //     const file = event.target.files[0];
  //     if (!file) return;
  //     const fileUtils = new FileUtils()
  //     const type = fileUtils.getFileType(file.name)
  //     // 发送图片消息
  //     emit("handleSendMessage", [{
  //         type: type,
  //         content: file
  //     }]);
  // };

  // const handleOpenFileInput = () => {
  //     fileInputRef.value.click();
  // }

  onMounted(() => {
    addShortcut({
      name: "sendMessage",
      combination: "Alt + Enter",
      handler: () => {
        // 判断是否可见
        if (useWindowFocus()) {
          handleSendMessage();
          console.log("快捷键发送消息 ");
        }
      }
    });
    //historyEmojiList.value = localStorage.getItem('emojiHistory') ? JSON.parse(localStorage.getItem('emojiHistory')) : []
  });
</script>

<style lang="scss" scoped>
  @mixin scroll-bar($width: 8px) {
    /* 背景色为透明 */
    &::-webkit-scrollbar-track {
      border-radius: 10px;
      background-color: transparent;
    }

    &::-webkit-scrollbar {
      width: $width;
      height: 10px;
      background-color: transparent;
    }

    &::-webkit-scrollbar-thumb {
      border-radius: 10px;
      background-color: rgba(0, 0, 0, 0.2);
    }
  }

  .chat-container {
    display: flex;
    flex-direction: column;
    height: 100%;
  }

  .chat-container-tool {
    display: flex;
    height: 25px;
    padding: 5px;
    margin-left: 10px;
    // border-top: 1px solid rgba(148, 142, 142, 0.11);

    .icon-box {
      margin-right: 10px;
      cursor: pointer;

      i {
        font-size: 20px;
        color: var(--input-button-icon-color);
      }

      &:hover i {
        color: rgb(25, 166, 221);
      }
    }
  }

  .chat-container-input {
    font-size: 15px;
    color: var(--input-font-color);
    border: none;
    outline: none;
    padding: 5px 8px;
    overflow-y: auto;
    flex: 1 1 auto;
    word-break: break-all; // 解决纯字母时不自动换行问题

    &:empty:before {
      content: attr(data-placeholder);
    }

    &:focus:before {
      content: " "; // 解决无内容时聚焦没有光标
    }

    /* 可以伸缩，但只占所需空间 */
    @include scroll-bar();
  }

  .chat-container-button .button {
    height: 30px;
    width: 90px;
    margin: 0 30px 10px auto;
    border-radius: 6px;
    border: none;
    float: right;

    &:hover {
      box-shadow: 1px 1px 2px #cec5c5;
      border: 1px solid rgba(255, 255, 255, 0.8);
    }
  }
</style>
