<template>
  <div class="chat-container">
    <!-- 工具栏 -->
    <div class="chat-container-tool">
      <!--表情-->
      <div class="icon-box" ref="emojiBtnRef" @click="handleOpenEmoji">
        <i class="iconfont icon-biaoqing-xue"></i>
        <el-popover
          ref="emojiPopoverRef"
          width="420"
          popper-class="emoji-popper"
          :virtual-ref="emojiBtnRef"
          trigger="click"
          placement="top"
          virtual-triggering
        >
          <Suspense>
            <template #default>
              <Emoji @handleChooseEmoji="handleChooseEmoji" :historyEmojiList="historyEmojiList"></Emoji>
            </template>
            <template #fallback>
              <el-empty description="description" />
            </template>
          </Suspense>
        </el-popover>
      </div>

      <!--截图-->
      <div class="icon-box" @click="handleScreenShot">
        <i class="iconfont icon-jietu1"></i>
      </div>

      <!--视频通话-->
      <div class="icon-box" @click="handleCall">
        <i class="iconfont icon-shipin1"></i>
      </div>

      <!--文件-->
      <div class="icon-box" @click="handleOpenFileInput">
        <i class="iconfont icon-wenjian"></i>
        <input type="file" ref="fileInputRef" style="display: none" @change="handleFileChange" />
      </div>

      <!--聊天历史-->
      <!-- <div class="icon-box" @click="handleHistoryMessageDialog">
        <i class="iconfont icon-liaotianjilu"></i>
      </div> -->
    </div>

    <!-- 输入框 -->
    <div
      class="chat-container-input"
      ref="inputContentRef"
      contenteditable="true"
      spellcheck="false"
      @click="handleSelection"
      @input="handleSelection"
      @keyup="handleKeyUpEvent"
      @paste="handlePaste"
    ></div>

    <!-- 在它下面或上面单独渲染预览区 -->
    <div class="image-preview-list">
      <div v-for="(img, i) in pastedImages" :key="i" class="preview-item">
        <img :src="img.url" style="height: 90px" />
      </div>
    </div>

    <!-- 发送按钮 -->
    <div class="chat-container-button no-select">
      <button class="button" @click="handleSendMsg">{{ $t("actions.send") }}</button>
    </div>

    <!-- @ 弹窗 -->

    <Suspense>
      <template #default>
        <AtDialog
          v-if="atDialogParam.showDialog"
          :visible="atDialogParam.showDialog"
          :position="atDialogParam.position"
          :queryString="atDialogParam.queryString"
          @handleHide="onHideAt"
          @handlePickUser="onPickUser"
          :users="users"
        />
      </template>
      <template #fallback> </template>
    </Suspense>

    <!-- <Suspense>
      <template #default>
        <HistoryDialog
          :visible="historyDialogParam.showDialog"
          :title="'聊天历史记录'"
          @handleClose="handleHistoryMessageDialog"
        />
      </template>
      <template #fallback>
        <el-empty description="description" />
      </template>
    </Suspense> -->
  </div>
</template>

<script setup lang="ts">
  const Emoji = defineAsyncComponent(() => import("@/components/Emoji/index.vue"));
  const AtDialog = defineAsyncComponent(() => import("@/components/Atdialog/index.vue"));
  // const HistoryDialog = defineAsyncComponent(() => import("@/components/History/index.vue"));
  import { useChatInput } from "@/hooks/useChatInput";

  const emojiBtnRef = ref<HTMLElement>();
  const emojiPopoverRef = ref<any>();
  const fileInputRef = ref<HTMLElement>();
  const inputContentRef = ref<HTMLElement>();

  const emit = defineEmits(["trigger"]);

  const keywordMap = [
    { keyword: "红包", effect: "redPacketPulse" },
    { keyword: "恭喜", effect: "confetti" },
    { keyword: "666", effect: "fireworks" },
    { keyword: "喜欢", effect: "hearts" },
    { keyword: "在看", effect: "emojiFloat", payload: { emoji: "👍" } }
  ];

  const users = [
    {
      userId: 100001,
      name: "any"
    }
  ];

  const ss = () => {
    const t = "在看";
    if (!t) return;
    // 检测关键词（简单包含匹配）
    for (const kv of keywordMap) {
      if (t.includes(kv.keyword)) {
        emit("trigger", kv.effect, { keyword: kv.keyword, ...(kv.payload ?? {}) });
      }
    }
  };

  const handleSendMsg = () => {
    ss();
    handleSendMessage();
  };

  const {
    pastedImages,
    historyEmojiList,
    atDialogParam,
    onHideAt,
    onPickUser,
    handleOpenFileInput,
    handleFileChange,
    handleScreenShot,
    handleCall,
    handleHistoryMessageDialog,
    handleKeyUpEvent,
    handleChooseEmoji,
    handleOpenEmoji,
    handleSelection,
    handlePaste,
    handleSendMessage
  } = useChatInput(emojiBtnRef, emojiPopoverRef, fileInputRef, inputContentRef);
</script>

<style lang="scss" scoped>
  @mixin scroll-bar($width: 8px) {
    /* 背景色为透明 */
    &::-webkit-scrollbar-track {
      border-radius: 10px;
      background-color: transparent;
    }

    &::-webkit-scrollbar {
      width: $width;
      height: 10px;
      background-color: transparent;
    }

    &::-webkit-scrollbar-thumb {
      border-radius: 10px;
      background-color: rgba(0, 0, 0, 0.2);
    }
  }

  .chat-container {
    display: flex;
    flex-direction: column;
    height: 100%;
  }

  .chat-container-tool {
    display: flex;
    height: 25px;
    padding: 5px;
    margin-left: 10px;
    // border-top: 1px solid rgba(148, 142, 142, 0.11);

    .icon-box {
      margin-right: 10px;
      cursor: pointer;

      i {
        font-size: 20px;
        color: var(--input-button-icon-color);
      }

      &:hover i {
        color: rgb(25, 166, 221);
      }
    }
  }

  .chat-container-input {
    font-size: 15px;
    color: var(--input-font-color);
    border: none;
    outline: none;
    padding: 5px 8px;
    overflow-y: auto;
    flex: 1 1 auto;
    word-break: break-all; // 解决纯字母时不自动换行问题

    &:empty:before {
      content: attr(data-placeholder);
    }

    &:focus:before {
      content: " "; // 解决无内容时聚焦没有光标
    }

    /* 可以伸缩，但只占所需空间 */
    @include scroll-bar();
  }

  .chat-container-button .button {
    height: 30px;
    width: 90px;
    margin: 0 30px 10px auto;
    border-radius: 6px;
    border: none;
    float: right;

    &:hover {
      box-shadow: 1px 1px 2px #cec5c5;
      border: 1px solid rgba(255, 255, 255, 0.8);
    }
  }
</style>
