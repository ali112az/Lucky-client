<template>
    <div class="chat-container">

        <div class="chat-container-tool">
            <div ref="emojiBtnRef" class="no-button" @click="handleOpenEmoji">
                <i class="iconfont icon-biaoqing-xue" style="font-size: 20px ;color: #6a6a6a"></i>
            </div>

            <el-popover ref="emojiPopoverRef" width="390" popper-class="emoji-popper" :virtual-ref="emojiBtnRef"
                trigger="click" placement="top" virtual-triggering>
                <emoji @handleChooseEmoji="handleChooseEmoji" :historyEmojiList="historyEmojiList"></emoji>
            </el-popover>

            <div class="no-button" @click="handleScreeenShot">
                <i class="iconfont icon-jietu1" style="font-size: 23px; color: #6a6a6a"></i>
            </div>

            <div class="no-button" @click="handleCall">
                <i class="iconfont icon-shipin1" style="font-size: 23px; color: #6a6a6a"></i>
            </div>

            <div class="no-button" @click="handleOpenFileInput">
                <i class="iconfont icon-wenjian" style="font-size: 23px;color: #6a6a6a"></i>
                <!-- https://blog.csdn.net/weixin_41674235/article/details/135079574 -->
                <input type="file" ref="fileInputRef" style="display: none;" @change="handleFileChange">
            </div>

            <div class="no-button" @click="handleMessageHistory">
                <i class="iconfont icon-liaotianjilu" style="font-size: 23px; color: #6a6a6a"></i>
            </div>
        </div>


        <!--输入框-->
        <div class="chat-container-input" ref="inputContentRef" contenteditable=true spellcheck="false" autofocus
            @click="handleSelection" @input="handleSelection" @keydown="handleKeyDown" @keyup="handkeKeyUp"
            @paste="handlePaste">
        </div>

        <!--发送按钮-->
        <div class="chat-container-button">
            <button class="chat-container-button button" @click="handleSendMessage">发送</button>
        </div>


        <!--@ 弹窗-->
        <AtDialog v-if="atDialogParam.showDialog" :visible="atDialogParam.showDialog" :position="atDialogParam.position"
            :queryString="atDialogParam.queryString" @handleHide="handleHide" @handlePickUser="handlePickUser" />

        <HistoryDialog :visible="historyDialogParam.showDialog" :title="'聊天历史记录'"
            @handleClose="handleCloseHistoryDialog" />
    </div>

</template>

<script setup lang="ts">
import onPaste from '@/utils/Paste.ts'
import emoji from '@/components/Emoji/index.vue'
// import upload from '@/components/upload/index.vue'
// import { chatMainStore } from '@/store/chat';
import AtDialog from '@/components/Atdialog/index.vue'
import HistoryDialog from '@/components/History/index.vue'
import { useMessageStore } from '@/store/modules/message';
import { useCallStore } from '@/store/modules/call'
import { storage } from "@/utils/Storage";
import { getFileType } from '@/utils/FileUpload'
// import FileUtils from '@/utils/FileUtils .js'

// const chatStore = chatMainStore();
const messageStore = useMessageStore();
const callStore = useCallStore();
const emojiBtnRef = ref(null)
const emojiPopoverRef = ref(null);
const fileInputRef = ref(null);
const inputContentRef = ref(null);
const messageList = ref([]);
const fileList = ref([])
const currentChildNodes = ref([]);//用来存储输入框中子元素
const currentSelection: any = ref(null); //用来存储输入框当前的光标对象，用于上传图片
const range = ref(null);//用来存储输入框当前的光标位置，用于上传图片,
//const limitNum:number = ref(10) //消息下行限制数

const historyEmojiList = ref([]) // 最近使用的emoji列表

const historyDialogParam = ref({
    showDialog: false,
})

const atDialogParam = ref({
    node: '',
    endIndex: '',
    position: {
        x: '',
        y: ''
    },
    queryString: '',
    showDialog: false,
    user: {}
})

// const groupMember = computed(() => {
//     return chatStore.groupMember[chatStore.currentChat.id];
// })



const handleScreeenShot = () => {
    messageStore.handleShowScreeenShot();
}

const handleCall = () => {
    callStore.handleCreateCallMessage();
}



/**
 * 发送图片消息
 * @param {*} event 
 */
const handleFileChange = (event: any) => {
    const file = event.target.files[0];
    if (!file) return;

    let type = getFileType(file.name);

    messageList.value.push({
        type: type,
        content: file,
    } as never);

    // 发送图片消息
    messageStore.handleSendMessage(messageList.value);

    messageList.value = []; // 清空消息列表
};


/**
 * 打开文件选择框
 */
const handleOpenFileInput = async () => {
    (fileInputRef.value as any).click();
}

/**
 * 隐藏 @ 弹窗
 */
const handleHide = () => {
    atDialogParam.value.showDialog = false
}

const handleMessageHistory = () => {
    historyDialogParam.value.showDialog = true;
}

const handleCloseHistoryDialog = () => {
    historyDialogParam.value.showDialog = false;
}

/**
 * 裁剪字符串
 * @param raw 输入框内容
 * @param replace 
 */
const replaceString = (raw: string, replace: string) => {
    return raw.replace(/@([^@\s]*)$/, replace);
};

// 插入标签后隐藏选择框
const handlePickUser = (user: any) => {
    replaceAtUser(user);
    atDialogParam.value.user = user;
    atDialogParam.value.showDialog = false;
};

const handkeKeyUp = (event: any) => {
    if (event.keyCode === 13) {
        //this.$emit('enter')
    }
    if (showAt()) {
        //if (showAt() && chatStore.currentChat.type == MessageType.GROUP_MESSAGE.code) {
        const node = getRangeNode();
        const endIndex = getCursorIndex();
        atDialogParam.value.node = node;
        atDialogParam.value.endIndex = endIndex;
        atDialogParam.value.position = getRangeRect();
        atDialogParam.value.queryString = getAtUser() || '';
        console.log("sss", atDialogParam.value.queryString);
        atDialogParam.value.showDialog = true;
    } else {
        atDialogParam.value.showDialog = false;
    }
}


// 获取节点
const getRangeNode = () => {
    const selection: any = window.getSelection();
    return selection.focusNode; // 选择的结束节点
};

// 获取光标位置
const getCursorIndex = () => {
    const selection: any = window.getSelection();
    return selection.focusOffset; // 选择开始处 focusNode 的偏移量
};

// 弹窗出现的位置
const getRangeRect = () => {
    const selection: any = window.getSelection();
    const range = selection.getRangeAt(0); // 是用于管理选择范围的通用对象
    const rect = range.getClientRects()[0]; // 择一些文本并将获得所选文本的范围
    console.log(rect);
    const LINE_HEIGHT = -160;
    return {
        x: rect.x,
        y: rect.y + LINE_HEIGHT
    };
};


// 创建标签
const createAtButton = (user: any) => {
    const dom = document.createElement('span')
    dom.classList.add('active-text')
    // 这里的contenteditable属性设置为false，删除时可以整块删除
    dom.setAttribute('contenteditable', 'false')
    // 将id存储在dom元素的标签上，便于后续数据处理
    dom.setAttribute('data-id', user.userId)
    dom.innerHTML = `&nbsp@${user.name}&nbsp`
    dom.style.color = 'blue'
    return dom
};


// 获取 @ 用户
const getAtUser = () => {
    const content = getRangeNode().textContent || '';
    const regx = /@([^@\s]*)$/;
    const match = regx.exec(content.slice(0, getCursorIndex()));
    if (match && match.length == 2) {
        return match[1];
    }
    return undefined;
};

const showAt = () => {
    const node = getRangeNode();
    const content = node.textContent || '';
    const regx = /@([^@\s]*)$/;
    const match = regx.exec(content.slice(0, getCursorIndex()));
    return match && match.length === 2;
};

// 插入@标签
const replaceAtUser = (user: any) => {
    const node: any = atDialogParam.value.node;
    if (node && user) {
        const content = node.textContent || '';
        const endIndex = atDialogParam.value.endIndex;
        const preSlice = replaceString(content.slice(0, endIndex), '');
        const restSlice = content.slice(endIndex);
        //const parentNode = node.parentNode;
        const nextNode = node.nextSibling;
        const previousTextNode = new Text(preSlice);
        // const nextTextNode = new Text('\u200b' + restSlice); // 添加 0 宽字符
        const nextTextNode = new Text(' ' + restSlice); // 添加 0 宽字符
        const atButton = createAtButton(user);

        inputContentRef.value.removeChild(node);
        // 插在文本框中
        if (nextNode) {
            inputContentRef.value.insertBefore(previousTextNode, nextNode);
            inputContentRef.value.insertBefore(atButton, nextNode);
            inputContentRef.value.insertBefore(nextTextNode, nextNode);
        } else {
            inputContentRef.value.appendChild(previousTextNode);
            inputContentRef.value.appendChild(atButton);
            inputContentRef.value.appendChild(nextTextNode);
        }
        // 光标移动到最后
        cursorToEnd()
    }
};



/**
 * 插入emoji表情
 * @param {*} emoji 选择的emoji
 */
const handleChooseEmoji = (emoji: string) => {
    if (emoji) {
        // 没有焦点就获取输入框焦点
        if (document.activeElement != inputContentRef.value) {
            inputContentRef.value.focus();
        }
        const textNode = document.createTextNode(emoji);
        inputContentRef.value.appendChild(textNode);

        // 保存表情到 currentChildNodes
        if (inputContentRef.value && inputContentRef.value.childNodes) {
            currentChildNodes.value = inputContentRef.value.childNodes
        }

        // 保存最近使用的emoji
        recentlyUseEmoji(emoji);
        // 光标移动到最后
        cursorToEnd()
    }
}


/**
 * 打开emoji表情弹窗
 */
const handleOpenEmoji = () => {
    unref(emojiPopoverRef).popperRef?.delayHide?.()
}


const cursorToEnd = () => {
    if (window.getSelection) {//ie11 10 9 ff safari
        inputContentRef.value.focus(); //解决ff不获取焦点无法定位问题
        var range: any = window.getSelection();//创建range
        range.selectAllChildren(inputContentRef.value);//range 选择obj下所有子内容
        range.collapseToEnd();//光标移至最后
    }
    // else if (document.getSelection as any) {//ie10 9 8 7 6 5
    //     var range = (document.selection as any).createRange();//创建选择对象
    //     //var range = document.body.createTextRange();
    //     range.moveToElementText(inputContentRef.value);//range定位到obj
    //     range.collapse(false);//光标移至最后
    //     range.select();
    // }
};

const handleKeyDown = (event: any) => {
    // 检查是否按下了回车键
    if (event.key === 'Enter' || event.keyCode === 13) {
        // 检查是否正在输入中文字符
        if (!!event.target.composing) return
        // 否则，阻止默认行为，防止插入换行
        event.cancelBubble = true
        event.stopPropagation()
        event.preventDefault();
        // 调用发送消息的方法
        handleSendMessage();
    }
};

const handleSelection = (e: any) => {
    // 获取输入框中所有的子元素
    if (e.target && e.target.childNodes) {
        currentChildNodes.value = e.target.childNodes
    }
    // 存储输入框最后输入时的光标目标及位置，用于上传图片时，图片插入光标所在位置
    currentSelection.value = window.getSelection()
    range.value = currentSelection.value.getRangeAt(0)
};



const handlePaste = async (e: any) => {
    e.preventDefault();
    const result: any = await onPaste(e)
    if (result.data.size > 2 * 1024 * 1024) {
        // this.$message.error('图片大小超过2M')
        return
    }
    if (result.type === 'string') {
        // 粘贴文本
        document.execCommand('insertText', false, result.data);
        cursorToEnd()
    } else {
        // 粘贴图片
        const imgRegx = /^data:image\/(png|jpg|jpeg|gif|svg\+xml|bmp|tif);base64,/;// 支持的图片格式
        if (imgRegx.test(result.url)) {
            fileList.value.push(result.data as never)
            // document.execCommand('insertImage', false, result.compressedDataUrl);
            const sel = window.getSelection(); // 获取当前光标位置
            if (sel && sel.rangeCount === 1 && sel.isCollapsed) {
                const range = sel.getRangeAt(0);
                const img: any = new Image();
                img.style = 'height: 90px'
                img.src = result.url; // 使用压缩后的图片
                range.insertNode(img);
                range.collapse(false);
                sel.removeAllRanges();
                sel.addRange(range);
            }
        }
    }
};



const emitChange = () => {
    // const oldMsgList = JSON.parse(JSON.stringify(messageList.value));
    // messageList.value = []; // 重置

    // 图片下标，用于获取图片文件
    let imgIndex = 0;

    currentChildNodes.value.forEach((node: any) => {
        if (node.nodeType === 1) {
            if (node.nodeName === 'BR') {
                // 处理回车
                const lastMsg: any = messageList.value[messageList.value.length - 1];
                if (lastMsg?.type === 'text') {
                    lastMsg.content += '\n';
                }
            };

            if (node.nodeName === 'SPAN') {
                // 处理@标签
                messageList.value.push({
                    type: 'at',
                    content: node.innerText
                } as never);
            };

            if (node.nodeName === 'IMG') {
                // 从文件集合中获取图片
                const file = fileList.value[imgIndex]
                if (file) {
                    // 处理图片
                    messageList.value.push({
                        type: 'image',
                        content: file,
                    } as never);

                    imgIndex++;
                }
            };
        }

        if (node.nodeType === 3 && node.nodeValue) {
            // 处理文本
            const lastMsg: any = messageList.value[messageList.value.length - 1];
            if (lastMsg?.type === 'text' || lastMsg?.type === 'at') {
                lastMsg.type = 'text';
                lastMsg.content += node.nodeValue;
            } else {
                messageList.value.push({
                    type: 'text',
                    content: node.nodeValue
                } as never);
            };
        }
    });

    // 检查是否有新消息或旧消息
    if (!messageList.value.length) {
        return;
    }
};






/**
 * 通过组件传递发送输入框的消息
 */
const handleSendMessage = async () => {
    emitChange();
    messageStore.handleSendMessage(messageList.value)
    useLogger().prettyInfo('send message', messageList.value)
    //emit("handleSendMessage", messageList.value);
    fileList.value = []
    messageList.value = [];
    currentChildNodes.value = []
    inputContentRef.value.innerHTML = ''
};




// 保存最近使用的emoji
const recentlyUseEmoji = (emoji: any) => {
    let idx = historyEmojiList.value.indexOf(emoji as never)
    if (idx < 0) {
        historyEmojiList.value.unshift(emoji as never)
    } else {
        historyEmojiList.value.unshift(historyEmojiList.value.splice(idx, 1)[0])
    }
    // 只要两行emoji(16个)
    historyEmojiList.value = historyEmojiList.value.splice(0, 16)
    // 保存记录
    storage.set('emojiHistory', JSON.stringify(historyEmojiList.value))
}

/**
 * 发送图片消息
 * @param {*} event
 */
// const handleFileChange = (event) => {
//     const file = event.target.files[0];
//     if (!file) return;
//     const fileUtils = new FileUtils()
//     const type = fileUtils.getFileType(file.name)
//     // 发送图片消息
//     emit("handleSendMessage", [{
//         type: type,
//         content: file
//     }]);
// };

// const handleOpenFileInput = () => {
//     fileInputRef.value.click();
// }


// onMounted(() => {
//     historyEmojiList.value = localStorage.getItem('emojiHistory') ? JSON.parse(localStorage.getItem('emojiHistory')) : []
// })

</script>

<style lang="scss" scoped>
/* 定义滚动条宽度 */
@mixin scroll-bar($width: 8px) {


    /* 背景色为透明 */
    &::-webkit-scrollbar-track {
        border-radius: 10px;
        background-color: transparent;
    }

    &::-webkit-scrollbar {
        width: $width;
        height: 10px;
        background-color: transparent;
    }

    &::-webkit-scrollbar-thumb {
        border-radius: 10px;
        background-color: rgba(0, 0, 0, 0.2);
    }
}

.iconfont:hover {
    color: rgb(25, 166, 221);
}

button:focus {
    outline: none;
}

button:hover {
    border: 1px rgba(255, 255, 255, 0.8) solid;
    box-shadow: 1px 1px 2px #cec5c5;
}


.chat-container {
    display: flex;
    flex-direction: column;
    height: 100%;
}

.chat-container-tool {
    height: 25px;
    border-top: 1px solid rgba(148, 142, 142, 0.11);
    padding: 5px;
    width: 100%;
    display: flex;
    line-height: 25px;

    .icon-box {
        margin-right: 10px;
        cursor: pointer;
    }

    // border: 1px solid black;
}



.chat-container-input {
    font-size: 15px;
    color: #000;
    border: none;
    outline: none;
    padding: 8px;
    overflow-y: auto;
    flex: 1 1 auto;
    word-break: break-all; // 解决纯字母时不自动换行问题

    &:empty:before {
        content: attr(data-placeholder);
    }

    &:focus:before {
        content: ' '; // 解决无内容时聚焦没有光标
    }

    /* 可以伸缩，但只占所需空间 */
    @include scroll-bar();
}

.no-button {
    background: rgba(0, 0, 0, 0);
    border-color: transparent;
    background-color: transparent;
    border: 0;
    margin: 0px 8px 0px 8px;
    cursor: pointer;
}

.chat-container-button {
    height: 40px;
    //flex: 0 1;

    .button {
        height: 30px;
        width: 90px;
        border-radius: 6px;
        border: none;
        float: right;
        margin-right: 30px;
        margin-bottom: 10px;
    }
}
</style>