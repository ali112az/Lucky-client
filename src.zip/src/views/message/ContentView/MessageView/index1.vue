<template>
  <div class="message-records" ref="messageRecordsRef">
    <VirtList
      ref="virtListRef"
      itemKey="message_id"
      :list="data"
      :minSize="64"
      :buffer="4"
      class="message-list"
      @scroll="handleScroll"
    >
      <template #default="{ itemData, index }">
        <Message :message="itemData" @handleRightClick="handleMessageRightClick">
          <template #more>
            <div v-show="index === 0 && count > 0" class="more-message-container">
              <span class="more-message no-select" @click="handleMoreMessage">{{ $t("chat.more") }}</span>
            </div>
          </template>
          <template #time>
            <div>
              <span class="message-time no-select">
                <div v-if="shouldDisplayTime(index)">
                  {{ useFriendlyTime(itemData.messageTime, "yyyy-MM-dd", true) }}
                </div>
                <div v-else-if="isTipMessage(itemData)">
                  {{ itemData.messageBody?.text }}
                </div>
              </span>
            </div>
          </template>
        </Message>
      </template>
    </VirtList>

    <el-drawer
      v-model="chatStore.isShowDetail"
      style="position: absolute"
      :title="chatStore.getCurrentName"
      size="32%"
      @close="chatStore.isShowDetail = false"
      :destroy-on-close="true"
    >
      <groupDetail v-if="isGroupMessage"></groupDetail>
      <singleDetail v-if="isSingleMessage"></singleDetail>
    </el-drawer>
  </div>
</template>

<script setup>
  import groupDetail from "@/components/ChatDetail/group.vue";
  import { MessageType, MessageContentType } from "@/constants";
  import singleDetail from "@/components/ChatDetail/single.vue";
  import { VirtList } from "vue-virt-list";
  import Message from "@/components/Message/index.vue";
  // import { useFriendlyTime } from '@/utils/Date'
  import { useChatMainStore } from "@/store/modules/chat";
  import { useTimeFormat } from "@/hooks/useTimeFormat";

  const { useFriendlyTime } = useTimeFormat();

  const chatStore = useChatMainStore();

  // 定义引用，用于 DOM 操作
  const messageRecordsRef = ref(null);
  const virtListRef = ref(null);
  const contextMenuRef = ref(null);

  // 定义事件
  const emit = defineEmits(["handleMoreMessage"]);

  // 定义组件的属性
  const props = defineProps({
    data: Array,
    count: Number
  });

  // 使用 toRefs 将 props 转换为响应式引用
  const { data } = toRefs(props);

  // 计算属性，用于判断当前消息类型
  const isGroupMessage = computed(() => chatStore.getCurrentType === MessageType.GROUP_MESSAGE.code);
  const isSingleMessage = computed(() => chatStore.getCurrentType === MessageType.SINGLE_MESSAGE.code);

  // 判断是否需要显示时间
  const shouldDisplayTime = index => {
    if (index === 0) return true;
    const currentTime = props.data[index].messageTime;
    const prevTime = props.data[index - 1].messageTime;
    return currentTime - prevTime >= 5 * 60 * 1000;
  };

  // 判断是否为提示消息
  const isTipMessage = itemData => {
    return itemData.messageContentType === MessageContentType.TIP.code;
  };

  // 处理查看更多消息的点击事件
  const handleMoreMessage = async () => {
    emit("handleMoreMessage");
  };

  // 处理滚动事件（如果需要）
  const handleScroll = () => {
    // Handle scroll logic if needed
    //contextMenuRef.value.hideContextMenu();
  };

  // 列表发生变化时，自动滚动到底部
  const handleItemResize = () => {
    virtListRef.value?.scrollToBottom();
  };

  // // 处理右键点击事件
  const handleMessageRightClick = e => {
    // const { content, event, options } = e;
    // if (contextMenuRef.value) {
    //     contextMenuRef.value.hideContextMenu();
    // }
    // contextMenuRef.value = content;
    // contextMenuRef.value.showContextMenu(event, options);
  };

  // 组件挂载时禁用右键菜单
  onMounted(() => {
    messageRecordsRef.value.addEventListener("contextmenu", e => e.preventDefault());
  });
</script>

<style lang="scss" scoped>
  /* 定义滚动条样式 */
  @mixin scroll-bar($width: 5px) {
    &::-webkit-scrollbar-track {
      border-radius: 10px;
      background-color: transparent;
    }

    &::-webkit-scrollbar {
      width: $width;
      height: 10px;
      background-color: transparent;
      transition: opacity 0.3s ease;
    }

    &::-webkit-scrollbar-thumb {
      border-radius: 10px;
      background-color: rgba(0, 0, 0, 0.2);
    }
  }

  .message-list {
    height: 100%;
    overflow-y: scroll;
    -webkit-overflow-scrolling: touch;
    overscroll-behavior: none;
    overflow-anchor: none;
    @include scroll-bar();

    &:not(:hover) {
      &::-webkit-scrollbar-thumb {
        background-color: transparent;
      }
    }
  }

  .message-records {
    height: 99%;
    margin-top: 5px;
    width: 100%;
    padding: 0 5px;
    box-sizing: border-box;
    position: relative;
  }

  .message-time {
    text-align: center;
    font-size: 12px;
    color: #ccc;
  }

  .more-message-container {
    text-align: center;
  }

  .more-message {
    margin: 5px 0 10px;
    display: inline-block;
    font-size: 12px;
    color: #539df3;
    cursor: pointer;
  }
</style>
