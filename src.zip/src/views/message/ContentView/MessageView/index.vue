<template>
  <div class="message-records" ref="messageRecordsRef" role="region" aria-label="消息记录">
    <DynamicScroller
      ref="scrollerRef"
      class="message-list"
      :items="data"
      :min-item-size="64"
      key-field="messageId"
      @scroll="handleScroll"
    >
      <template #default="{ item, index, active }">
        <DynamicScrollerItem :item="item" :index="index" :active="active">
          <Message
            :message="item"
            @handleMoreMessage="handleMoreMessage"
            :time="shouldDisplayTime(index)"
            :more="shouldDisplayMore(index) && active"
          />
        </DynamicScrollerItem>
      </template>
    </DynamicScroller>

    <!-- 底部 sentinel，用于 IntersectionObserver 检测是否在底部 -->
    <div ref="bottomSentinelRef" class="bottom-sentinel" aria-hidden="true"></div>

    <!-- 新消息提示按钮 -->
    <!-- <Transition name="fade">
      <div v-if="showNewMessageTip" class="new-message-tip" @click="scrollToBottom">
        有 {{ newMessageCount }} 条新消息，点击查看
      </div>
    </Transition> -->

    <el-drawer
      v-model="chatStore.isShowDetail"
      style="position: absolute"
      :title="chatStore.getCurrentName"
      size="32%"
      @close="chatStore.handleChatDetail"
      :destroy-on-close="true"
    >
      <GroupDetail v-if="isGroupMessage" />
      <SingleDetail v-if="isSingleMessage" />
    </el-drawer>
  </div>
</template>

<script setup lang="ts">
  import { ref, computed, watch, nextTick, onMounted, onBeforeUnmount } from "vue";
  import GroupDetail from "@/components/ChatDetail/group.vue";
  import SingleDetail from "@/components/ChatDetail/single.vue";
  import { useChatMainStore } from "@/store/modules/chat";
  import { DynamicScroller, DynamicScrollerItem } from "vue-virtual-scroller";
  import { MessageType } from "@/constants";
  import type { PropType } from "vue";
  import { useDebounceFn } from "@vueuse/core";

  // ------------------------- Props & Emits -------------------------
  const props = defineProps({
    data: {
      type: Array as PropType<any[]>,
      required: true,
      default: () => []
    },
    count: {
      type: Number,
      required: true,
      default: 0
    },
    chat: {
      type: Object as PropType<Record<string, any>>,
      required: true,
      default: () => ({})
    }
  });
  const emit = defineEmits(["handleMoreMessage"]);

  // ------------------------- Stores / Computed -------------------------
  const chatStore = useChatMainStore();
  const isGroupMessage = computed(() => chatStore.getCurrentType === MessageType.GROUP_MESSAGE.code);
  const isSingleMessage = computed(() => chatStore.getCurrentType === MessageType.SINGLE_MESSAGE.code);

  // ------------------------- Refs & Internal State -------------------------
  const scrollerRef = ref<InstanceType<typeof DynamicScroller> | null>(null);
  const messageRecordsRef = ref<HTMLElement | null>(null);
  const bottomSentinelRef = ref<HTMLElement | null>(null);

  const previousScrollHeight = ref(0);
  const previousScrollTop = ref(0);
  const isLoadingMore = ref(false);

  // 新消息提示与“是否在底部”状态
  const newMessageCount = ref(0);
  const isAtBottom = ref(true); // true 表示当前已经在底部（或非常接近）
  //const showNewMessageTip = computed(() => newMessageCount.value > 0 && !isAtBottom.value);

  // IntersectionObserver 用于检测是否在底部（更可靠）
  let io: IntersectionObserver | null = null;

  // ------------------------- Methods -------------------------
  function handleMoreMessage() {
    // 记录当前 scrollHeight 和 scrollTop（若能获取）
    const el = scrollerRef.value?.$el as HTMLElement | undefined;
    if (el) {
      previousScrollHeight.value = el.scrollHeight;
      previousScrollTop.value = el.scrollTop;
      isLoadingMore.value = true;
    }
    emit("handleMoreMessage");
  }

  function shouldDisplayMore(index: number) {
    return typeof index === "number" && index === 0 && props.count > 0;
  }

  function shouldDisplayTime(index: number): boolean {
    if (!Array.isArray(props.data)) return false;
    if (index === 0) return true;
    const curr = props.data[index];
    const prev = props.data[index - 1];
    if (!curr || !prev) return false;
    return curr.messageTime - prev.messageTime >= 5 * 60 * 1000;
  }

  /**
   * 尝试平滑滚动到底部：
   * - 优先使用 scroller 的 scrollToBottom 或 scrollToItem（如果存在）
   * - 否则对 scroller.$el 使用 scrollTop
   */
  async function scrollToBottom({ behavior = "smooth" } = { behavior: "smooth" }) {
    await nextTick();
    requestAnimationFrame(() => {
      const scroller = scrollerRef.value;
      const el = scroller?.$el as HTMLElement | undefined;
      // 优先使用组件 API（如果实现了）
      try {
        if (scroller && (scroller as any).scrollToBottom) {
          // 某些版本的 dynamic scroller 实现 this.scrollToBottom(options)
          (scroller as any).scrollToBottom({ behavior });
        } else if (typeof (scroller as any)?.scrollToItem === "function") {
          // fallback: 滚到最后一项
          const idx = props.data.length - 1;
          if (idx >= 0) (scroller as any).scrollToItem(idx);
        } else if (el) {
          // DOM fallback
          el.scrollTo({ top: el.scrollHeight, behavior: behavior as any });
        }
      } catch (e) {
        // 兜底 DOM 操作
        if (el) el.scrollTop = el.scrollHeight;
      } finally {
        // 进入底部后重置新消息计数
        newMessageCount.value = 0;
        isAtBottom.value = true;
        (scroller as any).scrollToBottom();
      }
    });
  }

  /**
   * 处理滚动事件（debounced）：
   * - 判断用户是否不在底部（避免频繁计算）
   */
  const handleScrollInner = () => {
    const el = scrollerRef.value?.$el as HTMLElement | undefined;
    if (!el) return;
    const { scrollTop, scrollHeight, offsetHeight } = el;
    // 允许一定阈值（像素）认为在底部
    const threshold = 80;
    const atBottomNow = Math.ceil(scrollTop + offsetHeight) >= scrollHeight - threshold;
    isAtBottom.value = atBottomNow;
    if (atBottomNow) {
      newMessageCount.value = 0;
    }
  };

  const handleScroll = useDebounceFn(handleScrollInner, 80);

  // ------------------------- Watchers & Lifecycle -------------------------
  onMounted(() => {
    // 创建 IntersectionObserver，root 指定为 scroller 容器（若可用）
    nextTick().then(() => {
      const scrollerEl = scrollerRef.value?.$el as HTMLElement | null;
      const rootEl = scrollerEl || messageRecordsRef.value || null;
      if (rootEl && bottomSentinelRef.value) {
        io = new IntersectionObserver(
          entries => {
            for (const entry of entries) {
              // 当 sentinel 可见度高时，说明滚动到达底部
              if (entry.isIntersecting) {
                isAtBottom.value = true;
                newMessageCount.value = 0;
              } else {
                // 只有在 sentinel 离开视口时才认为不在底部（节流由 handleScroll 管理）
                isAtBottom.value = false;
              }
            }
          },
          {
            root: rootEl,
            threshold: 0.01
          }
        );
        io.observe(bottomSentinelRef.value);
      }

      // 初次滚动到底部
      setTimeout(() => scrollToBottom({ behavior: "auto" }), 0);
    });
  });

  onBeforeUnmount(() => {
    if (io && bottomSentinelRef.value) {
      io.unobserve(bottomSentinelRef.value);
      io.disconnect();
      io = null;
    }
  });

  // 监视 data 长度变化：用于处理加载更多恢复位置 & 新消息提示
  watch(
    () => props.data.length,
    async (newLen, oldLen) => {
      await nextTick();
      const el = scrollerRef.value?.$el as HTMLElement | undefined;
      if (!el) return;

      // 加载更多场景（前端在最顶部加载历史）
      if (isLoadingMore.value) {
        // 恢复 scrollTop，避免跳动
        const delta = el.scrollHeight - previousScrollHeight.value;
        el.scrollTop = previousScrollTop.value + (delta || 0);
        isLoadingMore.value = false;
        return;
      }

      // 新消息到来
      const deltaCount = Math.max(0, newLen - (oldLen || 0));
      if (deltaCount <= 0) return;

      if (isAtBottom.value) {
        // 若在底部：自动滚到底
        await scrollToBottom({ behavior: "smooth" });
      } else {
        // 不在底部：累加提示计数
        newMessageCount.value += deltaCount;
      }
    }
  );
</script>

<style lang="scss" scoped>
  /* 滚动条样式 */
  @mixin scroll-bar($width: 6px) {
    &::-webkit-scrollbar-track {
      border-radius: 10px;
      background-color: transparent;
    }
    &::-webkit-scrollbar {
      width: $width;
      height: 10px;
      background-color: transparent;
      transition: opacity 0.3s ease;
    }
    &::-webkit-scrollbar-thumb {
      border-radius: 10px;
      background-color: rgba(0, 0, 0, 0.2);
    }
  }
  .message-records {
    height: 100%;
    width: 100%;
    position: relative;

    .message-list {
      height: 100%;
      overflow-y: auto; /* 使用 auto 更稳健 */
      -webkit-overflow-scrolling: touch;
      overscroll-behavior: none;
      overflow-anchor: none;
      @include scroll-bar();

      &:not(:hover) {
        &::-webkit-scrollbar-thumb {
          background-color: transparent;
        }
      }
    }

    .new-message-tip {
      position: absolute;
      bottom: 20px;
      right: 6%;
      background: #409eff;
      color: white;
      padding: 6px 12px;
      border-radius: 20px;
      cursor: pointer;
      font-size: 14px;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
      z-index: 10;
    }
    /* Transition 动画 */
    .fade-enter-active,
    .fade-leave-active {
      transition: opacity 0.3s ease;
    }

    .fade-enter-from,
    .fade-leave-to {
      opacity: 0;
    }
  }
  // .first-message {
  //   margin-top: 10px;
  // }

  /* 绝对定位的 sentinel：不占文档流，不影响布局 */
  .bottom-sentinel {
    position: absolute;
    left: 0;
    right: 0;
    bottom: 0;
    height: 1px; /* 必须有尺寸以便 IntersectionObserver 正常触发 */
    pointer-events: none; /* 不阻塞任何交互 */
    z-index: -1; /* 放到底下，避免覆盖内容（也可用 opacity:0） */
    opacity: 0;
  }
</style>
