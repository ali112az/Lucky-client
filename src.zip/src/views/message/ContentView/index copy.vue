<template>
  <div ref="containerRef" class="message-container" v-if="currentChat">
    <!-- 上半区：消息列表 -->
    <div ref="topRef" class="message-content">
      <MessageView
        v-show="currentChat"
        :data="messageList"
        :count="remainingQuantity"
        :chat="currentChat"
        :rowHeight="64"
        @handleMoreMessage="handleMoreMessage"
      />

      <!-- 把 EffectsManager 放在页面上，注意定位（示例中使用绝对定位覆盖聊天区） -->
      <EffectsManager ref="effectsRef" />
    </div>

    <!-- 拖拽分隔条 -->
    <div class="drag-line" @mousedown.prevent="onDragStart" />

    <!-- 下半区：输入框区域 -->
    <div ref="bottomRef" class="message-input">
      <InputView v-show="currentChat" @trigger="onTrigger" />
    </div>
  </div>
  <!-- <div v-else class="empty-chat-placeholder">
    <div class="empty-icon">💬</div>
    <div class="empty-text">请选择一个会话开始聊天</div>
  </div> -->
</template>

<script setup lang="ts">
  import { ref, toRefs, onBeforeUnmount } from "vue";
  import MessageView from "./MessageView/index.vue";
  import InputView from "./InputView/index.vue";
  import { useMessageStore } from "@/store/modules/message";
  import { useChatMainStore } from "@/store/modules/chat";
  import EffectsManager from "@/components/EffectsManager/index.vue";
  
  // 引入 Pinia store
  const chatStore = useChatMainStore();
  const msgStore = useMessageStore();

  // 解构使模板中更方便
  const { currentChat } = toRefs(chatStore);
  const { messageList, remainingQuantity } = toRefs(msgStore);

  // “加载更多” 事件透传
  const handleMoreMessage = () => {
    msgStore.handleMoreMessage();
  };

  // DOM 引用
  const containerRef = ref<HTMLElement | null>(null);
  const topRef = ref<HTMLElement | null>(null);
  const bottomRef = ref<HTMLElement | null>(null);

  // 特效
  const effectsRef = ref<any | null>(null);

  /**
   * 统一处理来自 ChatInput 的 trigger 事件
   * effectName: 'confetti'|'fireworks'|'hearts'|'emojiFloat'|'redPacketPulse'
   */
  function onTrigger(effectName: string, payload?: Record<string, any>) {
    
    if (!effectsRef.value) {
      console.warn("EffectsManager 尚未就绪");
      return;
    }

    switch (effectName) {
      case "confetti":
        effectsRef.value.playConfetti(payload);
        break;
      case "fireworks":
        effectsRef.value.playFireworks(payload);
        break;
      case "hearts":
        effectsRef.value.playHearts(payload);
        break;
      case "emojiFloat":
        effectsRef.value.playEmojiFloat(payload);
        break;
      case "redPacketPulse":
        effectsRef.value.playRedPacketPulse(payload);
        break;
      default:
        // fallback
        effectsRef.value.playConfetti(payload);
    }
  }

  // 拖拽过程使用的临时变量
  let startY = 0; // 鼠标按下时的 Y 坐标
  let startTopHeight = 0; // 鼠标按下时，上区高度
  let startBotHeight = 0; // 鼠标按下时，下区高度

  /**
   * 开始拖拽：记录初始状态并绑定鼠标事件
   */
  function onDragStart(e: MouseEvent) {
    if (!containerRef.value || !topRef.value || !bottomRef.value) return;

    startY = e.clientY;
    startTopHeight = topRef.value.offsetHeight;
    startBotHeight = bottomRef.value.offsetHeight;

    // 全局绑定，确保鼠标移出组件也能持续拖拽
    document.addEventListener("mousemove", onDragging);
    document.addEventListener("mouseup", onDragEnd);
  }

  /**
   * 拖拽中：根据鼠标移动实时调整上下区域高度
   */
  function onDragging(e: MouseEvent) {
    if (!topRef.value || !bottomRef.value) return;

    const delta = e.clientY - startY;
    const newTop = startTopHeight + delta;
    const newBot = startBotHeight - delta;

    // 限制上下区域最小高度，防止折叠过头
    const minTop = 50; // 上区最小 50px
    const minBot = 180; // 下区最小 180px

    if (newTop >= minTop && newBot >= minBot) {
      topRef.value.style.height = `${newTop}px`;
      bottomRef.value.style.height = `${newBot}px`;
    }
  }

  /**
   * 结束拖拽：移除全局鼠标事件
   */
  function onDragEnd() {
    document.removeEventListener("mousemove", onDragging);
    document.removeEventListener("mouseup", onDragEnd);
  }

  // 组件卸载前移除监听，防止内存泄露
  onBeforeUnmount(() => {
    document.removeEventListener("mousemove", onDragging);
    document.removeEventListener("mouseup", onDragEnd);
  });
</script>

<style scoped lang="scss">
  .message-container {
    display: flex;
    flex-direction: column;
    height: 100%; // 父容器要有高度
    overflow: hidden;

    .message-content {
      /* 初始占比：可在父级或 JS 中动态设置 */
      height: 70%;
      overflow: auto;
    }

    .drag-line {
      height: 1px;
      background-color: var(--content-drag-line-color);
      cursor: ns-resize;
      user-select: none;
      z-index: 10;
    }

    .message-input {
      height: 30%;
      overflow: auto;
    }
  }
  .empty-chat-placeholder {
    height: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    color: #bbb;
    font-size: 18px;
    .empty-icon {
      font-size: 48px;
      margin-bottom: 12px;
    }
    .empty-text {
      font-size: 18px;
    }
  }
</style>
