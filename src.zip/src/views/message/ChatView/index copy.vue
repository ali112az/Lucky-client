<template>
  <div class="vl-box" ref="boxRef" role="list" aria-busy="isLoading">
    <!-- 大容器占位，确保滚动条长度正确 -->
    <div :style="{ height: totalHeight + 'px', position: 'relative' }">
      <!-- 可见项容器：用 transform 位移到 startIndex*rowHeight，内部每项使用 normal flow -->
      <div
        class="vl-visible"
        :style="{
          transform: `translateY(${translateY}px)`,
          position: 'absolute',
          left: 0,
          right: 0
        }"
      >
        <div
          v-for="(itemWrapper, i) in visible"
          :key="itemWrapper.item.chatId"
          class="vl-box-item"
          :style="{ height: rowHeight + 'px' }"
        >
          <div
            class="item"
            :class="{ pinned: itemWrapper.item.isTop == 1 }"
            @click="handleChooseChat(itemWrapper.item)"
            v-context-menu="getMenuConfig(itemWrapper.item)"
            role="listitem"
          >
            <ItemView :data="itemWrapper.item" />
          </div>
        </div>

        <!-- 若正在加载而可见区域不足，显示占位骨架行 -->
        <template v-if="isLoading">
          <div v-for="n in skeletonCount" :key="'skeleton-' + n" class="vl-box-item skeleton" :style="{ height: rowHeight + 'px' }">
            <div class="skeleton-line"></div>
          </div>
        </template>
      </div>
    </div>

    <!-- 顶层加载覆盖层（居中 spinner + 文案） -->
    <div v-if="isLoading && showOverlay" class="vl-loading-overlay">
      <div class="spinner"></div>
      <div class="loading-text">加载中...</div>
    </div>

    <!-- 空状态 -->
    <div v-if="!isLoading && totalCount === 0" class="vl-empty">暂无会话</div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, shallowRef, onMounted, onBeforeUnmount, watch, nextTick, defineExpose } from "vue";
import ItemView from "./ItemView/index.vue";
import { useChatMainStore } from "@/store/modules/chat";
import { useMessageStore } from "@/store/modules/message";
import type Chats from "@/database/entity/Chats";
import { ElMessageBox } from "element-plus";
import { useMediaCacheStore } from "@/store/modules/media";

const chatStore = useChatMainStore();
const messageStore = useMessageStore();
const mediaStore = useMediaCacheStore();

// ====== 配置项（可按需调整） ======
const rowHeight = 60; // 行高（必须固定）
const overscan = 3; // 向上下各预渲染多少行
const showOverlay = false; // 是否显示全局 loading overlay（true 会遮罩）
const prefetchDistancePx = 300; // 距离底部多少触发 needMore 事件
const skeletonCount = 6; // overlay skeleton 行数（在较短列表上显示占位）
// =================================

// DOM refs
const boxRef = ref<HTMLElement | null>(null);

// 状态
const isLoading = ref(false); // 加载状态（外部可通过 store 或事件控制）
const containerHeight = ref(0);
const scrollTop = ref(0);

// 使用 shallowRef 缓存不可变快照（避免深度响应式带来的性能开销）
// 当 chatStore.chatList 长度或明确刷新时，我们更新 snapshot。
const snapshot = shallowRef<Chats[]>([]);

// total count and height
const totalCount = computed(() => snapshot.value.length);
const totalHeight = computed(() => totalCount.value * rowHeight);

// visible window calculation
const visibleCount = computed(() => {
  // +1 防止边界空白，乘以 1 for safe
  return Math.ceil(containerHeight.value / rowHeight) + overscan * 2 + 1;
});

const startIndex = computed(() => {
  const top = Math.floor(scrollTop.value / rowHeight) - overscan;
  return Math.max(0, Math.min(Math.max(0, totalCount.value - 1), top));
});

const endIndex = computed(() => {
  const end = startIndex.value + visibleCount.value;
  return Math.max(0, Math.min(totalCount.value, end));
});

// 需要渲染的数据片段（含绝对索引）
const visible = computed(() => {
  if (!snapshot.value.length) return [] as { item: Chats; absIndex: number }[];
  const slice = snapshot.value.slice(startIndex.value, endIndex.value);
  return slice.map((item, i) => ({ item, absIndex: startIndex.value + i }));
});

// translateY for inner container
const translateY = computed(() => startIndex.value * rowHeight);

// 控制 skeleton 展示数（仅样式）
const skeletonCountRef = computed(() => skeletonCount);

// ====== 性能友好的滚动处理 ======
let rafId: number | null = null;
function onScrollHandler() {
  if (rafId !== null) cancelAnimationFrame(rafId);
  rafId = requestAnimationFrame(() => {
    if (!boxRef.value) return;
    const st = boxRef.value.scrollTop;
    scrollTop.value = st;
    rafId = null;

    // 触发 near-bottom prefetch
    const remaining = totalHeight.value - (st + containerHeight.value);
    if (remaining <= prefetchDistancePx && totalCount.value > 0) {
      // 发出事件，告诉父组件需要加载更多
      emitNeedMore();
    }
  });
}

// passive listener + attach native listener for best perf
function attachScroll() {
  if (!boxRef.value) return;
  boxRef.value.addEventListener("scroll", onScrollHandler, { passive: true });
}
function detachScroll() {
  if (!boxRef.value) return;
  boxRef.value.removeEventListener("scroll", onScrollHandler);
  if (rafId !== null) {
    cancelAnimationFrame(rafId);
    rafId = null;
  }
}

// ====== ResizeObserver：动态计算容器高度（更精确） ======
let ro: ResizeObserver | null = null;
function attachResizeObserver() {
  if (!boxRef.value || typeof ResizeObserver === "undefined") {
    // fallback to window.innerHeight (already used initially)
    containerHeight.value = boxRef.value ? boxRef.value.clientHeight : window.innerHeight;
    return;
  }
  ro = new ResizeObserver(entries => {
    for (const e of entries) {
      const h = (e.contentRect && e.contentRect.height) || (boxRef.value ? boxRef.value.clientHeight : 0);
      containerHeight.value = Math.max(0, Math.floor(h));
    }
  });
  ro.observe(boxRef.value);
}
function detachResizeObserver() {
  if (ro && boxRef.value) {
    ro.unobserve(boxRef.value);
    ro = null;
  }
}

// ====== 快速 snapshot 管理（避免深度响应） ======
let lastListVersion = 0;
function refreshSnapshot(force = false) {
  // 只在长度变或强制刷新时更新 snapshot，避免每次 store 变动触发大量渲染
  const list = chatStore.chatList;
  // 这里假设 chatStore 里有一个 version 或 time 可做更优判定；若没有，基于 length 比较
  if (!force && snapshot.value.length === list.length) {
    // 但如果你需要响应内容变化，可以把此条件放宽或在外部调用 refresh(true)
    return;
  }
  snapshot.value = list.slice();
  lastListVersion++;
}

// 对外暴露 refresh 方法
defineExpose({ refresh: () => refreshSnapshot(true), setLoading: (v: boolean) => (isLoading.value = v) });

// 触发父组件加载更多（通过自定义事件）
const emitNeedMore = () => {
  // 这里直接使用 CustomEvent 派发到 DOM，父组件可监听或你改为发 store action / emit
  // 例如：boxRef.value?.dispatchEvent(new CustomEvent('needMore'))
  // 更简单：调用 chatStore 的加载方法或 emit event via global event bus
  // 为兼容性，我们触发一个 DOM 事件，可在父组件上用 @needMore 监听（需使用 addEventListener）
  if (!boxRef.value) return;
  try {
    boxRef.value.dispatchEvent(new CustomEvent("needMore", { detail: {} }));
  } catch {}
};

// ======= 右键菜单 & 点击逻辑（保持你原来的实现） =======
const getMenuConfig = (item: Chats) => {
  const config = shallowRef<{ options: any[]; callback: (a: string) => Promise<void> }>({
    options: [],
    callback: async () => {}
  });

  // 使用非深度响应，避免监听 item 的每次微改
  config.value.options = [
    { label: item.isTop === 1 ? "取消置顶" : "置顶会话", value: "pin" },
    { label: "删除会话", value: "delete" }
  ];

  config.value.callback = async (action: string) => {
    try {
      if (action === "delete") {
        await ElMessageBox.confirm(`确定删除与 ${item.name} 的会话?`, "删除会话", {
          distinguishCancelAndClose: true,
          confirmButtonText: "确认",
          cancelButtonText: "取消"
        });
        await chatStore.handleDeleteChat(item);
      } else if (action === "pin") {
        await chatStore.handlePinChat(item);
      }
    } catch {
      /* cancel */
    }
  };

  return config.value;
};

const handleChooseChat = async (item: Chats) => {
  // 尽量减少 await 链造成的卡顿感：先触发同步 UI 状态，然后并行加载
  messageStore.handleReset();
  // 异步并行执行耗时操作
  mediaStore.initStorage(item.toId);
  chatStore.handleChangeCurrentChat(item);
  messageStore.handleGetMessageList(item);
  chatStore.handleUpdateReadStatus(item);
};

// ====== 生命周期挂载/卸载 ======
onMounted(() => {
  // 初始化 snapshot
  refreshSnapshot(true);

  // attach listeners
  nextTick(() => {
    attachScroll();
    attachResizeObserver();
    // 初始化 containerHeight
    if (boxRef.value) containerHeight.value = boxRef.value.clientHeight || window.innerHeight;
  });

  // 监控 chatStore 长度变化（轻量）
  // 这里只监听 length 变更以避免频繁更新 snapshot；若你需要更细粒度，可放宽条件。
  watch(
    () => chatStore.chatList.length,
    () => {
      refreshSnapshot(true);
    }
  );
});

onBeforeUnmount(() => {
  detachScroll();
  detachResizeObserver();
});

// 允许外部通过 DOM 事件触发刷新或加载控制
// 例如：boxRef.value?.addEventListener('setLoading', e => isLoading.value = e.detail)
</script>

<style lang="scss" scoped>
@import "@/assets/style/scss/index.scss";

.vl-box {
  border-right: 1px solid var(--side-border-right-color);
  overflow-y: auto;
  height: 100%;
  position: relative;
  @include scroll-bar();
}

.vl-box > div {
  position: relative;
  overflow: hidden;
}

/* visible container holds the actual nodes and is transformed for position */
.vl-visible {
  width: 100%;
  will-change: transform;
}

/* each item is in normal flow inside the visible container */
.vl-box-item {
  box-sizing: border-box;
  width: 100%;
}

/* content */
.item {
  cursor: pointer;
  user-select: none;
  transition: background 0.12s;
  height: 100%;
  display: flex;
  align-items: center;
  padding: 0 12px;
}

.pinned {
  background-color: var(--side-active-bg-color);
  color: var(--side-active-color);
}

/* skeleton */
.skeleton {
  padding: 10px 12px;
}
.skeleton-line {
  height: 14px;
  width: 60%;
  background: linear-gradient(90deg, rgba(0,0,0,0.06) 0%, rgba(0,0,0,0.03) 50%, rgba(0,0,0,0.06) 100%);
  border-radius: 6px;
}

/* loading overlay (centered) */
.vl-loading-overlay {
  position: absolute;
  left: 0;
  right: 0;
  top: 0;
  bottom: 0;
  display: flex;
  gap: 12px;
  align-items: center;
  justify-content: center;
  background: rgba(255, 255, 255, 0.6);
  z-index: 20;
  pointer-events: none;
}
.spinner {
  width: 28px;
  height: 28px;
  border-radius: 50%;
  border: 3px solid rgba(0,0,0,0.1);
  border-top-color: rgba(0,0,0,0.4);
  animation: spin 1s linear infinite;
}
.loading-text {
  font-size: 13px;
  color: var(--muted-color);
}
@keyframes spin {
  to { transform: rotate(360deg); }
}

/* empty state */
.vl-empty {
  position: absolute;
  left: 0;
  right: 0;
  top: 50%;
  transform: translateY(-50%);
  text-align: center;
  color: var(--muted-color);
  font-size: 14px;
}
</style>
