<template>
  <div class="requests-fullscreen" role="region" aria-label="好友申请列表">
    <!-- Header (固定顶部) -->
    <header class="requests-header" role="banner" aria-live="polite">
      <div class="header-inner">
        <div class="title">好友申请</div>
        <div class="subtitle">
          你有 <strong>{{ pendingCount }}</strong> 条待处理申请
        </div>
        <div class="actions">
          <!-- 可放置刷新按钮、返回等 -->
          <el-button type="text" size="small" @click="refresh" aria-label="刷新申请列表">
            <i class="iconfont icon-refresh" /> 刷新
          </el-button>
        </div>
      </div>
    </header>

    <!-- 主体列表（滚动区） -->
    <main class="requests-body" role="main">
      <div v-if="!hasRequests" class="empty-state" role="status">当前没有好友申请</div>

      <ul v-else class="requests-list" role="list" aria-label="好友申请列表">
        <li
          v-for="(req, idx) in displayRequests"
          :key="req.id"
          class="request-item"
          role="listitem"
          :aria-label="`好友申请，来自 ${req.name}`"
        >
          <div class="left">
            <el-avatar :size="64" :src="req.avatar" class="req-avatar" :aria-hidden="false">
              <template #default>
                <div class="avatar-fallback">{{ initials(req.name) }}</div>
              </template>
            </el-avatar>
          </div>

          <div class="center">
            <div class="name">{{ req.name }}</div>
            <div class="message" v-if="req.message">{{ req.message }}</div>
            <div class="message muted" v-else>请求添加你为好友</div>
          </div>

          <div class="right">
            <template v-if="localState[req.id]?.status === 'pending'">
              <el-button
                size="small"
                type="primary"
                :loading="localState[req.id]?.loadingAccept"
                @click="onAccept(req)"
                aria-label="同意好友申请"
              >
                同意
              </el-button>

              <el-button
                size="small"
                :loading="localState[req.id]?.loadingReject"
                @click="onReject(req)"
                aria-label="拒绝好友申请"
              >
                拒绝
              </el-button>
            </template>

            <template v-else>
              <span
                class="result-badge"
                :class="{
                  accepted: localState[req.id]?.status === 'accepted',
                  rejected: localState[req.id]?.status === 'rejected'
                }"
                aria-live="polite"
              >
                {{ localState[req.id]?.status === "accepted" ? "已同意" : "已拒绝" }}
              </span>
            </template>
          </div>
        </li>
      </ul>
    </main>

    <!-- footer 可选 -->
    <!-- <footer class="requests-footer" role="contentinfo">
      <div class="footer-inner">好友申请 · 全屏视图</div>
    </footer> -->
  </div>
</template>

<script setup lang="ts">
  /**
   * FullscreenFriendRequests.vue
   *
   * 全屏好友申请页面（与 groups 页面风格一致，但为全屏布局）。
   * 关键点：使用 localState 管理 UI 状态，避免 computed 副本导致状态丢失或重复渲染。
   */

  import { shallowReactive, computed, watch, onMounted } from "vue";
  import { ElMessage, ElMessageBox } from "element-plus";
  import { useFriendsStore } from "@/store/modules/friends";

  /** 请求类型（按后台返回字段调整） */
  type FriendRequest = {
    id: string;
    fromId?: string;
    toId?: string;
    name?: string;
    avatar?: string;
    message?: string;
  };

  /** 本地 UI 状态类型 */
  type LocalUiState = {
    status: "pending" | "accepted" | "rejected";
    loadingAccept: boolean;
    loadingReject: boolean;
  };

  /* -------------------- store & data wiring -------------------- */
  const friendStore = useFriendsStore() as any; // as any 以兼容不同 store 定义

  /* rawRequests：直接引用 store 的列表（不要在这里 clone 对象） */
  const rawRequests = computed<FriendRequest[]>(() => {
    // 尽量兼容几种命名
    return friendStore.newFriends ?? friendStore.requests ?? friendStore.friendRequests ?? [];
  });

  /* localState：响应式 map，用 request.id 作为 key 保存 UI 状态 */
  const localState = shallowReactive<Record<string, LocalUiState>>({});

  /** helper：确保给某条请求初始化 localState（不会修改 store） */
  function ensureLocalStateFor(req?: Partial<FriendRequest> & { id?: string }) {
    const id = req?.id ?? "";
    if (!id) return;
    if (!localState[id]) {
      localState[id] = {
        status: (req as any).__local?.status ?? "pending",
        loadingAccept: false,
        loadingReject: false
      };
    }
  }

  /* 监听 store 列表，初始化 localState，并清理已删除项 */
  watch(
    rawRequests,
    list => {
      (list || []).forEach((r: any) => ensureLocalStateFor(r));
      // 清理：移除 localState 中不再存在的 id（避免内存增长）
      const ids = new Set((list || []).map((r: any) => r.id));
      Object.keys(localState).forEach(k => {
        if (!ids.has(k)) delete localState[k];
      });
      if (!friendStore.ignore) friendStore.ignore = true;
    },
    { immediate: true }
  );

  /* displayRequests 直接返回 store 数据（模板从 localState 读取 UI 状态） */
  const displayRequests = computed(() => rawRequests.value || []);
  const hasRequests = computed(() => displayRequests.value.length > 0);
  const pendingCount = computed(
    () => displayRequests.value.filter(r => (localState[r.id]?.status ?? "pending") === "pending").length
  );

  /* onMounted：尝试触发 store 的加载方法（如果存在） */
  // onMounted(() => {
  //   try {
  //     if (typeof friendStore.loadNewFriends === "function") {
  //       friendStore.loadNewFriends();
  //     }
  //   } catch (err) {
  //     // 兜底：不要阻塞渲染
  //     console.warn("调用 friendStore.loadNewFriends 失败：", err);
  //   }
  // });

  /* -------------------- UI helpers -------------------- */
  function initials(name?: string) {
    const n = (name ?? "").trim();
    if (!n) return "#";
    const first = n[0];
    return /[A-Za-z0-9]/.test(first) ? first.toUpperCase() : first;
  }

  /* -------------------- 操作：同意 / 拒绝 -------------------- */
  /**
   * 设计：
   * - 优先查找并调用 store 中的 action（常见命名列在 possibleActions）
   * - 假设 store action 会在成功时更新 store.newFriends（移除或标记），组件由 watch 同步 UI
   * - 若找不到 store action，则使用本地模拟（短延时），并以 localState 标记
   * - 防重复点击：通过 loading flag 与 status 检查
   */

  const acceptActionCandidates = [
    "acceptFriendRequest",
    "approveFriendRequest",
    "handleApproveRequest",
    "handleAcceptNewFriend"
  ];
  const rejectActionCandidates = [
    "rejectFriendRequest",
    "refuseFriendRequest",
    "handleRejectRequest",
    "handleRefuseNewFriend"
  ];

  async function onAccept(req: FriendRequest) {
    if (!req?.id) return;
    ensureLocalStateFor(req);
    const s = localState[req.id];
    if (!s || s.loadingAccept || s.status !== "pending") return;
    s.loadingAccept = true;

    try {
      const actionName = acceptActionCandidates.find(n => typeof friendStore[n] === "function");
      if (actionName) {
        // 调用 store action（期望它完成后更新 store.newFriends）
        await friendStore[actionName](req.id);
      } else {
        // 回退本地模拟：若无后端/store，做乐观更新
        console.warn("未在 friendStore 中找到 accept action，使用本地模拟（请替换为真实 action）");
        await new Promise(r => setTimeout(r, 600));
      }

      // 标记成功（如果 store 会自动从列表中移除，这一步只作为 UI 兜底）
      s.status = "accepted";
      ElMessage.success(`已同意 ${req.name} 的好友申请`);
    } catch (err) {
      console.error("accept error:", err);
      ElMessage.error("同意失败，请稍后重试");
    } finally {
      s.loadingAccept = false;
    }
  }

  async function onReject(req: FriendRequest) {
    if (!req?.id) return;
    ensureLocalStateFor(req);
    const s = localState[req.id];
    if (!s || s.loadingReject || s.status !== "pending") return;

    // 确认对话（可选）
    try {
      await ElMessageBox.confirm(`确定要拒绝来自 ${req.name} 的好友申请吗？`, "拒绝好友申请", {
        confirmButtonText: "确认拒绝",
        cancelButtonText: "取消",
        type: "warning"
      });
    } catch (e) {
      // 用户取消或关闭，直接返回
      return;
    }

    s.loadingReject = true;
    try {
      const actionName = rejectActionCandidates.find(n => typeof friendStore[n] === "function");
      if (actionName) {
        await friendStore[actionName](req.id);
      } else {
        console.warn("未在 friendStore 中找到 reject action，使用本地模拟（请替换为真实 action）");
        await new Promise(r => setTimeout(r, 500));
      }
      s.status = "rejected";
      ElMessage.success(`已拒绝 ${req.name} 的好友申请`);
    } catch (err) {
      console.error("reject error:", err);
      ElMessage.error("拒绝失败，请稍后重试");
    } finally {
      s.loadingReject = false;
    }
  }

  /* 小工具：手动刷新（触发 store 的加载方法） */
  function refresh() {
    try {
      friendStore.loadNewFriends();
      ElMessage.success("刷新中...");
    } catch (err) {
      console.warn("刷新失败：", err);
      ElMessage.error("刷新失败");
    }
  }
</script>

<style scoped lang="scss">
  /* 定义滚动条宽度 */
  @mixin scroll-bar($width: 5px) {
    &::-webkit-scrollbar-track {
      border-radius: 10px;
      background-color: transparent;
    }

    &::-webkit-scrollbar {
      width: $width;
      height: 10px;
      background-color: transparent;
    }

    &::-webkit-scrollbar-thumb {
      border-radius: 10px;
      background-color: rgba(0, 0, 0, 0.3);
    }
  }

  /* 全屏布局（头部固定，主体滚动） */
  .requests-fullscreen {
    height: calc(100vh - 65px);
    display: flex;
    flex-direction: column;
    background: var(--side-bg, #f7f9fc);
    color: #111827;
  }

  /* header 固定在顶部 */
  .requests-header {
    position: sticky;
    top: 0;
    z-index: 20;
    background: #ffffff;
    border-bottom: 1px solid rgba(15, 23, 42, 0.06);
    padding: 14px 20px;
    box-shadow: 0 1px 0 rgba(0, 0, 0, 0.02);
  }
  .header-inner {
    display: flex;
    align-items: center;
    gap: 16px;
    justify-content: space-between;
  }
  .title {
    font-size: 18px;
    font-weight: 700;
  }
  .subtitle {
    color: #6b6b6b;
    font-size: 13px;
  }
  .actions {
    display: flex;
    gap: 8px;
    align-items: center;
  }

  /* 滚动主体 */
  .requests-body {
    flex: 1 1 auto;
    overflow: auto;
    padding: 18px 20px;
    @include scroll-bar();
  }

  /* 列表与条目 */
  .requests-list {
    display: flex;
    flex-direction: column;
    gap: 12px;
    padding: 4px 0;
    list-style: none;
    margin: 0;
  }
  .request-item {
    display: flex;
    align-items: center;
    gap: 16px;
    padding: 12px;
    border-radius: 10px;
    background: #ffffff;
    box-shadow: 0 4px 12px rgba(11, 22, 39, 0.04);
  }
  .left {
    width: 64px;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .center {
    flex: 1 1 auto;
    min-width: 0;
  }
  .name {
    font-weight: 600;
    font-size: 15px;
    color: #0f1724;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .message {
    margin-top: 6px;
    color: #6b6b6b;
    font-size: 13px;
  }
  .message.muted {
    color: #9aa0a6;
  }
  .right {
    width: 200px;
    display: flex;
    gap: 8px;
    align-items: center;
    justify-content: flex-end;
  }

  /* result badge */
  .result-badge {
    padding: 6px 12px;
    border-radius: 999px;
    color: #fff;
    font-size: 13px;
  }
  .result-badge.accepted {
    background: linear-gradient(90deg, #34c759, #0fbf5a);
  }
  .result-badge.rejected {
    background: linear-gradient(90deg, #e55353, #c94141);
  }

  /* avatar */
  .req-avatar {
    border-radius: 8px !important;
    width: 64px !important;
    height: 64px !important;
    overflow: hidden;
  }
  .avatar-fallback {
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 22px;
    font-weight: 700;
    color: #fff;
    background: linear-gradient(135deg, #7cc0ff, #4aa3ff);
    border-radius: 8px;
  }

  /* empty state */
  .empty-state {
    padding: 48px;
    text-align: center;
    color: #8b8b8b;
    font-size: 15px;
  }

  /* footer */
  .requests-footer {
    padding: 10px 20px;
    text-align: center;
    color: #9aa0a6;
    font-size: 13px;
    border-top: 1px solid rgba(15, 23, 42, 0.03);
  }

  /* small screen adjustments */
  @media (max-width: 640px) {
    .request-item {
      padding: 10px;
      gap: 10px;
    }
    .right {
      width: 140px;
    }
    .req-avatar {
      width: 56px !important;
      height: 56px !important;
    }
  }
</style>
