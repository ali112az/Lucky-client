<template>
  <div class="video-call-header" data-tauri-drag-region>
    <el-row style="height: 30px">
      <el-col :span="20" data-tauri-drag-region></el-col>
      <el-col :span="4">
        <system about-visible @handleClose="handUp" />
      </el-col>
    </el-row>
  </div>

  <el-container class="meeting-page">
    <!-- 左侧视频展示区域 -->
    <el-main class="video-section">
      <div class="video-grid">
        <!-- 视频组件 自动播放 ，如果用户是自己 静音 -->
        <video
          v-for="userId in activeUsers"
          :key="userId"
          :ref="el => setRef(el, userId)"
          class="video-window"
          :muted="userId === userStore.userId"
          autoplay
        ></video>
      </div>

      <!-- 折叠按钮 -->
      <el-button class="toggle-chat-btn" @click="toggleChat">
        <el-icon :size="20">
          <Plus v-if="isChatCollapsed" />
          <Minus v-else />
        </el-icon>
      </el-button>
    </el-main>

    <!-- 右侧聊天区域 -->
    <el-aside v-if="!isChatCollapsed" width="20%" class="chat-section">
      <el-card style="height: 100%" class="chat-card">
        <h3>聊天区</h3>
        <div class="chat-messages">
          <div v-for="(msg, index) in messages" :key="index" class="message">
            <span>{{ msg.user }}:</span> {{ msg.body }}
          </div>
        </div>

        <!-- 固定输入框到底部 -->
        <div class="chat-input">
          <el-input v-model="newMessage" placeholder="输入消息..." @keyup.enter="sendMessage">
            <template #append>
              <el-button @click="sendMessage" type="primary">发送</el-button>
            </template>
          </el-input>
        </div>
      </el-card>
    </el-aside>
  </el-container>
</template>
<script setup lang="ts">
  import { ref, nextTick, onMounted, onBeforeUnmount } from "vue";
  import { useCallStore } from "@/store/modules/call";
  import { useUserStore } from "@/store/modules/user";
  import WebRTC from "@/utils/WebRTC";
  import System from "@/components/System/index.vue";
  import { getCurrentWindow } from "@tauri-apps/api/window";

  /**
   * 配置项
   * - heartbeatIntervalMs: 心跳间隔
   * - initialReconnectDelayMs: 重连初始延迟（指数退避会基于此乘以 2^n）
   */
  const WebRTCPublishParam = {
    httpPublish: `${import.meta.env.VITE_API_SERVER_SRS}/publish/`,
    httpPlay: `${import.meta.env.VITE_API_SERVER_SRS}/play/`,
    webrtc: `${import.meta.env.VITE_API_SERVER_WEBRTC}`,
    audio: {
      echoCancellationType: "system",
      echoCancellation: true,
      noiseSuppression: true,
      autoGainControl: false,
      sampleRate: 24000,
      sampleSize: 16,
      channelCount: 2,
      volume: 0.5
    },
    video: {
      frameRate: { min: 30 },
      width: { min: 640, ideal: 1080 },
      height: { min: 360, ideal: 720 },
      aspectRatio: 16 / 9
    }
  };

  const callStore = useCallStore();
  const userStore = useUserStore();

  // WebRTC 实例（封装好的工具）
  const webRTC = ref(new WebRTC(WebRTCPublishParam));

  // 活跃用户列表（userId 字符串）
  const activeUsers = ref<string[]>([]);

  // 使用 Map 管理 video 元素引用，避免 index/refs 混乱
  const videoRefs = ref<Map<string, HTMLVideoElement>>(new Map());

  // 聊天消息
  const messages = ref<{ user: string; body: string }[]>([]);
  const newMessage = ref("");
  const isChatCollapsed = ref(true);

  // WebSocket / 心跳 / 重连相关
  let socket: WebSocket | null = null;
  let heartbeatTimer: number | null = null;
  let reconnectAttempts = 0;
  const maxReconnectAttempts = 10;
  const heartbeatIntervalMs = 5000; // 心跳 5s
  const initialReconnectDelayMs = 1000; // 初始重连延迟 1s

  // 防重入标记，防止重复 publish/pull
  const publishing = ref<Set<string>>(new Set());
  const pulling = ref<Set<string>>(new Set());

  /** 辅助：安全播放 video（兼容 autoplay 限制） */
  async function safePlayVideo(video?: HTMLVideoElement | null) {
    if (!video) return;
    try {
      // 尝试设置 playsinline 以支持移动端
      video.setAttribute?.("playsinline", "true");
      await video.play();
    } catch (err) {
      // autoplay 可能被阻止，忽略错误（也可在此触发 UI 提示）
      console.debug("safePlayVideo:", err);
    }
  }

  /** 将模板的 ref 回调统一到 Map（v-for 中使用 setRef(el, userId)） */
  function setRef(el: Element | null | any, userId: string) {
    // 仅保存 HTMLVideoElement
    if (!(el instanceof HTMLVideoElement)) return;
    videoRefs.value.set(userId, el);
  }

  /** 切换聊天折叠状态 */
  function toggleChat() {
    isChatCollapsed.value = !isChatCollapsed.value;
  }

  /** 发送消息到服务器（通过 WebSocket） */
  function sendWebSocketMessage(payload: Record<string, any>) {
    if (!socket) return;
    if (socket.readyState !== WebSocket.OPEN) return;
    try {
      socket.send(JSON.stringify(payload));
    } catch (err) {
      console.error("sendWebSocketMessage send error:", err);
    }
  }

  /** 处理新消息发送（点击/回车） */
  function sendMessage() {
    const body = newMessage.value.trim();
    if (!body || !socket || socket.readyState !== WebSocket.OPEN) return;
    sendWebSocketMessage({
      type: "signal",
      roomId: callStore.roomId,
      userId: userStore.userId,
      body
    });
    newMessage.value = "";
  }

  /** 处理用户加入：如果是自己则 publish，否则 pull */
  async function handleUserJoin(userId: string) {
    if (!userId) return;
    if (activeUsers.value.includes(userId)) return;

    // 添加到活跃列表
    activeUsers.value.push(userId);

    // 等待 DOM 更新，确保 videoRef 已设置
    await nextTick();

    const videoEl = videoRefs.value.get(userId);
    if (!videoEl) {
      // video 元素可能尚未挂载，后续 will be handled when setRef 被调用
      return;
    }

    try {
      if (userId === userStore.userId) {
        // 本人：发布本地流（避免重复 publish）
        if (!publishing.value.has(userId)) {
          publishing.value.add(userId);
          await webRTC.value.publish(userId, videoEl);
          await safePlayVideo(videoEl);
        }
      } else {
        // 他人：拉流
        if (!pulling.value.has(userId)) {
          pulling.value.add(userId);
          await webRTC.value.pull(userId, videoEl);
          await safePlayVideo(videoEl);
        }
      }
    } catch (err) {
      console.error(`handleUserJoin(${userId}) error:`, err);
      // 出错时清理标记，允许后续重试
      publishing.value.delete(userId);
      pulling.value.delete(userId);
    }
  }

  /** 处理用户离开：移除 video、停止拉流/取消拉流 */
  function handleUserLeave(userId: string) {
    // 从活跃数组里移除
    activeUsers.value = activeUsers.value.filter(id => id !== userId);

    // 停止拉流并从 refs 删除
    try {
      // 如果我们有 webRTC.removePull，调用它以释放资源
      try {
        webRTC.value.removePull?.(userId);
      } catch (e) {
        console.warn("removePull error:", e);
      }
    } finally {
      // 清除本地引用与状态标记
      videoRefs.value.delete(userId);
      publishing.value.delete(userId);
      pulling.value.delete(userId);
    }
  }

  /** 处理服务端广播的消息（WebSocket onmessage）*/
  function handleServerMessage(evt: MessageEvent) {
    try {
      const msg = JSON.parse(evt.data);
      switch (msg.type) {
        case "join":
          // join 消息中可能带有当前房间用户列表
          if (Array.isArray(msg.users)) {
            for (const u of msg.users) {
              // 假设每个 u 具有 userId 字段
              if (u?.userId) handleUserJoin(u.userId);
            }
          }
          break;
        case "leave":
          handleUserLeave(msg.userId);
          break;
        case "signal":
          // 聊天信令消息
          messages.value.push({ user: msg.userId, body: msg.body });
          break;
        default:
          console.debug("unknown ws message:", msg);
      }
    } catch (err) {
      console.error("parse ws message failed:", err);
    }
  }

  /** 启动 WebSocket 连接（包含重连逻辑） */
  function initializeWebSocket() {
    // 如果超过最大重连次数则停止重连
    if (reconnectAttempts > maxReconnectAttempts) {
      console.error("已超过最大重连次数，停止重连");
      return;
    }

    const wsUrl = String(import.meta.env.VITE_API_MEET_SERVER_WS);
    try {
      socket = new WebSocket(wsUrl);
    } catch (err) {
      console.error("WebSocket 构造失败:", err);
      scheduleReconnect();
      return;
    }

    socket.onopen = () => {
      console.log("WebSocket 已连接");
      reconnectAttempts = 0;
      // 加入房间
      sendWebSocketMessage({ type: "join", roomId: callStore.roomId, userId: userStore.userId });
      // 将自己视为已加入
      handleUserJoin(userStore.userId);
      startHeartbeat();
    };

    socket.onmessage = handleServerMessage;

    socket.onclose = ev => {
      console.warn("WebSocket 已关闭：", ev);
      stopHeartbeat();
      scheduleReconnect();
    };

    socket.onerror = err => {
      console.error("WebSocket 错误：", err);
      // 错误后连接通常会被 onclose 触发，仍然走重连流程
    };
  }

  /** 定时器：发送心跳 */
  function startHeartbeat() {
    stopHeartbeat();
    heartbeatTimer = window.setInterval(() => {
      if (socket && socket.readyState === WebSocket.OPEN) {
        sendWebSocketMessage({ type: "heartbeat", roomId: callStore.roomId, userId: userStore.userId });
      }
    }, heartbeatIntervalMs) as unknown as number;
  }

  function stopHeartbeat() {
    if (heartbeatTimer) {
      clearInterval(heartbeatTimer);
      heartbeatTimer = null;
    }
  }

  /** 重连调度（指数退避） */
  function scheduleReconnect() {
    reconnectAttempts++;
    if (reconnectAttempts > maxReconnectAttempts) {
      console.error("重连尝试次数达到上限，停止重连");
      return;
    }
    const delay = initialReconnectDelayMs * Math.pow(2, reconnectAttempts - 1);
    console.info(`将在 ${delay}ms 后尝试第 ${reconnectAttempts} 次重连`);
    setTimeout(() => initializeWebSocket(), delay);
  }

  /** 挂断：通知服务器并关闭资源 */
  async function handUp() {
    try {
      // 优雅离开房间
      sendWebSocketMessage({ type: "leave", roomId: callStore.roomId, userId: userStore.userId });
      // 关闭所有 pull/publish，释放本地设备
      try {
        // 如果 webRTC 提供 close，会关闭所有流
        webRTC.value.close();
      } catch (e) {
        console.warn("webRTC.close error:", e);
      }

      // 关闭窗口（tauri）
      try {
        const w = await getCurrentWindow();
        await w.close();
      } catch (e) {
        console.warn("getCurrentWindow.close error:", e);
      }
    } catch (err) {
      console.error("handUp error:", err);
    }
  }

  /** 组件挂载：初始化 WebSocket */
  onMounted(() => {
    initializeWebSocket();
  });

  /** 组件卸载：清理所有资源 */
  onBeforeUnmount(() => {
    try {
      // 向服务器发送离开（若 socket 仍然可用）
      if (socket && socket.readyState === WebSocket.OPEN) {
        sendWebSocketMessage({ type: "leave", roomId: callStore.roomId, userId: userStore.userId });
      }
    } catch (e) {
      console.warn("beforeunmount send leave error:", e);
    }

    // 关闭 socket
    try {
      if (socket) {
        socket.close();
        socket = null;
      }
    } catch (e) {
      console.warn("close socket error:", e);
    }

    // 停止心跳
    stopHeartbeat();

    // 清除 webRTC 资源：停止所有 pull/publish
    try {
      // 如果 webRTC 提供列出当前 pull 的方法，优先调用并逐个 removePull
      // 否则尝试遍历 activeUsers 清理
      for (const userId of [...activeUsers.value]) {
        try {
          webRTC.value.removePull?.(userId);
        } catch {
          /* noop */
        }
      }
      webRTC.value.close();
    } catch (e) {
      console.warn("cleanup webRTC error:", e);
    }

    // 清理本地状态
    activeUsers.value = [];
    videoRefs.value.clear();
    publishing.value.clear();
    pulling.value.clear();
  });
</script>

<style lang="scss" scoped>
  .video-call-header {
    background-color: #f2f2f2;
  }

  /* 页面总体布局 */
  .meeting-page {
    height: calc(100vh - 30px);
  }

  /* 折叠按钮 */
  .toggle-chat-btn {
    position: absolute;
    top: 40px;
    right: 20px;
    z-index: 10;
    background-color: #1677ff;
    color: #fff;
  }

  /* 左侧视频区域 */
  .video-section {
    width: 80%;
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: #333;
  }

  /* 视频窗口栅格布局 */
  .video-grid {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    align-content: center;
    gap: 5px;
    width: 96%;
    height: calc(100vh - 30px);
    padding: 5px;
    box-sizing: border-box;
    overflow: hidden;
  }

  /* 每个视频窗口，保持5:4宽高比 */
  .video-window {
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: #444;
    color: #fff;
    font-size: 1.2em;
    aspect-ratio: 16 / 9;
    flex: 1 1 calc(32% - 5px);
    /* 三列布局，保持一定的间距 */
    min-width: 32%;
    max-width: 96%;
    border-radius: 5px;
    object-fit: cover;
  }

  /* 右侧聊天区域 */
  .chat-section {
    padding: 10px;
    background-color: #f9f9f9;
    display: flex;
    flex-direction: column;
  }

  /* 聊天内容卡片 */
  .chat-card {
    display: flex;
    flex-direction: column;

    :deep(.el-card__body) {
      height: 100%;
    }
  }

  .chat-messages {
    flex: 1;
    padding: 5px;
    overflow-y: auto;
    margin-bottom: 10px;
    height: calc(100% - 120px);
    border: 1px solid #ddd;
    border-radius: 5px;
  }

  .chat-input {
    padding-bottom: 10px;
  }

  // .message {
  //     margin-bottom: 8px;
  // }
</style>
