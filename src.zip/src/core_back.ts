// // 常量定义
// import { MessageType, MessageContentType } from "@/constants";

// // 本地工具和存储
// import { storage } from "@/utils/Storage";
// import { useAudioPlayer, AudioEnum } from "@/hooks/useAudioPlayer";
// import { useTauriEvent } from "@/hooks/useTauriEvent";
// import { useGlobalShortcut } from "./hooks/useGlobalShortcut";
// import ObjectUtils from "@/utils/ObjectUtils";
// import { downloadDir } from "@tauri-apps/api/path";
// import { useTray } from "@/hooks/useTray";
// import { exit } from "@tauri-apps/plugin-process";
// import { useIdleTaskExecutor } from "@/hooks/useIdleTaskExecutor";
// // import { useUpdate } from "@/hooks/useUpdate"

// // 窗口操作
// import { CreateScreenWindow } from "@/windows/screen";
// import { showOrCreateNotifyWindow, calculateHideNotifyWindow } from "@/windows/notify";
// import { ShowMainWindow, appIsMinimizedOrHidden } from "@/windows/main";

// // 数据请求
// import api from "@/api/index";

// // 配置和初始化
// import { useWebSocketWorker } from "@/hooks/useWebSocketWorker";
// //import loadWorker from "@/worker/LoadWorker";

// // 状态管理和数据存储
// import { useChatMainStore } from "@/store/modules/chat";
// import { useMessageStore } from "@/store/modules/message";
// import { useUserStore } from "@/store/modules/user";
// import { useCallStore } from "@/store/modules/call";
// import { useSettingStore } from "@/store/modules/setting";
// import { useFriendsStore } from "@/store/modules/friends";

// // 数据库实体
// import SingleMessage from "@/database/entity/SingleMessage";
// import GroupMessage from "@/database/entity/GroupMessage";
// import { useMappers } from "@/database";

// // 获取和初始化数据库操作
// const { chatsMapper, singleMapper, groupMapper, friendsMapper } = useMappers();

// // 状态管理实例
// const callStore = useCallStore();
// const chatStore = useChatMainStore();
// const userStore = useUserStore();
// const messageStore = useMessageStore();
// const settingStore = useSettingStore();
// const friendStore = useFriendsStore();

// // 声音
// const { play } = useAudioPlayer();

// // 系统托盘
// const { init, flash } = useTray();

// // 事件总线
// const { onceEventDebounced } = useTauriEvent();

// // 日志
// const log = useLogger();

// const { state, connect, send, disconnect, onMessage } = useWebSocketWorker();

// // 异步（空闲）任务执行器
// const exec = useIdleTaskExecutor({ maxWorkTimePerIdle: 12 });

// // const { fetchVersion } = useUpdate();
// /**
//  * 主管理器
//  */
// class MainManager {
//   // 单例
//   private static instance: MainManager;

//   private constructor() {}

//   public static getInstance(): MainManager {
//     if (!MainManager.instance) {
//       MainManager.instance = new MainManager();
//     }
//     return MainManager.instance;
//   }

//   // 初始化客户端
//   initClient() {
//     // 初始化语言
//     this.initLanguage();

//     // 初始化用户信息
//     this.initUser();

//     // 同步用户数据
//     this.syncUserData();

//     // 同步会话数据
//     this.initChatStore();

//     // 初始化websocket
//     this.initWebSocket();

//     // 初始化系统托盘
//     this.initTray();

//     // 初始化快捷键
//     this.initShortcut();

//     // 初始化文件下载
//     this.initFileDownload();
//   }

//   /**
//    * 初始化语言
//    */
//   async initLanguage() {
//     //await fetchVersion()
//   }

//   /**
//    * 初始化文件下载目录
//    */
//   async initFileDownload() {
//     if (ObjectUtils.isEmpty(settingStore.file.path)) {
//       settingStore.file.path = await downloadDir();
//     }
//   }

//   /**
//    * 初始化用户信息
//    */
//   async initUser() {
//     userStore.handleGetUserInfo();
//   }

//   // 初始化数据库和相关表格
//   async initDatabase() {
//     await Promise.all([
//       await chatsMapper.createFTSTable(),
//       await singleMapper.createFTSTable(),
//       await groupMapper.createFTSTable(),
//       await friendsMapper.createFTSTable(),
//       log.prettyInfo("database", "数据库初始化成功")
//     ]);
//   }

//   // 初始化WebSocket连接
//   initWebSocket() {
//     const url = new URL(import.meta.env.VITE_API_SERVER_WS);

//     // 添加用户id 和 token 用于 用户鉴权
//     url.searchParams.append("uid", userStore.userId);
//     url.searchParams.append("token", userStore.token);

//     onMessage((e :any)=> {
//       log.prettyInfo("websocket", "收到 ws 消息:", e);
//       this.handleWebSocketMessage(e);
//     });

//     // 发起连接
//     connect(url.toString(), {
//       payload: { code: 1000, token: userStore.token, data: "registrar" },
//       heartbeat: { code: 1001, token: userStore.token, data: "heartbeat" },
//       interval: 25000,
//       protocol: import.meta.env.VITE_PROTOCOL_TYPE
//     });

//     log.prettySuccess("websocket", "WebSocket连接成功");
//   }

//   /**
//    * 处理WebSocket收到的消息
//    * @param data
//    */
//   handleWebSocketMessage(res: any) {
//     const { code, data } = res;
//     if (!data) return;
//     if (code === MessageType.SINGLE_MESSAGE.code || code === MessageType.GROUP_MESSAGE.code) {
//       this.handleIncomingMessage(data, code); // 处理消息
//     }
//     if (code === MessageType.VIDEO_MESSAGE.code) {
//       callStore.handleCallMessage(data); // 处理视频消息
//     }
//     if (code === MessageType.REFRESHTOKEN.code) {
//       userStore.refreshToken(); // 刷新token
//     }
//   }

//   /**
//    * 处理收到的消息
//    * @param message
//    * @param code
//    */
//   async handleIncomingMessage(message: SingleMessage | GroupMessage, code: number) {
//     if (settingStore.notification.message) {
//       // 播放提示音
//       play(AudioEnum.MESSAGE_ALERT);

//       // 窗口最小化时
//       if (await appIsMinimizedOrHidden()) {
//         // 系统托盘闪烁
//         flash(true);
//       }
//     }

//     const id =
//       code === MessageType.SINGLE_MESSAGE.code ? (message as SingleMessage).fromId : (message as GroupMessage).groupId;
//     // 更新或创建会话
//     chatStore.handleCreateOrUpdateChat(message, id as any);
//     // 插入新消息
//     messageStore.handleCreateMessage(id, message, code);
//   }
//   /**
//    * 初始化快捷键
//    * 先移除快捷键，再进行注册
//    */
//   async initShortcut() {
//     try {
//       // 主页面初始化
//       useGlobalShortcut([
//         {
//           name: "screenshot",
//           combination: "Ctrl+Shift+M",
//           handler: () => {
//             log.prettyInfo("shortcut", "开启截图");
//             CreateScreenWindow(screen.availWidth, screen.availHeight);
//           }
//         }
//       ]).init();
//     } catch (err) {
//       log.prettyError("shortcut", "快捷键初始化失败");
//     }

//     log.prettySuccess("shortcut", "初始化快捷键成功");
//     // // 初始化快捷键
//     // try {
//     //   await ShortcutManager.unregister(["Ctrl+Shift+M", "Esc"]);
//     // } catch (error) {
//     //   log.prettyError("core","移除快捷键失败");
//     // }

//     // try {
//     //   ShortcutManager.register("Ctrl+Shift+M", () => {
//     //     log.prettyInfo("core","开启截图");
//     //     CreateScreenWindow(screen.availWidth, screen.availHeight);
//     //   });
//     // } catch (error) {
//     //   log.prettyError("截图快捷键初始化失败");
//     // }

//     // try {
//     //   ShortcutManager.register("Esc", () => {
//     //     log.prettyInfo("core","结束截图");
//     //     CloseScreenWindow();
//     //   });
//     // } catch (error) {
//     //   log.prettyError("快捷键初始化失败");
//     // }
//     // //log.prettySuccess("初始化快捷键成功");
//   }

//   /**
//    * 初始化系统托盘
//    */
//   async initTray() {
//     // 托盘初始化
//     await init({
//       id: "app-tray",
//       tooltip: import.meta.env.VITE_APP_NAME,
//       icon: "icons/32x32.png",
//       empty_icon: "icons/empty.png",
//       flashTime: 500,
//       menuItems: [
//         { id: "open", text: "打开窗口", action: () => ShowMainWindow() },
//         {
//           id: "quit",
//           text: "退出",
//           action: async () => {
//             // 退出程序
//             await exit(0);
//           }
//         }
//       ],
//       trayClick: (event: any) => {
//         const { button, buttonState, type } = event;
//         if (button === "Left" && buttonState === "Up" && type === "Click") {
//           log.prettyInfo("tray", "鼠标左键点击抬起 打开主窗口");
//           ShowMainWindow();
//           // 系统托盘停止闪烁
//           flash(false);
//         }
//         if (button === "Right" && buttonState === "Up" && type === "Click") {
//         }
//       },
//       trayEnter: async (event: any) => {
//         const chatCount = chatStore.getHaveMessageChat.length;
//         if (chatCount > 0) {
//           showOrCreateNotifyWindow(chatCount, event.position);
//           // 消息通知窗口只监听一次
//           onceEventDebounced("notify-win-click", event => {
//             log.prettyInfo("tray", "应用加载完成:", event.payload);
//           });
//         }
//       },
//       trayMove: (event: any) => {
//         // 处理鼠标移动事件
//         // log.prettyInfo("tray","鼠标移动事件", event);
//       },
//       trayLeave: (event: any) => {
//         log.prettyInfo("tray", "鼠标移出关闭窗口", event);
//         calculateHideNotifyWindow(event);
//       }
//     });
//   }

//   /**
//    * 同步用户数据（消息、会话、好友）
//    */
//   async syncUserData() {
//     //await Promise.race([await this.updateMessageData(), this.updateChatData(), this.updateFriendData()]);
//     await Promise.race([await this.updateMessageData(), this.updateChatData()]);
//     // 刷新好友请求信息
//     friendStore.loadNewFriends();
//   }

//   /**
//    * 获取并更新离线消息数据
//    * 用于在用户重新登录后同步消息
//    */
//   async updateMessageData() {
//     // 获取最近一次的会话时间戳
//     const chats = await chatsMapper.findLastChat();
//     const sequence = chats[0]?.sequence || 0; // 默认时间戳为0

//     const formData = {
//       fromId: storage.get("userId"), // 从用户名获取
//       sequence: sequence // 最近的会话时间戳
//     };

//     try {
//       const res: any = await api.GetMessageList(formData); // 通过API获取消息列表

//       if (res) {
//         if (res[MessageType.SINGLE_MESSAGE.code]) {
//           // 批量插入单聊消息
//           await singleMapper.batchInsert(res[MessageType.SINGLE_MESSAGE.code], {
//             ownerId: storage.get("userId"),
//             messageType: MessageType.SINGLE_MESSAGE.code
//           });

//           singleMapper.batchInsertFTS5(
//             res[MessageType.SINGLE_MESSAGE.code],
//             {
//               ownerId: storage.get("userId"),
//               messageType: MessageType.SINGLE_MESSAGE.code
//             },
//             200,
//             exec
//           );
//         }

//         if (res[MessageType.GROUP_MESSAGE.code]) {
//           // 批量插入群聊消息
//           await groupMapper.batchInsert(res[MessageType.GROUP_MESSAGE.code], {
//             ownerId: storage.get("userId"),
//             messageType: MessageType.GROUP_MESSAGE.code
//           });

//           groupMapper.batchInsertFTS5(
//             res[MessageType.GROUP_MESSAGE.code],
//             {
//               ownerId: storage.get("userId"),
//               messageType: MessageType.GROUP_MESSAGE.code
//             },
//             200,
//             exec
//           );
//         }

//         log.prettyInfo("core", "消息数据更新成功");
//       }
//     } catch (error) {
//       log.prettyError("core", "更新离线消息失败", error);
//     }
//   }

//   /**
//    * 获取并更新会话数据
//    * 用于更新用户的会话列表
//    */
//   async updateChatData() {
//     // 获取最近一次会话，用于获取 sequence
//     const lastChats = await chatsMapper.findLastChat();
//     const sequence = lastChats?.[0]?.sequence ?? 0;

//     try {
//       const res: any = await api.GetChatList({
//         fromId: storage.get("userId"),
//         sequence: sequence
//       });

//       if (Array.isArray(res) && res.length > 0) {
//         // 把服务器返回的数据转换为要写入 FTS/索引的实体数组
//         const transformed: Array<Record<string, any>> = res.map((chat: any) => {
//           // 解析 message（容错）
//           let parsedMessage: any = chat.message;
//           try {
//             if (typeof chat.message === "string" && chat.message.length > 0) {
//               parsedMessage = JSON.parse(chat.message);
//             }
//           } catch (e) {
//             // 解析失败则保留原始字符串
//             parsedMessage = chat.message;
//           }

//           // 用 replaceMessageBody 生成最终 message 展示内容（你原来的函数）
//           const message = this.replaceMessageBody(parsedMessage, chat.messageContentType);

//           // 组装要插入的对象（字段名根据你的 FTS 表/mapper 期望）
//           const newChat: Record<string, any> = {
//             ...chat,
//             message // 用处理后的 message 覆盖原字段
//           };
//           // 删除不需要的临时字段（例如 messageContentType）
//           delete newChat.messageContentType;

//           return newChat;
//         });

//         // 批量写入：使用 chatsMapper.batchInsertFTS5（内部会处理分批、事务等）
//         // 注意：此方法会把数组拆分成批次并执行 INSERT
//         try {
//           await chatsMapper.batchInsert(transformed);

//           chatsMapper.batchInsertFTS5(transformed, undefined, 200, exec);

//           log.prettyInfo("core", `批量插入 ${transformed.length} 条会话到 FTS 索引/表`);
//         } catch (batchErr) {
//           // 若批量插入失败，记录错误并尝试逐条插入（降级策略）
//           log.prettyWarn("core", "batchInsertFTS5 失败，尝试逐条插入", batchErr);
//           for (const item of transformed) {
//             try {
//               // 逐条插入或更新（回退到原来的单条插入/更新方法）
//               await chatsMapper.insertOrUpdate(item);
//             } catch (singleErr) {
//               log.prettyError("core", "单条插入失败，忽略并继续", singleErr);
//             }
//           }
//         }

//         // 写入完成后，从主表读取所有会话并排序展示（保持和原逻辑一致）
//         const list: any = await chatsMapper.selectList();
//         chatStore.handleSortChatList(list);
//         log.prettyInfo("core", "会话数据批量更新成功");
//       } else {
//         // 如果无新数据，仍尝试获取并排序本地会话
//         const list: any = await chatsMapper.selectList();
//         chatStore.handleSortChatList(list);
//       }
//     } catch (error) {
//       log.prettyError("core", "更新会话数据失败", error);
//       // 在失败时，仍然尝试获取所有会话列表并排序（和以前保持一致）
//       const list: any = await chatsMapper.selectList();
//       chatStore.handleSortChatList(list);
//     }
//   }

//   /**
//    * 更新好友数据
//    * 用于同步好友列表
//    */
//   async updateFriendData() {
//     //const friends = await friendsMapper.findLast(); // 获取最后一条好友记录
//     //const sequence = friends[0]?.sequence || 0; // 默认时间戳为0
//     //const sequence = 0; // 默认时间戳为0
//     try {
//       const res: any = await api.GetContacts({
//         userId: storage.get("userId") // 获取当前用户的好友数据
//       });
//       if (res && res.length > 0) {
//         // TODO 先删后插,确保数据能更新
//         friendsMapper.deleteById({ userId: storage.get("userId") } as any);
//         friendsMapper.batchInsert(res); // 插入或更新好友数据
//         log.prettyInfo("core", "好友数据更新成功");
//       }
//     } catch (error) {
//       log.prettyError("core", "更新好友数据失败", error);
//     }
//   }

//   /**
//    * 获取消息体的替代文本
//    * @param messageObj 消息体
//    * @param messageContentType 消息内容类型
//    * @returns 返回替代的消息文本
//    */
//   replaceMessageBody(messageObj: any, messageContentType: any) {
//     const code = parseInt(messageContentType); // 转换为整数

//     if (!messageObj || !messageContentType) return ""; // 如果消息为空，则返回空字符串

//     // 根据消息类型，替换消息内容
//     switch (code) {
//       case MessageContentType.TEXT.code:
//         return messageObj.message; // 文字消息
//       case MessageContentType.IMAGE.code:
//         return "[图片]"; // 图片消息
//       case MessageContentType.VIDEO.code:
//         return "[视频]"; // 视频消息
//       case MessageContentType.AUDIO.code:
//         return "[语音]"; // 语音消息
//       case MessageContentType.FILE.code:
//         return "[文件]"; // 文件消息
//       case MessageContentType.LOCAL.code:
//         return "[位置]"; // 位置消息
//       default:
//         return "未知消息类型"; // 未知类型的消息
//     }
//   }

//   /**
//    * 初始化会话
//    */
//   initChatStore() {
//     chatStore.handleInit();
//   }
// }

// // 创建 hook
// export function useMainManager() {
//   return MainManager.getInstance();
// }
