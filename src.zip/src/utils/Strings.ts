/**
 * https://github.com/iimeta/iim-web/blob/main/src/utils/strings.js
 */

/**
 * 将字符串中的 URL 转为 <a> 标签，但不触发默认跳转，而是交给 JS 处理
 * @param {String} str
 */
export function urlToLink(str: string): string {
  // const re: RegExp = /((ftp|http|https?:\/\/)?([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(\/[^\s]*)?)/g;
  const re: RegExp = new RegExp("(ftp|http|https?://)?([a-zA-Z0-9-]+.)+[a-zA-Z]{2,}(/[^s]*)?", "g");
  return str.replace(re, match => {
    const safeUrl = match.replace(/"/g, "&quot;");
    return `<a  style="text-decoration: none; cursor: pointer; color:#0000EE" data-url="${safeUrl}">${match}</a>`;
  });
}

// export function urlToLink(str: string) {
//   const re: RegExp =
//     /((ftp|http|https?:\/\/)?([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(\/[^\s]*)?)/g;
//   return str.replace(re, function (website) {
//     return (
//       "<a href='" +
//       website +
//       "' style='text-decoration: none; cursor: pointer;' target='_blank'>" +
//       website +
//       "</a>"
//     );
//   });
// }

/**
 * 去除字符串控制
 *
 * @param {String} str
 */
export function trim(str: string, type = null) {
  if (type) {
    return str.replace(/(^\s*)|(\s*$)/g, "");
  } else if (type == "l") {
    return str.replace(/(^\s*)/g, "");
  } else {
    return str.replace(/(\s*$)/g, "");
  }
}

/**
 * 隐藏用户手机号中间四位
 *
 * @param {String} phone  手机号
 */
export function hidePhone(phone: string) {
  return phone.replace(/(\d{3})\d{4}(\d{4})/, "$1****$2");
}

/**
 * Url 替换超链接
 *
 * @param {String} text 文本
 */
export function textReplaceLink(text: string) {
  const re: RegExp = new RegExp("(ftp|http|https?://)?([a-zA-Z0-9-]+.)+[a-zA-Z]{2,}(/[^s]*)?", "g");
  // const re: RegExp = /((ftp|http|https?:\/\/)?([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(\/[^\s]*)?)/g;
  return text.replace(re, function (website) {
    return (
      "<a href='" + website + "' style='text-decoration: none; cursor: pointer;' target='_blank'>" + website + "</a>"
    );
  });
}

/**
 * 文本 替换@信息
 *
 * @param {String} text 文本
 * @param {String} color 超链接颜色
 */
export function textReplaceMention(text: string, color: string = "#EE9028") {
  return text.replace(new RegExp(/@\S+/, "g"), ($0, _$1) => {
    return `<span style="color:${color};">${$0}</span>`;
  });
}

/**
 * 文本关键词高亮
 * @param keyword 关键词
 * @param text 文本
 * @param color  高亮颜色
 * @returns
 */
export function textToHighlight(keyword: string, text: string, color: string = "yellow") {
  const regExp = new RegExp(keyword, "g");
  return text.replace(regExp, `<span style="background: ${color};">${keyword}</span>`);
}

/**
 * Escape HTML for safe display
 */
export function escapeHtml(s: string): string {
  return String(s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

/**
 * 构建用于高亮的正则（去重、按长度降序、转义特殊字符）
 * 返回 null 表示没有有效 token
 */
export function buildHighlightRegex(tokensArr: string[]): RegExp | null {
  if (!Array.isArray(tokensArr)) return null;

  // 去重、trim、过滤空
  const uniq = Array.from(new Set(tokensArr.map(t => String(t).trim()).filter(Boolean)));

  if (uniq.length === 0) return null;

  // 按长度降序，避免短 token 覆盖长 token（例如： '高' 与 '高考'）
  uniq.sort((a, b) => b.length - a.length);

  // 转义 regex 特殊字符
  const escaped = uniq.map(t => t.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"));

  // 使用全局和 unicode 标志，中文无需忽略大小写
  try {
    return new RegExp(`(${escaped.join("|")})`, "gu");
  } catch (e) {
    // 若正则构造失败（极端字符），退回 null
    return null;
  }
}

/**
 * 根据 tokens 高亮文本（先做 HTML 转义）
 * - text: 原始文本
 * - tokensArr: token 列表（会被去重/排序/转义）
 * - tag: 可选，高亮元素标签，默认 'mark'（也可以传 'b'、'span' 等）
 */
export function highlightTextByTokens(text: string, tokensArr: string[], tag: string = "mark"): string {
  if (!text) return escapeHtml(String(text));
  if (!Array.isArray(tokensArr) || tokensArr.length === 0) return escapeHtml(String(text));

  const html = escapeHtml(String(text));
  const rx = buildHighlightRegex(tokensArr);
  if (!rx) return html;

  // 包裹匹配项（注意：替换内容已经是 HTML 转义过的）
  return html.replace(rx, `<${tag}>$1</${tag}>`);
}

/**
 * 获取文件后缀名
 *
 * @param {String} fileName
 */
export function fileSuffix(fileName: string) {
  let ext = fileName.split(".");

  return ext[ext.length - 1];
}
