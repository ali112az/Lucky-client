<template>
    <div ref="boxRef" class="vl-box" @scroll="handleScroll" v-memo="offsetData">
        <div :style="{ height: boxHeight + 'px' }" ref="listRef">
            <div :style="styleTranslate">
                <div class="vl-box-item" v-for="(item, index) in offsetData" :key="index" :id="(item as any)[id]">
                    <!-- <slot :item="item" :index="index"></slot> -->

                    <Message :message="item">
                        <template #more>
                            <div style="text-align: center;" v-show="index === 0 && count > 0">
                                <span class="more-message no-select" @click="handleMoreMessage">查看更多消息</span>
                            </div>
                        </template>
                        <template #time>
                            <div class="message-time no-select" v-if="handelShouldDisplayTime(index)">
                                {{ getTimeToDisplay((item as any).message_time, 'yyyy-MM-dd', true) }}
                            </div>
                        </template>
                    </Message>

                </div>
            </div>
        </div>
    </div>
</template>

<script setup lang="ts">

import { getTimeToDisplay } from '@/utils/Date'
import Message from '@/components/Message/index.vue'

interface Position {
    /**
     * 当前数据处在data数组的索引位置
     */
    index: any
    /**
     * 当前数据dom的top位置
     */
    top: number
    /**
     * 当前数据dom的bottom位置
     */
    bottom: number
    /**
     * 当前数据dom的高度(初始值为猜测高度【预估高度】)
     */
    height: number

}

const emit = defineEmits(['handleMoreMessage'])

const boxRef = ref(null); // 容器dom
const listRef = ref(null); // 列表dom

const props = defineProps({
    rowHeight: {
        type: Number,
        default: 60
    },
    count: {
        type: Number,
        default: 15
    },
    data: {
        type: Array,
        default: () => []
    },
    id: {
        type: String,
        default: 'message_id'
    }
})

const { data, count } = toRefs(props)

watch(() => data, () => {
    updatePosition()
})


onMounted(() => {
    initPosition()
})


/**
 * 判断是否需要显示时间
 * @param index 消息索引
 */
const handelShouldDisplayTime = (index: number) => {
    if (index === 0) return true;
    const datas: any = data.value;
    const currentTime = datas[index].message_time;
    const prevTime = datas[index - 1].message_time;
    return (currentTime - prevTime) >= 5 * 60 * 1000;
}

const position = ref<Position[]>([])

const offset = ref(0); // 偏移
const offsetIndex = ref(0); // 偏移下标
//const windowHeight = ref(document.documentElement.clientHeight); // 窗口高度

//const boxHeight = computed(() => props.data.length * props.rowHeight); // 总高度
const boxHeight = ref(null)

const startIndex = ref(0)




/**
 * 查看更多消息
 */
const handleMoreMessage = async () => {
    // 记录当前滚动位置
    //previousScrollHeight = messageRecordsRef.value.scrollHeight
    emit('handleMoreMessage')
}

const offsetData = computed(() => {
    const datas = data.value;
    if (!datas || datas.length <= 0) return [];
    const count = Math.ceil(boxRef.value.clientHeight / props.rowHeight);
    //const startIndex = Math.floor(offset.value / props.rowHeight);
    //offsetIndex.value = startIndex;
    return datas.slice(startIndex.value, count + startIndex.value);
});

function findStartByBinarySearch(position: Position[], scrollTop: number) {
    let startIdx = 0
    let endIdx = position.length - 1
    let resultIdx: any;
    while (startIdx <= endIdx) {
        // Math.trunc 去除小数部分，只取整数部分. 取startIdx 到 endIdx的中间索引号
        const middleIdx = Math.trunc((startIdx + endIdx) / 2)
        // 获取中间索引号对应元素的位置信息
        const middleEle = position[middleIdx]
        // 获取中间索引号对应元素的底部位置
        const middleEleEndPos = middleEle.bottom
        if (middleEleEndPos === scrollTop) {
            // 当前滚动高度等于中间索引号对应元素的底部位置，则start为中间索引号的下一个位置
            return middleIdx + 1
        } else if (middleEleEndPos < scrollTop) {
            // 当前滚动高度大于中间索引号对应元素的底部位置，则调整查找区间为右区间
            startIdx = middleIdx + 1
        } else if (middleEleEndPos > scrollTop) {
            // 当前滚动高度大于中间索引号对应元素的底部位置，则调整查找区间为左区间
            if (resultIdx === undefined || resultIdx > middleIdx) {
                // 存储元素 middleEleEndPos>scrollTop 元素的最小数组索引号
                resultIdx = middleIdx
            }
            // 调整查找区间为左区间
            endIdx = middleIdx - 1
        }
    }
    return resultIdx
}


const initPosition = () => {
    const datas = data.value;
    for (let i = 0; i < datas.length; i++) {
        position.value.push({
            index: (datas[i] as any)['message_id'],
            height: props.rowHeight,
            top: i * props.rowHeight,
            bottom: (i + 1) * props.rowHeight
        })
    }
}

const updatePosition = () => {
    if (position.value.length === 0) {
        initPosition();
    }
    const nodes = listRef.value?.children || [];
    if (!nodes.length) return;

    const data = [...nodes];


    for (let i = 0; i < data.length; i++) {
        const childEle = data[i] as HTMLElement
        // 获取当前数据dom节点的数据在positionDataArr数组中的索引位置
        const dataIndexStr = childEle.dataset['index']
        if (!dataIndexStr) continue

        const dataIndex = parseInt(dataIndexStr)
        // 从positionDataArr获取到当前dom元素的位置信息和高度信息
        const dataItem = position.value[dataIndex]
        if (!dataItem) continue

        // 获取元素的实际高度
        const { height } = childEle.getBoundingClientRect()
        // const { offsetHeight: height } = childEle
        const oldHeight = dataItem.height
        /*
        计算当前数据dom元素的旧高度和当前高度的差值
    
        如：
        oldHeight为100px，height为50px, 那么dffVal为 50px，那么 oldHeight - dffVal 为 50px
        oldHeight为50px，height为100px, 那么dffVal为 -50px，那么 oldHeight - dffVal 为 100px
         */
        const dffVal = oldHeight - height
        if (dffVal != 0) {
            // 当前dom元素的实际高度与allData中记录的高度不一致，则更新高度以及元素位置信息
            dataItem.height = oldHeight - dffVal
            dataItem.bottom = dataItem.bottom - dffVal

            for (let j = dataIndex + 1; j < position.value.length; j++) {
                const jPosDataItem = position.value[j]
                // j位置的上一个位置的元素
                const jPrevPosDataItem = position.value[j - 1]

                jPosDataItem.top = jPrevPosDataItem.bottom
                jPosDataItem.bottom = jPosDataItem.top + jPosDataItem.height
            }
        }
    }
    boxHeight.value = position.value.length > 0 ? position.value[position.value.length - 1].bottom : 0
};

const contentListOffset = ref<number>(0);

const styleTranslate = computed<string>(() => {
    return `transform:translate(0,${contentListOffset.value}px)`
});

const handleScroll = rafThrottle(() => {
    if (position.value.length === 0) {
        updatePosition()
    }
    //offset.value = boxRef.value.scrollTop;
    startIndex.value = findStartByBinarySearch(position.value, boxRef.value.scrollTop);
    contentListOffset.value = position.value[startIndex.value - 1] ? position.value[startIndex.value - 1].top : 0;

});


function rafThrottle(fn: Function) {
    let lock = false;
    return function (this: any, ...args: any[]) {
        if (lock) return;
        lock = true;
        window.requestAnimationFrame(() => {
            fn.apply(this, args);
            lock = false;
        });
    };
}

const init = () => {
    initPosition()
    nextTick(() => {
        updatePosition();
    });
}

onMounted(() => {
    init()
})


// 监听窗口高度变化，及时更新
// watchEffect(() => {
//     windowHeight.value = document.documentElement.clientHeight;
// });

</script>


<style lang="scss" scoped>
/* 定义滚动条宽度 */
@mixin scroll-bar($width: 5px) {

    /* 背景色为透明 */
    &::-webkit-scrollbar-track {
        border-radius: 10px;
        background-color: transparent;
    }

    &::-webkit-scrollbar {
        width: $width;
        height: 10px;
        background-color: transparent;
    }

    &::-webkit-scrollbar-thumb {
        border-radius: 10px;
        background-color: rgba(0, 0, 0, 0.1);
    }
}

.active {
    background-color: #ddd;
}


.vl-box {
    height: 99%;
    margin-top: 5px;
    width: 100%;
    //padding: 10px;
    box-sizing: border-box;
    position: relative;
    overflow-y: scroll;
    @include scroll-bar();
}



.message-time {
    text-align: center;
    font-size: 12px;
    color: #ccc;
}

.more-message {
    margin: 5px 0px 10px 0px;
    display: inline-block;
    font-size: 12px;
    color: #539df3;
    cursor: pointer;
}
</style>