<template>
    <div class="message-records" ref="messageRecordsRef" v-memo="[data]" @scroll="handleScroll">
        <template v-for="(message, index) in data" :key="index">
            <Message :message="message">
                <template #more>
                    <div style="text-align: center;" v-show="index === 0 && count > 0">
                        <span class="more-message no-select"  @click="handleMoreMessage">查看更多消息</span>
                    </div>
                </template>
                <template #time>
                    <div class="message-time no-select" v-if="handelShouldDisplayTime(index)">
                        {{ getTimeToDisplay(message.message_time, 'yyyy-MM-dd', true) }}
                    </div>
                </template>
            </Message>
        </template>
    </div>
</template>

<script setup>
import Message from '@/components/Message'
import { ref, onMounted, nextTick, watch, onUpdated } from 'vue'
import { getTimeToDisplay } from '@/utils/Date'
import { useDebounceFn } from '@vueuse/core'
import LazyLoad from 'vanilla-lazyload';

const messageRecordsRef = ref(null);
const isScrolling = ref(false);
let previousScrollHeight = 0;

const emit = defineEmits(['handleMoreMessage'])

const props = defineProps({
    data: Array,
    count: Number
})

/**
 * 判断是否需要显示时间
 * @param index 消息索引
 */
const handelShouldDisplayTime = (index) => {
    if (index === 0) return true
    const currentTime = props.data[index].message_time
    const prevTime = props.data[index - 1].message_time
    return (currentTime - prevTime) >= 5 * 60 * 1000
}

/**
 * 查看更多消息
 */
const handleMoreMessage = async () => {
    // 记录当前滚动位置
    previousScrollHeight = messageRecordsRef.value.scrollHeight
    emit('handleMoreMessage')
    //virtListRef.value.addedList2Top(props.data);
}
onUpdated(() => {
    /**
     * 判断是否需要滚动到底部
     */
    requestAnimationFrame(() => {
        if (!isScrolling.value) {
            scrollToBottom()
        } else {
            // 恢复到之前的位置
            messageRecordsRef.value.scrollTop = messageRecordsRef.value.scrollHeight - previousScrollHeight
        }
    })
})
/**
 * 滚动到底部
 */
const scrollToBottom = () => {
    nextTick(() => {
        const container = messageRecordsRef.value
        if (container) {
            container.scrollTop = container.scrollHeight - container.offsetHeight + 1
        }
    })
}
/**
 * 处理滚动事件
 */
const handleScroll = useDebounceFn(() => {
    const { scrollTop, scrollHeight, offsetHeight } = messageRecordsRef.value
    isScrolling.value = Math.ceil(scrollTop + offsetHeight) < scrollHeight
}, 10)


onMounted(() => {
    new LazyLoad({
        elements_selector: '.lazy-img',
        threshold: 300,
        callback_loaded: (el) => el.classList.add('loaded')
    });
});

</script>

<style lang="scss" scoped>
/* 定义滚动条样式 */
@mixin scroll-bar($width: 5px) {
    &::-webkit-scrollbar-track {
        border-radius: 10px;
        background-color: transparent;
    }

    &::-webkit-scrollbar {
        width: $width;
        height: 10px;
        background-color: transparent;
    }

    &::-webkit-scrollbar-thumb {
        border-radius: 10px;
        background-color: rgba(0, 0, 0, 0.1);
    }
}

.message-records {
    height: 99%;
    margin-top: 5px;
    width: 100%;
    padding: 10px;
    box-sizing: border-box;
    position: relative;
    overflow-y: scroll;
    @include scroll-bar();
}

.message-container {
    display: flex;
    align-items: flex-start;
    margin-bottom: 10px;
}

.message-container.owner {
    justify-content: flex-end;
}

.message-content {
    display: flex;
    flex-direction: column;
    margin-left: 10px;
}

.message-content.owner {
    margin-left: 0;
    margin-right: 10px;
    align-items: flex-end;
}

.user-name {
    font-size: 11px;
    color: #999;
    margin-bottom: 5px;
}

.user-name.owner {
    text-align: right;
    margin: 5px;
}

.message-time {
    text-align: center;
    font-size: 12px;
    color: #ccc;
}

.avatar {
    width: 35px;
    height: 35px;
    border-radius: 8px;
    margin: 5px;
}

.more-message {
    margin: 5px 0px 10px 0px;
    display: inline-block;
    font-size: 12px;
    color: #539df3;
    cursor: pointer;
}

.bubble {
    //background-color: #f1f1f1;
    border-radius: 10px;
    padding: 10px;
    max-width: 100%;
    word-break: break-word;
}
</style>